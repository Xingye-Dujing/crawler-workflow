"""The public API of the framework: one object a host constructs and calls.

Nothing here imports a web framework. A host maps its HTTP body onto ``ChatRequest``, iterates the
events from ``ask()`` (writing SSE or forwarding them to a UI), and calls the other CRUD methods
from its own routes. ``adapters.flask`` is an optional thin example of that mapping.

The SQLite path is resolved through the host at call time, so a host whose ``data_dir()`` follows
the signed-in account gets real per-account isolation from one service instance.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from pathlib import Path

from . import config, python_runtime
from .agent import Agent
from .approvals import Approvals
from .artifacts import ArtifactRegistry
from .commands import CommandRegistry
from .context import ContextBuilder
from .costs import Costs
from .errors import AIError
from .fsm import TURN
from .host import DefaultHostAdapter, HostAdapter
from .monitors import Monitors
from .plugins import PluginHost
from .providers.registry import ProviderCatalog
from .python_scripts import ScriptLibrary
from .references import References
from .scopes import Scopes
from .skills import SkillRegistry
from .store import Store
from .tools import ToolRegistry
from .tracing import Tracing
from .types import ChatRequest, new_id
from .workspace import Workspace

#: The wire protocol version stamped on every event. A frontend can branch on it during a
#: migration instead of guessing from event names.
EVENT_PROTOCOL = 1

#: Which turn state an event moves the machine to. Terminal and user-waiting states are written by
#: the runner after the host's alert, so a subscription never returns before the notification. An
#: event never rewinds a turn either: a resumed turn is already streaming when its new ``meta``
#: arrives, so an illegal/backward move is recorded in the log and simply does not change the state.
EVENT_STATES = {
    'user': 'context',
    'meta': 'context',
    'text_delta': 'streaming',
    'thinking_delta': 'streaming',
    'tool_call': 'streaming',
    'tool_start': 'tool',
    'tool_result': 'streaming',
}

#: How much of the assistant's answer the finished-turn report carries. A notification is a
#: pointer, not a transcript: a host that needs the text reads the stored rows.
TURN_PREVIEW_CHARS = 240


@dataclass
class _TurnOutcome:
    """What one ``ask()`` learned about its own turn, for the host's finished-turn report."""

    turn_id: str = ''
    skill: str = ''
    provider: str = ''
    model: str = ''
    stop_reason: str = ''
    paused_reason: str = ''
    error: str = ''
    text: str = ''
    tool_calls: int = 0

    def observe(self, item: dict) -> None:
        kind = str(item.get('type') or '')
        if kind == 'meta':
            self.turn_id = str(item.get('turn_id') or '')
            self.skill = str(item.get('skill') or '')
            self.provider = str(item.get('provider') or '')
            self.model = str(item.get('model') or '')
        elif kind == 'text_delta':
            self.text += str(item.get('text') or '')
        elif kind == 'tool_start':
            self.tool_calls += 1
        elif kind == 'done':
            self.stop_reason = str(item.get('stop_reason') or '')
        elif kind == 'paused':
            self.paused_reason = str(item.get('reason') or '')

    @property
    def status(self) -> str:
        """The one word a host alerts on. Paused wins: it is the state a user must act on."""
        if self.paused_reason:
            return 'paused'
        if self.stop_reason == 'cancelled':
            return 'cancelled'
        if self.stop_reason == 'error' or self.error:
            return 'error'
        if self.stop_reason:
            return 'completed'
        # A caller that stopped iterating closed the stream before any done/paused event. The turn
        # did not finish, and calling that completed would be a lie the host shows as a popup.
        return 'aborted'

    def summary(self, request: ChatRequest) -> dict:
        preview = self.text if len(self.text) <= TURN_PREVIEW_CHARS else self.text[-TURN_PREVIEW_CHARS:]
        return {
            'conversation_id': request.conversation_id,
            'turn_id': self.turn_id or request.turn_id,
            'account': request.account,
            'status': self.status,
            'stop_reason': self.stop_reason,
            'reason': self.paused_reason,
            'error': self.error,
            'skill': self.skill,
            'provider': self.provider,
            'model': self.model,
            'tool_calls': self.tool_calls,
            'text': preview,
        }


class AgentWorkspace:
    """Construct once per process. All state is either in the host or in the store."""

    def __init__(self, host: HostAdapter | None = None, *, data_dir: str | Path | None = None):
        if host is None:
            host = DefaultHostAdapter(data_dir=data_dir)
        self.host = host
        Path(host.data_dir()).mkdir(parents=True, exist_ok=True)
        self.scopes = Scopes()
        self.store = Store(lambda: Path(self.host.data_dir()) / 'ai.db')
        self.tracing = Tracing(self.store)
        self.library = host.script_library(self.store) or ScriptLibrary(self.store)
        self.python = host.python_runtime() or python_runtime
        self.settings = host.settings()
        self.i18n = host.i18n()
        self.catalog = ProviderCatalog(self.settings, host, self.scopes)
        self.context = ContextBuilder(self.store, host, self.settings)
        self.skills = SkillRegistry(self.store, host, self.settings, self.catalog, self.scopes)
        self.tools = ToolRegistry(
            self.store,
            host,
            self.settings,
            self.context,
            self.workspace,
            scopes=self.scopes,
            library=self.library,
            python=self.python,
        )
        # A host declares its domain tools on the adapter; they are its real catalogue, so they are
        # registered once at boot. A name that collides with a builtin, a control tool or another
        # host tool is refused here by name instead of shadowing silently at call time.
        for spec in host.tools():
            self.tools.register(spec)
        self.artifact_registry = ArtifactRegistry()
        for kind, validator in (host.artifact_validators() or {}).items():
            self.artifact_registry.register_validator(kind, validator)
        for kind, preview in (host.artifact_previews() or {}).items():
            self.artifact_registry.register_preview(kind, preview)
        self.commands = CommandRegistry()
        self.commands.register('status', self._command_status)
        self.commands.register('skills', self._command_skills)
        self.commands.register('mode', self._command_mode)
        self.commands.register('compact', self._command_compact)
        for name, handler in (host.commands() or {}).items():
            self.commands.register(name, handler, host=True)
        self.skills.tools = self.tools
        self.approvals = Approvals()
        self.references = References(self.store, host, self.context)
        self.costs = Costs(self.store, self.settings, self.catalog)
        self.monitors = Monitors(self.store, host)
        self.plugins = PluginHost(
            self.store,
            host,
            self.settings,
            self.scopes,
            self.skills,
            self.tools,
            self.catalog,
            {'openai_compat': self._openai_factory, 'deepseek': self._deepseek_factory, 'ollama': self._ollama_factory},
        )
        self.agent = Agent(self)
        self._active: dict[str, object] = {}
        self._active_conversation: dict[str, str] = {}
        self._threads: dict[str, threading.Thread] = {}
        self._events = threading.Condition()
        self._lock = threading.RLock()
        # A kill between a text delta and the assistant row's settle leaves a `streaming` row.
        # Boot recovery settles those before any history is replayed to a provider.
        self.recover_streams()
        # No turn may stay mid-flight across a restart either: its event log keeps what happened,
        # and the next request starts a new turn.
        self.store.settle_interrupted_turns()
        self.store.settle_interrupted_steps()

    # ── small helpers ──────────────────────────────────────────────────────────

    def t(self, key: str, **fields) -> str:
        return self.i18n.t(key, **fields)

    def workspace(self, account: str = 'default') -> Workspace:
        return Workspace(self.store, account)

    def recover_streams(self) -> int:
        total = 0
        for conversation in self.store.list_conversations_all():
            total += self.store.settle_streams(conversation['id'])
        return total

    def _openai_factory(self, payload: dict):
        from .providers.openai_compat import OpenAICompatibleProvider
        from .types import ModelSpec, ProviderSpec

        spec = ProviderSpec(
            id=str(payload.get('id') or ''),
            label_key=str(payload.get('label_key') or ''),
            notes_key=str(payload.get('notes_key') or ''),
            protocol='openai',
            base_url=str(payload.get('base_url') or ''),
            models=tuple(
                ModelSpec(str(model.get('id') or ''), str(model.get('label') or ''))
                for model in payload.get('models') or ()
            ),
            requires_key=bool(payload.get('requires_key', True)),
            local_only=bool(payload.get('local_only', False)),
            capabilities=frozenset(payload.get('capabilities') or ()),
        )
        provider = OpenAICompatibleProvider()
        provider.spec = spec
        return provider

    def _deepseek_factory(self, payload: dict):
        from .providers.deepseek import DeepSeekProvider

        provider = DeepSeekProvider()
        provider.spec = self._openai_factory(payload).spec
        return provider

    def _ollama_factory(self, payload: dict):
        from .providers.ollama import OllamaProvider

        provider = OllamaProvider()
        provider.spec = self._openai_factory(payload).spec
        return provider

    # ── chat ───────────────────────────────────────────────────────────────────

    def ask(self, request: ChatRequest):
        """Start one turn and subscribe to its durable event log.

        The turn runs on its own thread (``_run_turn``); this generator only reads what the log
        already holds and waits for more. Closing it — a page reload, a conversation switch, a
        dropped SSE — ends the SUBSCRIPTION, not the turn: the answer still lands, and
        ``turn_events(after=last_seq)`` replays it later.

        An answer reuses the paused turn's id (``request.turn_id``): the answer is a tool result of
        that same turn, not a second one, which is what lets a client rebuild the transcript from
        one id.
        """
        account = self._resolve_account(request)
        if not request.conversation_id:
            request.conversation_id = self.store.create_conversation(
                account, title=request.text[:40] or 'New conversation'
            )['id']
        mailbox_id = str(request.context_payload.get('mailbox_id') or '')
        if mailbox_id:
            queued = self.store.take_inbox(mailbox_id, account)
            if not queued or queued['conversation_id'] != request.conversation_id:
                raise AIError('turn.unknownMailbox', kind='not_found', key='turn.unknownMailbox', reason=mailbox_id)
            self._follow_queued(request, queued.get('payload') or {})
        elif not request.turn_id and self.store.pending_calls(request.conversation_id, account):
            # A question is waiting. Starting another turn would leave its tool_use unanswered and
            # providers reject that, so the message waits in the mailbox instead of cancelling the
            # question the user still sees. The client sends it back with the mailbox id (and its
            # own key) once the question is answered.
            queued = self.store.enqueue_turn(request.conversation_id, account, self._queued_payload(request))
            yield {'v': EVENT_PROTOCOL, 'type': 'notice', 'key': 'turn.queued', 'mailbox_id': queued['id']}
            yield {'v': EVENT_PROTOCOL, 'type': 'done', 'stop_reason': 'queued'}
            return
        start_after = self.store.last_turn_event_seq(request.turn_id) if request.turn_id else 0
        turn_id = self._open_turn(request, account)
        cancel = threading.Event()
        if request.cancel_event is None:
            request.cancel_event = cancel
        with self._lock:
            self._active[turn_id] = request.cancel_event
            self._active_conversation[request.conversation_id] = turn_id
        thread = threading.Thread(target=self._run_turn, args=(request,), name=f'turn-{turn_id}', daemon=True)
        with self._lock:
            self._threads[turn_id] = thread
        thread.start()
        # An answer continues a turn the caller already has: stream only what is NEW after the
        # events it has read. A fresh turn starts at zero.
        yield from self.subscribe(turn_id, start_after)

    def _resolve_account(self, request: ChatRequest) -> str:
        """The host's signed-in account is the default; an explicit request account still wins."""
        if not request.account or request.account == 'default':
            host_account = ''
            try:
                host_account = str(self.host.account() or '')
            except Exception:
                pass
            request.account = host_account or request.account or 'default'
        return request.account

    @staticmethod
    def _queued_payload(request: ChatRequest) -> dict:
        """What the mailbox keeps. Never the key, never attachment bytes."""
        return {
            'text': request.text,
            'provider': request.provider,
            'model': request.model,
            'skill': request.skill,
            'context': {key: value for key, value in request.context_payload.items() if key != 'mailbox_id'},
        }

    @staticmethod
    def _follow_queued(request: ChatRequest, payload: dict) -> None:
        """Run a queued message: the request's own fields win, the stored ones fill the gaps."""
        request.text = request.text or str(payload.get('text') or '')
        request.provider = request.provider or str(payload.get('provider') or '')
        request.model = request.model or str(payload.get('model') or '')
        request.skill = request.skill or str(payload.get('skill') or '')
        merged = dict(payload.get('context') or {})
        merged.update(request.context_payload)
        request.context_payload = merged

    def _open_turn(self, request: ChatRequest, account: str) -> str:
        """Create the turn row, or reopen the paused one an answer belongs to."""
        if request.turn_id:
            turn = self.store.get_turn(request.turn_id, account)
            if not turn:
                raise AIError('turn.unknown', kind='not_found', key='turn.unknown', reason=request.turn_id)
            if turn['state'] != 'awaiting_user':
                raise AIError('turn.notAwaiting', kind='refused', key='turn.notAwaiting', reason=turn['state'])
            # The answer resumes the SAME turn: awaiting_user -> streaming is the declared move.
            TURN.require('awaiting_user', 'streaming')
            self.store.set_turn_state(request.turn_id, 'streaming')
            return request.turn_id
        request.turn_id = new_id('turn')
        self.store.create_turn(
            request.turn_id,
            request.conversation_id,
            account,
            provider=request.provider or '',
            model=request.model or '',
            skill=request.skill or '',
        )
        return request.turn_id

    def _run_turn(self, request: ChatRequest) -> None:
        """Drive one turn to its end on a background thread, then record the outcome.

        This is the only writer of a turn's terminal state. The host's alert hook runs BEFORE that
        write, so a subscriber that sees the turn ended also knows the popup was handed over.
        """
        turn_id = request.turn_id
        # A background thread inherits no host context: the host binds its account tree here.
        try:
            self.host.bind_account(request.account, getattr(request, 'lang', '') or '')
        except Exception:
            pass
        outcome = _TurnOutcome()
        final = 'settled'
        try:
            for raw in self.agent.run(request):
                item = {'v': EVENT_PROTOCOL, **raw}
                outcome.observe(item)
                self._record_event(turn_id, item)
                self._publish()
                self._consume_commands(turn_id, request)
        except Exception as exc:
            outcome.error = str(getattr(exc, 'message', '') or exc) or exc.__class__.__name__
            self.store.append_turn_event(
                turn_id,
                {
                    'v': EVENT_PROTOCOL,
                    'type': 'error',
                    'kind': str(getattr(exc, 'kind', 'error')),
                    'key': str(getattr(exc, 'key', '')),
                    'message': outcome.error,
                    'fields': dict(getattr(exc, 'fields', {}) or {}),
                },
            )
            final = 'interrupted'
        else:
            final = 'awaiting_user' if outcome.paused_reason else 'settled'
        finally:
            self._report_turn(request, outcome)
            self._handoff_unused_steer(request)
            if final == 'settled':
                self.store.set_turn_state(turn_id, 'settled', stop_reason=outcome.stop_reason)
            elif final == 'awaiting_user':
                self.store.set_turn_state(turn_id, 'awaiting_user')
            else:
                self.store.set_turn_state(turn_id, 'interrupted', error=outcome.error)
            with self._lock:
                self._active.pop(turn_id, None)
                self._threads.pop(turn_id, None)
                if self._active_conversation.get(request.conversation_id) == turn_id:
                    self._active_conversation.pop(request.conversation_id, None)
            self._publish()

    def subscribe(self, turn_id: str, after: int = 0):
        """Yield a turn's events from ``after``, waiting for the runner; end when it stops.

        A client reattaches with ``after=last_seq``: the log is the only source, so a reconnect
        cannot skip an event or repeat one. The generator ends when the turn settles or waits for
        the user; it raises the named error a failed turn recorded before it ends.
        """
        cursor = int(after or 0)
        while True:
            for item in self.store.turn_events(turn_id, cursor):
                cursor = item['seq']
                yield item
            turn = self.store.get_turn(turn_id)
            state = str(turn.get('state') or '')
            if state in TURN.terminals or state == 'awaiting_user':
                # Drain once more: the runner appends the last event before it writes the state.
                for item in self.store.turn_events(turn_id, cursor):
                    cursor = item['seq']
                    yield item
                if state == 'interrupted':
                    failure = self._error_event(turn_id)
                    if failure:
                        raise AIError(
                            str(failure.get('message') or 'error'),
                            kind=str(failure.get('kind') or 'error'),
                            key=str(failure.get('key') or ''),
                            **(failure.get('fields') or {}),
                        )
                return
            with self._lock:
                running = turn_id in self._active
            if not running:
                # Nothing in this process can advance this turn (a replay of a turn whose runner is
                # gone). Return what the log holds instead of waiting forever.
                return
            with self._events:
                self._events.wait(0.25)

    def _error_event(self, turn_id: str) -> dict:
        for item in reversed(self.store.turn_events(turn_id)):
            if item.get('type') == 'error':
                return item
        return {}

    def _publish(self) -> None:
        """Wake every subscription waiting on a turn's log."""
        with self._events:
            self._events.notify_all()

    def _consume_commands(self, turn_id: str, request: ChatRequest) -> None:
        """A stop/steer issued while the runner was between rounds is as real as the in-memory one."""
        for kind, payload in self.store.take_turn_commands(turn_id):
            if kind == 'stop' and request.cancel_event is not None:
                setter = getattr(request.cancel_event, 'set', None)
                if callable(setter):
                    setter()
            elif kind == 'steer':
                text = str(payload.get('text') or '').strip()
                if text:
                    request.context_payload.setdefault('steer', []).append(text)

    def _record_event(self, turn_id: str, item: dict) -> None:
        """Append one event and move the turn's state forward when the event declares a move.

        Terminal and user-waiting states are the runner's to write (after the host's alert), so a
        subscription never returns before the notification was handed over.
        """
        self.store.append_turn_event(turn_id, item)
        if item.get('type') == 'meta':
            self.store.set_turn_origin(
                turn_id,
                provider=str(item.get('provider') or ''),
                model=str(item.get('model') or ''),
                skill=str(item.get('skill') or ''),
            )
        target = EVENT_STATES.get(str(item.get('type') or ''))
        if not target:
            return
        state = str(self.store.get_turn(turn_id).get('state') or '')
        if not state or state == target or not TURN.allows(state, target):
            return
        self.store.set_turn_state(turn_id, target)

    def turn(self, turn_id: str, account: str = '') -> dict:
        """One turn row: state, stop reason, provider/model/skill — what a reattaching client needs."""
        return self.store.get_turn(turn_id, account)

    def _handoff_unused_steer(self, request: ChatRequest) -> None:
        """Guidance that arrived after the last safe boundary becomes the next message, not a loss."""
        pending = request.context_payload.pop('steer', None) or []
        if isinstance(pending, str):
            pending = [pending]
        for text in pending:
            text = str(text).strip()
            if text:
                self.store.enqueue_turn(request.conversation_id, request.account, {'text': text})

    def turn_events(self, turn_id: str, after: int = 0) -> list[dict]:
        """The durable event log, after ``after`` — the reattach path (``after=last_seq``)."""
        return self.store.turn_events(turn_id, after)

    def steps(self, turn_id: str, account: str = '') -> list[dict]:
        """The durable tool steps of one turn: what ran, its result, and a crash's leftover."""
        if not self.store.get_turn(turn_id, account):
            return []
        return self.store.steps(turn_id)

    def traces(self, turn_id: str, account: str = '') -> list[dict]:
        """OTel-GenAI-shaped spans of one turn: ids, names, status, tokens — never content."""
        if not self.store.get_turn(turn_id, account):
            return []
        return self.tracing.spans(turn_id)

    def trace_tree(self, turn_id: str, account: str = '') -> dict:
        """Spans nested by parent; a tool call sits under the provider call that asked for it."""
        if not self.store.get_turn(turn_id, account):
            return {'turn_id': turn_id, 'spans': [], 'roots': []}
        return self.tracing.tree(turn_id)

    def pending(self, conversation_id: str, account: str = '') -> list[dict]:
        """Unanswered interrupts of one conversation. Survives a restart; answering is idempotent."""
        return self.store.pending_calls(conversation_id, account)

    def inbox(self, conversation_id: str, account: str = '') -> list[dict]:
        """Messages that arrived while a question waited. Each runs when sent back with its id."""
        return self.store.inbox(conversation_id, account)

    def _report_turn(self, request: ChatRequest, outcome: _TurnOutcome) -> None:
        """Hand one settled turn to the host's alert hook; a broken host hook never breaks a turn."""
        try:
            self.host.turn_finished(outcome.summary(request))
        except Exception:
            # Deliberately swallowed: the answer is already produced and stored, and a desktop
            # popup that cannot be drawn must not turn it into an error the user sees. The host's
            # own log carries its failure; the engine has no second place to report it.
            pass

    def ask_text(
        self,
        text: str,
        *,
        account: str = 'default',
        conversation_id: str = '',
        skill: str = '',
        provider: str = '',
        api_key: str = '',
        **kwargs,
    ) -> tuple[list[dict], str]:
        """Convenience for tests and simple hosts: return all events and the assistant text."""
        request = ChatRequest(
            text=text,
            account=account,
            conversation_id=conversation_id,
            skill=skill,
            provider=provider,
            api_key=api_key,
            **kwargs,
        )
        events = list(self.ask(request))
        answer = ''.join(str(item.get('text') or '') for item in events if item.get('type') == 'text_delta')
        return events, answer

    def chat_once(self, provider_id: str, model: str, api_key: str, prompt: str, **kwargs) -> str:
        """One non-streaming prompt for row analyzers — no conversation rows, one provider call."""
        return self.catalog.chat_once(provider_id, model, api_key, prompt, **kwargs)

    def retry(self, conversation_id: str, account: str = 'default', api_key: str = ''):
        """Re-run the last user turn as a NEW paid run — no second user row, budget re-checked.

        The provider/model/skill come from the turn the user row belongs to: a retry must reproduce
        the original run, not today's defaults. The original context block is replayed from the row
        itself, so no context source is re-read for a run that already has its bytes.
        """
        last = self.store.last_message(conversation_id, 'user')
        if not last:
            raise AIError('retry.noUserTurn', kind='not_found', key='retry.noUserTurn', reason=conversation_id)
        origin = self.store.get_turn(str(last.get('turn_id') or ''), account)
        request = ChatRequest(
            text='',
            conversation_id=conversation_id,
            account=account,
            api_key=api_key,
            provider=str(origin.get('provider') or ''),
            model=str(origin.get('model') or ''),
            skill=str(origin.get('skill') or ''),
            context_payload={'resume_mode': True, 'retry': True},
        )
        return self.ask(request)

    def answer(
        self,
        conversation_id: str,
        call_id: str,
        answers,
        *,
        account: str = 'default',
        custom: str = '',
        api_key: str = '',
    ):
        """Resume a paused turn. The answer is a tool result, never a new user message.

        The interrupt is looked up in the store, so it survives a restart, a conversation switch
        and a page reload. ``turn_id`` comes from that row: the answer resumes the same turn. The
        runner claims the row when it executes, so two clicks cannot execute the approved tool
        twice; the loser is refused by name (``question.unknown``). ``api_key`` is passed again
        because a key is never stored.
        """
        pending = self.store.get_pending_call(call_id, account)
        if not pending or pending.get('conversation_id') != conversation_id:
            raise AIError('question.unknown', kind='not_found', key='question.unknown', reason=call_id)
        payload = {'call_id': call_id}
        if isinstance(answers, dict):
            payload.update(answers)
            if custom:
                payload['custom'] = custom
        request = ChatRequest(
            text='',
            conversation_id=conversation_id,
            turn_id=pending.get('turn_id') or '',
            account=account,
            provider=pending.get('provider') or '',
            model=pending.get('model') or '',
            skill=pending.get('skill') or '',
            api_key=api_key,
            answers=payload,
            resume_call_id=call_id,
        )
        return self.ask(request)

    def steer(self, conversation_id: str, text: str) -> bool:
        """Insert guidance into the RUNNING turn of one conversation at its next safe boundary.

        The engine applies it between provider rounds, where a user row cannot split a tool_call
        from its result. Guidance that arrives after the last boundary is not dropped: the runner
        hands it to the mailbox as the next message. ``False`` means no runner is live.
        """
        text = str(text or '').strip()
        if not text:
            return False
        with self._lock:
            turn_id = self._active_conversation.get(conversation_id) or ''
        if not turn_id:
            return False
        self.store.add_turn_command(turn_id, 'steer', {'text': text})
        return True

    def stop(self, conversation_id: str) -> bool:
        """Ask the running turn of one conversation to stop at its next safe boundary.

        The command is written durably first, so a runner between rounds still sees it even if the
        in-memory event were lost; the event then makes the run loop's next round check observe the
        stop. A conversation with no live runner reports ``False``.
        """
        with self._lock:
            turn_id = self._active_conversation.get(conversation_id) or ''
            event = self._active.get(turn_id) if turn_id else None
        if event is None:
            return False
        self.store.add_turn_command(turn_id, 'stop', {})
        setter = getattr(event, 'set', None)
        if callable(setter):
            setter()
        return True

    # ── bootstrap / catalog ────────────────────────────────────────────────────

    def bootstrap(self, account: str = 'default', provider_id: str = '') -> dict:
        provider_id = provider_id or self.catalog.default_id()
        provider = self.catalog.get(provider_id, account)
        # Declared models, never a live fetch: bootstrap paints the panel, and a bootstrap that
        # blocks on the provider's /models endpoint made every page load a network round trip (and
        # made an offline panel impossible). The picker refreshes a local daemon separately.
        models = [model.to_dict() for model in provider.spec.models] if provider is not None else []
        return {
            'ok': True,
            'providers': self.catalog.available(account, scopes=self.scopes),
            'default_provider': provider_id,
            'models': models,
            'skills': self.skills.list(account, provider_id),
            'tools': self.tools.schemas(),
            'conversations': self.store.list_conversations(account, limit=20),
            'memories': self.store.list_memories(account),
            'runtime': self.host.environment().capabilities(),
            'settings': self.settings.all(),
            'settings_schema': config.schema(),
            'monitors': self.monitors.list(account),
            'python': python_runtime.status(self.settings),
            'workspace': self.workspace(account).describe(),
            'scripts': self.library.all(account),
        }

    def providers(self, account: str = 'default') -> list[dict]:
        return self.catalog.available(account, scopes=self.scopes)

    def models(self, provider_id: str, api_key: str = '', account: str = 'default') -> list[dict]:
        self.catalog.require(provider_id, account)
        return self.catalog.list_models(provider_id, api_key, str(self.host.data_dir()))

    def test_provider(self, provider_id: str, model: str = '', api_key: str = '', account: str = 'default') -> dict:
        """One tiny round trip, reported the way a settings panel shows it: model, latency, reply."""
        provider = self.catalog.require(provider_id, account)
        chosen = model or (provider.spec.models[0].id if provider.spec.models else '')
        pieces = []
        started = time.monotonic()
        for item in provider.stream(
            {
                'model': chosen,
                'api_key': api_key,
                'system': 'You are a connection test.',
                'messages': [{'role': 'user', 'content': 'Reply with exactly: OK'}],
                'tools': [],
                'thinking': False,
                'web_search': False,
                'safety': 'high',
                'title': False,
                'max_tokens': 24,
                'timeout': 45,
                'cancel_event': None,
            }
        ):
            if item.get('type') == 'text_delta':
                pieces.append(str(item.get('text') or ''))
            if item.get('type') == 'done':
                break
        return {
            'ok': True,
            'provider': provider_id,
            'model': chosen,
            'latency_ms': int((time.monotonic() - started) * 1000),
            'reply': ''.join(pieces).strip()[:80],
        }

    def balance(self, provider_id: str, api_key: str = '', account: str = 'default') -> dict:
        provider = self.catalog.require(provider_id, account)
        value = provider.balance(api_key)
        if value is None:
            raise AIError('provider.noBalance', kind='capability', key='provider.noBalance', reason=provider_id)
        return {'ok': True, 'provider': provider_id, **value}

    # ── conversations ──────────────────────────────────────────────────────────

    def conversations(
        self, account: str, *, query: str = '', archived: bool = False, limit: int = 50, offset: int = 0
    ) -> list[dict]:
        return self.store.list_conversations(account, query=query, archived=archived, limit=limit, offset=offset)

    def patch_conversation(self, conversation_id: str, account: str, **fields) -> dict:
        return self.store.patch_conversation(conversation_id, account, **fields)

    def delete_conversation(self, conversation_id: str, account: str) -> bool:
        self.approvals.revoke(conversation_id)
        return self.store.delete_conversation(conversation_id, account)

    def export_conversation(self, conversation_id: str, account: str, fmt: str = 'json') -> str:
        return self.store.export_conversation(conversation_id, account, fmt)

    def messages(self, conversation_id: str) -> list[dict]:
        return self.store.list_messages(conversation_id)

    # ── memories / artifacts ───────────────────────────────────────────────────

    def add_memory(self, account: str, text: str) -> dict:
        try:
            return self.store.add_memory(account, text)
        except ValueError as exc:
            raise AIError(str(exc), kind='refused', key=str(exc)) from exc

    def delete_memory(self, account: str, memory_id: str) -> bool:
        return self.store.delete_memory(account, memory_id)

    def artifacts(self, account: str, conversation_id: str = '') -> list[dict]:
        return self.store.list_artifacts(account, conversation_id)

    def apply_artifact(self, account: str, artifact_id: str) -> dict:
        artifact = self.store.get_artifact(artifact_id)
        if not artifact or artifact.get('account') != account:
            raise AIError('artifact.unknown', kind='not_found', key='artifact.unknown', reason=artifact_id)
        problems = self.artifact_registry.problems(artifact['kind'], artifact['payload'])
        if problems:
            # Validation happens again at the apply step: the payload is what it is NOW, and a host
            # must never be handed something the model produced that fails its own contract.
            raise AIError(
                'artifact.invalid',
                kind='refused',
                key='artifact.invalid',
                reason=str(artifact.get('kind') or ''),
                problems=problems,
            )
        result = self.host.apply_artifact(artifact['kind'], artifact['payload'])
        self.store._run("UPDATE artifacts SET status='applied' WHERE id=?", (artifact_id,))
        return {'ok': True, 'artifact_id': artifact_id, 'result': result}

    # ── context / usage / files / references ───────────────────────────────────

    def context_preview(self, query: str, account: str = 'default', payload: dict | None = None) -> dict:
        return self.context.preview(query, account, payload)

    def usage(self, conversation_id: str) -> dict:
        return self.costs.conversation_cost(conversation_id)

    def add_file(
        self,
        account: str,
        name: str,
        path: str = '',
        size: int = 0,
        conversation_id: str = '',
        meta: dict | None = None,
    ) -> dict:
        return self.store.add_file(account, name, path, size, conversation_id, meta)

    def files(self, account: str, conversation_id: str = '') -> list[dict]:
        return self.store.list_files(account, conversation_id)

    def delete_file(self, account: str, file_id: str) -> bool:
        return self.store.delete_file(account, file_id)

    def reference_candidates(self, account: str, query: str = '') -> list[dict]:
        return self.references.candidates(account, query)

    # ── python script library ──────────────────────────────────────────────────

    def scripts(self, account: str) -> list[dict]:
        return self.library.all(account)

    def get_script(self, account: str, script_id: str) -> dict:
        return self.library.get(account, script_id)

    def save_script(self, account: str, payload: dict) -> dict:
        return self.library.save(account, payload)

    def fork_script(self, account: str, script_id: str) -> dict:
        return self.library.fork(account, script_id)

    def delete_script(self, account: str, script_id: str) -> bool:
        return self.library.delete(account, script_id)

    # ── settings / skills / plugins / monitors ─────────────────────────────────

    def set_setting(self, key: str, value) -> dict:
        self.settings.set(key, value)
        return {'key': key, 'value': self.settings.get(key)}

    # ── commands (/status /skills /mode /compact + host verbs) ────────────────

    def command(
        self, name: str, *, account: str = 'default', conversation_id: str = '', args: list | None = None
    ) -> dict:
        """Run one slash command; it returns data, never a stream and never a paid call by itself."""
        result = self.commands.run(
            name,
            {'account': account, 'conversation_id': conversation_id, 'args': list(args or [])},
        )
        return {'ok': True, 'command': str(name or '').strip().lstrip('/'), 'result': result}

    def _stored_mode(self, account: str, conversation_id: str) -> str:
        if not conversation_id:
            return 'build'
        mode = str(self.store.get_pref(account, f'agent_mode:{conversation_id}', 'build') or 'build').lower()
        return mode if mode in ('build', 'plan') else 'build'

    def _command_status(self, payload: dict) -> dict:
        account = str(payload.get('account') or 'default')
        conversation_id = str(payload.get('conversation_id') or '')
        conversation = self.store.get_conversation(conversation_id, account) if conversation_id else {}
        turns = self.store.list_turns(conversation_id, account, limit=5) if conversation_id else []
        latest = turns[0] if turns else {}
        return {
            'conversation': {'id': conversation.get('id', ''), 'title': conversation.get('title', '')},
            'turn': {key: latest.get(key) for key in ('id', 'state', 'stop_reason', 'provider', 'model', 'skill')}
            if latest
            else {},
            'recent_turns': len(turns),
            'pending': len(self.store.pending_calls(conversation_id, account)) if conversation_id else 0,
            'inbox': len(self.store.inbox(conversation_id, account)) if conversation_id else 0,
            'usage': self.costs.conversation_cost(conversation_id) if conversation_id else {},
            'mode': self._stored_mode(account, conversation_id),
        }

    def _command_skills(self, payload: dict) -> dict:
        account = str(payload.get('account') or 'default')
        skills = self.skills.list(account)
        return {'skills': [item.get('id', '') if isinstance(item, dict) else str(item) for item in skills]}

    def _command_mode(self, payload: dict) -> dict:
        account = str(payload.get('account') or 'default')
        conversation_id = str(payload.get('conversation_id') or '')
        args = payload.get('args') or []
        current = self._stored_mode(account, conversation_id)
        if not args:
            return {'modes': ['build', 'plan'], 'current': current}
        mode = str(args[0] or '').lower()
        if mode not in ('build', 'plan'):
            raise AIError('mode.unknown', kind='refused', key='mode.unknown', reason=mode)
        if conversation_id:
            self.store.set_pref(account, f'agent_mode:{conversation_id}', mode)
        return {'modes': ['build', 'plan'], 'current': mode}

    def _command_compact(self, payload: dict) -> dict:
        """Drop the replayed context block of older user rows, keeping the transcript itself.

        Compaction here is deterministic — no model call, no rewritten history. The rows, answers and
        tool results stay; what stops being resent is the context block of everything but the last
        ``keep`` user turns.
        """
        conversation_id = str(payload.get('conversation_id') or '')
        if not conversation_id:
            raise AIError('command.needsConversation', kind='refused', key='command.needsConversation')
        args = payload.get('args') or []
        try:
            keep = int(args[0]) if args else 6
        except (TypeError, ValueError):
            raise AIError('command.badArgs', kind='refused', key='command.badArgs', reason=str(args[0])) from None
        keep = max(1, min(keep, 50))
        users = [row for row in self.store.list_messages(conversation_id) if row.get('role') == 'user']
        older = users[:-keep] if len(users) > keep else []
        for row in older:
            meta = dict(row.get('meta') or {})
            if not meta.get('context_text'):
                continue
            meta['context_text'] = ''
            meta['compacted'] = True
            self.store.update_message(row['id'], meta=meta)
        return {'cleared': len(older), 'kept': min(len(users), keep), 'user_turns': len(users)}

    def save_skill(self, account: str, manifest: dict) -> dict:
        return self.skills.save_user(account, manifest)

    def fork_skill(self, account: str, skill_id: str) -> dict:
        return self.skills.fork(account, skill_id)

    def delete_skill(self, account: str, skill_id: str) -> bool:
        return self.skills.delete_user(account, skill_id)

    def install_plugin(self, manifest: dict, account: str, *, admin: bool = False) -> dict:
        return self.plugins.install(manifest, account, admin=admin)

    def plugins_list(self) -> list[dict]:
        return self.plugins.list()

    def toggle_plugin(self, plugin_id: str, account: str, enabled: bool) -> dict:
        return self.plugins.enable(plugin_id, account, enabled=enabled)

    def uninstall_plugin(self, plugin_id: str, account: str = '') -> bool:
        return self.plugins.uninstall(plugin_id, account)

    def arm_monitor(self, account: str, conversation_id: str, conditions: dict) -> dict:
        return self.monitors.arm(account, conversation_id, conditions)

    def monitors_list(self, account: str) -> list[dict]:
        return self.monitors.list(account)

    def stop_monitor(self, account: str, monitor_id: str) -> bool:
        return self.monitors.stop(account, monitor_id)

    def publish_event(self, name: str, payload: dict) -> None:
        bus = self.host.event_bus()
        if bus is None:
            raise AIError('events.unavailable', kind='capability', key='events.unavailable')
        bus.publish(name, payload)

    def close(self) -> None:
        """Stop the live turns and their runners before the store goes away.

        A running turn owns a thread that writes to the store; closing the connection or deleting
        a temp data root underneath it is a use-after-free. A close asks every live turn to stop,
        then waits for its thread, so teardown cannot race a write.
        """
        with self._lock:
            events = list(self._active.values())
            threads = list(self._threads.values())
        for event in events:
            setter = getattr(event, 'set', None)
            if callable(setter):
                setter()
        for thread in threads:
            thread.join(timeout=5.0)
        self.store.close()


# A shorter alias for hosts that prefer the domain name.
WorkspaceService = AgentWorkspace
