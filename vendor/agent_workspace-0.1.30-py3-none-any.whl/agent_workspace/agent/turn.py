"""One turn: the loop that spends the model's money and writes what it said.

The turn is several assistant rows, not one. Each provider round opens a ``streaming`` row BEFORE the
first byte is read (a kill leaves a row the next boot settles as ``interrupted``, never an answer
that vanished), accumulates deltas into blocks, settles the row, and then runs the tool calls the
round asked for — each followed immediately by its result, all grouped by ``turn_id``.

The order in here is the contract: the pause/stop checks and the steer boundary sit BETWEEN rounds,
where appending a row cannot split a ``tool_call`` from its ``tool_result``.
"""

from __future__ import annotations

import json
import time

from ..errors import AIError, WorkspaceError
from ..providers.base import replay_context
from ..types import ChatRequest, message_text, new_id, text_block, thinking_block, tool_use_block
from ..util import estimate_tokens, event
from .dispatch import QUESTION_TOOLS
from .limits import PERSIST_EVERY_SECONDS


def routed_skill(services, text: str, account: str, provider_id: str, model: str):
    """The skill an automatic turn starts in: the router's pick, or ``general`` when unusable.

    An automatic turn must never fail because the router chose a skill this host cannot run (a
    cloud-refused local skill, an unknown tool, a capability the provider lacks) — the user did not
    choose it, so the honest answer is the general skill, and the meta block still says which id
    the router wanted.
    """
    chosen = services.skills.route(text, account) if str(text or '').strip() else 'general'
    skill = services.skills.get(chosen, account)
    if skill is None:
        return services.skills.get('general', account)
    available, _reason = services.skills.availability(skill, provider_id, model)
    return skill if available else services.skills.get('general', account)


class TurnMixin:
    def run(self, request: ChatRequest):
        services = self.services
        store = services.store
        account = request.account or 'default'
        conversation_id = request.conversation_id
        conversation = store.get_conversation(conversation_id, account)
        if not conversation:
            conversation = store.create_conversation(account, title='', conversation_id=conversation_id)
            conversation_id = conversation['id']
            yield event('conversation', conversation_id=conversation_id)
        request.conversation_id = conversation_id
        resuming = bool(request.context_payload.get('resume_mode'))
        retrying = bool(request.context_payload.get('retry'))

        turn_id = request.turn_id or new_id('turn')
        cancel = request.cancel_event
        provider_id = request.provider or services.catalog.default_id()
        provider = services.catalog.get(provider_id, account)
        if provider is None:
            raise AIError('provider.unknown', kind='refused', key='provider.unknown', reason=provider_id)
        configured_model = str(services.settings.get('chat.default_model', '') or '')
        model = (
            request.model
            or configured_model
            or (provider.spec.models[0].id if provider.spec.models else '')
            or services.catalog.default_model(provider_id, request.api_key, request.host)
        )
        # Pin the RESOLVED provider/model on the request: the turn row, the interrupt row and the
        # tool context all read them, and a restart must resume the same model, not today's default.
        request.provider = provider_id
        request.model = model

        if request.thinking and not provider.supports('thinking', model):
            raise AIError(
                'capability.refused',
                kind='capability',
                key='capability.refused',
                reason=services.t('workspace.refusal.capability', capability='thinking'),
            )
        if request.output_schema and not provider.supports('structured_output', model):
            raise AIError(
                'capability.refused',
                kind='capability',
                key='capability.refused',
                reason=services.t('workspace.refusal.capability', capability='structured_output'),
            )
        if request.answers is not None:
            yield from self._resume(request, conversation_id, account, turn_id, provider, model)
            return

        # A paused question the user never answered leaves an assistant tool_use in the transcript.
        # Providers (Ollama included) reject a tool_call without its tool_result, so a NEW user turn
        # must first settle any pending call with an explicit "skipped" result. The interrupt rows
        # travel through the store so the decision (and the reason) survives a restart too.
        for info in store.pending_calls(conversation_id, account):
            if not store.claim_pending_call(info['call_id'], account):
                continue
            self._persist_tool_result(
                conversation_id, turn_id, info['call_id'], info.get('tool') or 'question', {'skipped': True}, False
            )

        if retrying:
            previous = store.last_message(conversation_id, 'user')
            text = message_text(previous) if previous else ''
            if not text:
                raise AIError('retry.noUserTurn', kind='not_found', key='retry.noUserTurn', reason=conversation_id)
            # The row already carries its own context block; replay_context() puts it back for the
            # provider. Re-reading live sources would describe TODAY, not the run being reproduced.
            replay_text = str((previous.get('meta') or {}).get('context_text') or '')
            context_meta = {'retried': True, 'context_restored': bool(replay_text)}
        elif resuming:
            previous = store.last_message(conversation_id, 'user')
            text = message_text(previous) if previous else ''
            replay_text = str((previous.get('meta') or {}).get('context_text') or '')
            context_meta = {'resumed': True}
        else:
            text = request.text
            context_text, context_meta = services.context.build(text, account, request.context_payload)
            replay_text, replay_meta = services.context.for_replay(context_text)
            context_meta.update(replay_meta)

        requested_skill = str(request.skill or '').strip()
        if requested_skill in ('', 'auto'):
            skill = routed_skill(services, text, account, provider_id, model)
        else:
            skill = services.skills.get(requested_skill, account)
        if skill is None:
            raise AIError('skill.unknown', kind='refused', key='skill.unknown', reason=request.skill)
        request.skill = skill.id
        if requested_skill in ('', 'auto'):
            # The turn says which expert mode auto chose, so the transcript's skill row and the
            # inspector answer "why did it answer like this?" without a second request.
            context_meta['skill'] = {'requested': requested_skill or 'auto', 'chosen': skill.id}
        available, reason = services.skills.availability(skill, provider_id, model)
        if not available:
            raise AIError('skill.unavailable', kind='capability', key='skill.unavailable', reason=reason)
        if request.web_search is None:
            request.web_search = bool(services.settings.get('chat.web_search_default', True))
        if request.web_search and provider.supports('web_search', model):
            context_meta['web_search'] = True
        mode = self._mode(request, services, account, conversation_id)

        yield event(
            'meta',
            conversation_id=conversation_id,
            turn_id=turn_id,
            skill=skill.id,
            provider=provider_id,
            model=model,
            mode=mode or 'build',
            context=context_meta,
        )
        if not (resuming or retrying):
            yield from self._user_row(conversation_id, turn_id, text, replay_text, account, provider, model, request)

        allowed = set(skill.tools) | set(services.host.universal_tools() or ())
        if mode == 'plan':
            # Planning is a read-only surface: a write or an always-ask tool is not only hidden from
            # the schema list, it is removed from the offer list, so a replayed history cannot smuggle
            # one past the mode either (``_dispatch`` refuses anything outside ``allowed``).
            allowed = {name for name in allowed if not self._is_write_tool(services.tools.get(name, account))}
        base_allowed = set(allowed)
        chat_only = bool(request.context_payload.get('chat_only'))
        disable_questions = bool(request.context_payload.get('disable_questions'))
        # A recipe run lives on the conversation: an explicit id starts it, and a later turn with
        # no id still continues the live step (the UI may not resend it).
        recipe_state = services.recipes.ensure(conversation_id, account, str(request.recipe_id or ''))

        rounds = 0
        max_rounds = int(services.settings.get('tools.max_rounds', 30))
        while True:
            recipe_state = services.recipes.active(conversation_id, account) or recipe_state
            allowed = services.recipes.mask(base_allowed, recipe_state) if recipe_state else set(base_allowed)
            if chat_only:
                allowed = set()
                tool_schemas = []
            else:
                strict = bool(services.settings.get('tools.strict_local', True)) and bool(
                    getattr(provider.spec, 'local_only', False)
                )
                current_tool = (recipe_state.get('current') or {}).get('tool') if recipe_state else ''
                tool_schemas = services.tools.schemas(
                    allowed,
                    query=text,
                    limit=12 if strict else 0,
                    required=(current_tool,) if current_tool else (),
                    # The active skill's own verbs are the floor of the budget: a skill exists so that
                    # its tools are reachable, and a Chinese question ranked against English
                    # descriptions has no signal to decide with.
                    priority=tuple(getattr(skill, 'tools', ()) or ()),
                )
                context_meta['tooling'] = {
                    # `offered` counts control tools too, so `offered` > `budget` is normal and not a
                    # breach: the registry only cuts when its ranking can tell the tools apart, and
                    # control + a skill's own verbs are outside the budget by design. Read the two
                    # numbers as "how long was the list" and "what ceiling was declared".
                    'strict': strict,
                    'offered': len(tool_schemas),
                    'budget': 12 if strict else 0,
                }
                if disable_questions:
                    tool_schemas = [schema for schema in tool_schemas if schema['name'] not in QUESTION_TOOLS]
                    allowed -= set(QUESTION_TOOLS)
            if cancel is not None and getattr(cancel, 'is_set', lambda: False)():
                yield event('done', stop_reason='cancelled')
                return
            spend = services.costs.spend_state(conversation_id, account)
            if spend['exceeded']:
                yield event(
                    'error',
                    kind='budget',
                    message=services.t('workspace.budget.exceeded', scope=spend['scope'], limit=spend['limit']),
                )
                yield event('paused', reason='budget', conversation_id=conversation_id)
                return

            # A steer arrives as a command; the safe boundary is HERE, between provider rounds,
            # where appending a user row cannot split a tool_call from its result.
            for guidance in self._take_steer(request):
                store.append_message(conversation_id, turn_id, 'user', [text_block(guidance)], {'steer': True})
                yield event('steer', text=guidance)

            rows = self.repair_tool_pairs(store.list_messages(conversation_id), turn_id)
            history = self.provider_messages(rows)
            window = provider.context_window(model)
            reserved = (
                estimate_tokens(self._system(request, skill, provider, account))
                + estimate_tokens(json.dumps(tool_schemas, ensure_ascii=False))
                + int(request.max_tokens or 0)
            )
            history, history_meta = self.fit_history(history, window, reserved)
            context_meta['history'] = history_meta
            provider_messages = list(history)
            if retrying:
                # A retried turn's history ends with its previous ANSWER, so the same user words are
                # appended once more: the model is asked to answer again, not to continue itself.
                # A fresh turn ends with its stored user row, and a resume ends with a tool result —
                # appending there would duplicate the user message.
                provider_messages.append({'role': 'user', 'content': text, 'meta': {'context_text': replay_text}})
            payload = {
                'system': self._system(request, skill, provider, account),
                'messages': replay_context(provider_messages),
                'tools': tool_schemas,
                'thinking': request.thinking,
                'web_search': request.web_search,
                'safety': request.safety,
                'title': request.title,
                'max_tokens': request.max_tokens,
                'timeout': request.timeout,
                'cancel_event': cancel,
                'api_key': request.api_key,
                'host': request.host,
                'model': model,
                'user_id': account,
                'reasoning_effort': services.settings.get('chat.reasoning_effort', 'high'),
                'temperature': float(services.settings.get('chat.temperature', 0.3) or 0.3),
                'tool_mode': request.context_payload.get('tool_mode', ''),
                'output_schema': request.output_schema,
            }
            # The row exists before the first byte is read, so a crash leaves a visible answer.
            assistant_row = store.append_message(
                conversation_id,
                turn_id,
                'assistant',
                [],
                {'context_text': replay_text},
                status='streaming',
            )
            assistant_blocks: list[dict] = []
            assistant_meta: dict = {}
            tool_calls: list[dict] = []
            usage: dict = {}
            stop_reason = 'end_turn'
            title = ''
            last_flush = time.monotonic()
            span = services.tracing.start(
                turn_id=turn_id,
                conversation_id=conversation_id,
                account=account,
                kind='provider',
                name=str(provider_id),
                attributes={
                    'gen_ai.system': str(provider_id),
                    'gen_ai.operation.name': 'chat',
                    'gen_ai.request.model': model,
                    'gen_ai.request.max_tokens': int(request.max_tokens or 0),
                },
            )
            span_status = 'ok'
            try:
                for item in provider.stream(payload):
                    kind = item.get('type')
                    if kind not in ('meta', 'usage', 'done', 'title'):
                        yield item
                    if kind == 'thinking_delta':
                        assistant_blocks.append(thinking_block(item.get('text', '')))
                    elif kind == 'text_delta':
                        assistant_blocks.append(text_block(item.get('text', '')))
                    elif kind == 'tool_call':
                        call = {
                            'id': item.get('id') or new_id('call'),
                            'name': item.get('name') or '',
                            'arguments': item.get('arguments') or {},
                        }
                        tool_calls.append(call)
                        assistant_blocks.append(tool_use_block(call['id'], call['name'], call['arguments']))
                        if item.get('parse_error'):
                            assistant_meta['parse_error'] = item['parse_error']
                    elif kind == 'usage':
                        usage = item.get('usage') or {}
                    elif kind == 'title':
                        title = item.get('text', '')
                    elif kind == 'citation':
                        assistant_meta.setdefault('citations', []).append(item.get('payload') or {})
                    elif kind == 'server_tool':
                        assistant_meta.setdefault('server_tools', []).append(
                            item.get('payload') or item.get('block') or {}
                        )
                    elif kind == 'refusal':
                        assistant_meta['refusal'] = item.get('text', '')
                    elif kind == 'done':
                        stop_reason = item.get('stop_reason') or 'end_turn'
                        assistant_meta.update(
                            {key: value for key, value in item.items() if key in ('stop_reason', 'reasoning_content')}
                        )
                    if time.monotonic() - last_flush >= PERSIST_EVERY_SECONDS:
                        self._flush(assistant_row['id'], assistant_blocks, assistant_meta, 'streaming')
                        last_flush = time.monotonic()
            except WorkspaceError as exc:
                status = 'interrupted' if exc.kind in ('cancelled', 'error') else 'error'
                span_status = 'cancelled' if exc.kind == 'cancelled' else 'error'
                self._flush(assistant_row['id'], assistant_blocks, assistant_meta, status)
                if exc.kind == 'cancelled':
                    yield event('done', stop_reason='cancelled')
                else:
                    yield event('error', kind=exc.kind, message=exc.message)
                    yield event('done', stop_reason='error')
                return
            except Exception:
                span_status = 'error'
                raise
            finally:
                services.tracing.finish(
                    span,
                    status=span_status,
                    attributes={
                        'gen_ai.usage.input_tokens': int(usage.get('prompt_tokens') or 0),
                        'gen_ai.usage.output_tokens': int(usage.get('completion_tokens') or 0),
                        'gen_ai.usage.cached_tokens': int(usage.get('cached_tokens') or 0),
                        'gen_ai.response.finish_reason': str(stop_reason),
                        'tool_calls': len(tool_calls),
                    },
                )

            merged = self._merge_blocks(assistant_blocks)
            if not merged and not tool_calls:
                store.delete_message(assistant_row['id'])
            else:
                assistant_meta['context_text'] = replay_text
                if tool_calls:
                    assistant_meta['tool_calls'] = tool_calls
                self._flush(assistant_row['id'], merged, assistant_meta, 'done')
            if title and not conversation.get('title'):
                store.patch_conversation(conversation_id, account, title=title[:80])
                yield event('title', text=title[:80])
            if usage:
                yield event('usage', usage=usage)
                store.record_usage(
                    account,
                    conversation_id,
                    provider_id,
                    model,
                    int(usage.get('prompt_tokens') or 0),
                    int(usage.get('completion_tokens') or 0),
                    int(usage.get('cached_tokens') or 0),
                    int(usage.get('reasoning_tokens') or 0),
                )
            if stop_reason == 'max_tokens':
                yield event('notice', text='response.truncated', key='response.truncated')
            if not tool_calls:
                yield event('done', stop_reason=stop_reason)
                return
            final_answer = ''
            for call in tool_calls:
                dispatch = self._dispatch(
                    call,
                    request,
                    conversation_id,
                    account,
                    turn_id,
                    allowed,
                    cancel,
                    parent_span=span.get('trace_id', ''),
                )
                while True:
                    try:
                        item = next(dispatch)
                    except StopIteration as stop:
                        result = stop.value
                        break
                    # A host may return `_final_answer` from a deterministic tool. Small local
                    # models often cannot stop calling tools; the host-authored result becomes
                    # the answer and the turn ends, so correctness does not depend on the model.
                    if (
                        request.context_payload.get('auto_final_answer')
                        and item.get('type') == 'tool_result'
                        and isinstance(item.get('content'), dict)
                        and item['content'].get('_final_answer')
                        and not final_answer
                    ):
                        final_answer = str(item['content']['_final_answer'])
                    yield item
                if result == 'pause':
                    yield event('paused', reason='question', conversation_id=conversation_id)
                    return
            if final_answer:
                assistant_blocks.append(text_block(final_answer))
                self._flush(assistant_row['id'], self._merge_blocks(assistant_blocks), assistant_meta, 'done')
                yield event('text_delta', text=final_answer)
                yield event('done', stop_reason='end_turn')
                return
            rounds += 1
            if max_rounds and rounds >= max_rounds:
                yield event(
                    'question',
                    call_id=new_id('call_round'),
                    question='Continue or stop?',
                    options=['Continue', 'Stop'],
                    detail={'rounds': rounds},
                    kind='rounds',
                )
                yield event('paused', reason='rounds', conversation_id=conversation_id)
                return
