"""``@`` reference resolution: expand a host object into bounded text, never a raw path.

A reference in a prompt or in an answer to a question is resolved on the server with the same code.
The result is clipped per item and per whole round, so a large table or a long console tail can
never flood the prompt.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from .util import clip, redact

PATTERN = re.compile(r'@([a-z_]+):([A-Za-z0-9_.\-]+)')
ITEM_CHARS = 1200
TOTAL_CHARS = 6000
FILE_BYTES = 64 * 1024
TEXT_SUFFIXES = frozenset(
    {
        '.txt',
        '.md',
        '.csv',
        '.tsv',
        '.json',
        '.jsonl',
        '.log',
        '.yaml',
        '.yml',
        '.html',
        '.htm',
        '.xml',
        '.py',
        '.js',
        '.css',
        '.tex',
    }
)

#: Kinds that CHANGE the turn (a directive) rather than contribute bounded text (content).
DIRECTIVE_KINDS = frozenset({'skill'})
CONTENT_KINDS = (
    'dataset',
    'run',
    'workflow',
    'export',
    'capability',
    'file',
    'artifact',
    'conversation',
    'group',
)
KINDS = tuple(CONTENT_KINDS) + tuple(DIRECTIVE_KINDS)
#: A turn may name at most this many structured references; the character budget still binds.
MAX_REFS = 20


class References:
    def __init__(self, store, host, context, skills=None):
        self.store = store
        self.host = host
        self.context = context
        self.skills = skills

    def candidates(self, account: str, query: str = '', limit: int = 20) -> list[dict]:
        """Store-owned objects and the host's domain objects share ONE picker.

        The host declares its own candidates (a skill catalogue, saved workflows, exports); the
        framework only merges, de-duplicates and filters them, so a host adds a kind without a
        second picker implementation.
        """
        host_rows: list[dict] = [
            row for row in self.host.reference_candidates(account, query) or [] if isinstance(row, dict)
        ]
        store_rows: list[dict] = []
        for file in self.store.list_files(account):
            store_rows.append({'kind': 'file', 'id': file['id'], 'label': file['name']})
        for conv in self.store.list_conversations(account, limit=10):
            store_rows.append({'kind': 'conversation', 'id': conv['id'], 'label': conv.get('title') or conv['id']})
        for artifact in self.store.list_artifacts(account, limit=10):
            store_rows.append(
                {'kind': 'artifact', 'id': artifact['id'], 'label': f'{artifact["kind"]} · {artifact["id"]}'}
            )
        if self.skills is not None:
            for skill in self.skills.list(account):
                store_rows.append(
                    {
                        'kind': 'skill',
                        'id': skill['id'],
                        'label': skill.get('name') or skill.get('name_key') or skill['id'],
                        'detail': skill.get('group') or '',
                    }
                )
        # Interleave, never host-first: a host with many domain objects (a skill catalogue, saved
        # workflows) must not push the user's own files past the picker's limit.
        rows: list[dict] = []
        for index in range(max(len(host_rows), len(store_rows))):
            if index < len(store_rows):
                rows.append(store_rows[index])
            if index < len(host_rows):
                rows.append(host_rows[index])
        seen: set[tuple[str, str]] = set()
        unique: list[dict] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            key = (str(row.get('kind') or ''), str(row.get('id') or ''))
            if not all(key) or key in seen:
                continue
            seen.add(key)
            unique.append(row)
        if query:
            needle = query.lower()
            unique = [
                row
                for row in unique
                if needle in str(row.get('label') or '').lower()
                or needle in str(row.get('id') or '').lower()
                or needle in str(row.get('kind') or '').lower()
            ]
        return unique[:limit]

    def _file_body(self, row: dict, account: str) -> str:
        """Stored text first; a declared path only inside one of the host's roots."""
        text = str((row.get('meta') or {}).get('text') or '')
        if text:
            return text
        raw = str(row.get('path') or '')
        if not raw:
            return ''
        candidate = Path(raw).expanduser()
        if not candidate.is_file():
            return ''
        roots = [Path(root).expanduser().resolve() for root in self.host.file_roots(account)]
        resolved = candidate.resolve()
        if not any(resolved == root or root in resolved.parents for root in roots):
            return ''
        if resolved.suffix.lower() not in TEXT_SUFFIXES:
            return ''
        try:
            with resolved.open('rb') as handle:
                data = handle.read(FILE_BYTES + 1)
        except OSError:
            return ''
        return data[:FILE_BYTES].decode('utf-8', errors='replace')

    def _expand_one(self, kind: str, identifier: str, account: str) -> str:
        if kind == 'file':
            row = self.store.get_file(identifier)
            if not row or row.get('account') != account:
                return ''
            body = self._file_body(row, account)
            if not body:
                return f'文件 {row["name"]}（内容不可读）'
            return f'文件 {row["name"]}\n' + clip(redact(body), ITEM_CHARS)
        if kind == 'artifact':
            row = self.store.get_artifact(identifier)
            if not row or row.get('account') != account:
                return ''
            return f'产物 {row["kind"]}\n' + clip(json.dumps(row['payload'], ensure_ascii=False), ITEM_CHARS)
        if kind == 'conversation':
            row = self.store.get_conversation(identifier, account)
            if not row:
                return ''
            messages = self.store.list_messages(identifier, limit=6)
            from .types import message_text

            return f'会话 {row.get("title") or identifier}\n' + clip(
                '\n'.join(f'{message["role"]}: {message_text(message)}' for message in messages), ITEM_CHARS
            )
        if kind == 'dataset':
            obj = self.host.resolve_dataset(identifier)
            return self._describe(obj, f'数据集 {identifier}')
        if kind == 'run':
            obj = self.host.resolve_run(identifier)
            return self._describe(obj, f'运行 {identifier}')
        # Domain kinds the host owns: a saved workflow, an export, a capability skill. The host
        # renders its own bounded text; the framework only enforces the per-item and per-round cap.
        return str(self.host.resolve_reference(kind, identifier) or '')[:ITEM_CHARS]

    @staticmethod
    def _describe(obj, title: str) -> str:
        if obj is None:
            return ''
        if isinstance(obj, str):
            text = obj
        elif hasattr(obj, 'to_dict'):
            text = json.dumps(obj.to_dict(), ensure_ascii=False, default=str)
        else:
            try:
                text = json.dumps(dict(obj), ensure_ascii=False, default=str)
            except (TypeError, ValueError):
                text = str(obj)
        return f'{title}\n' + clip(text, ITEM_CHARS)

    def _expand_many(self, pairs: list[tuple[str, str]], account: str) -> tuple[str, list[str], list[dict]]:
        chunks: list[str] = []
        unresolved: list[str] = []
        directives: list[dict] = []
        used = 0
        seen_directives: set[str] = set()
        for kind, identifier in pairs:
            if kind not in KINDS:
                unresolved.append(f'@{kind}:{identifier}')
                continue
            if kind in DIRECTIVE_KINDS:
                if identifier not in seen_directives:
                    directives.append({'kind': kind, 'id': identifier})
                    seen_directives.add(identifier)
                continue
            body = self._expand_one(kind, identifier, account)
            if not body:
                unresolved.append(f'@{kind}:{identifier}')
                continue
            remaining = TOTAL_CHARS - used
            if remaining <= 0:
                break
            body = clip(body, remaining)
            chunks.append(body)
            used += len(body)
        return '\n\n'.join(chunks), unresolved, directives

    def resolve(self, text: str, account: str) -> tuple[str, list[str], list[dict]]:
        """Return ``(expanded_text, unresolved, directives)`` for the ``@kind:id`` tokens."""
        return self._expand_many(PATTERN.findall(str(text or '')), account)

    def resolve_rows(self, rows, account: str) -> tuple[str, list[str], list[dict]]:
        """The same expansion for the composer's structured picks (the picker writes chips, not
        tokens), so a picked reference reaches the model exactly like a typed one."""
        pairs = []
        for row in list(rows or [])[:MAX_REFS]:
            if not isinstance(row, dict):
                continue
            kind = str(row.get('kind') or '')
            identifier = str(row.get('id') or '').strip()
            if kind and identifier:
                pairs.append((kind, identifier))
        return self._expand_many(pairs, account)
