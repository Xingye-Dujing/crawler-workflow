"""The turn runner: start a turn, drive it on its own thread, publish its log, settle it.

``ask()`` creates the turn row and a background ``TurnRunner`` thread, then only SUBSCRIBES to the
durable event log. Closing the generator (a reload, a conversation switch, a dropped SSE) ends the
subscription, never the turn: the answer still lands and ``turn_events(after=last_seq)`` replays it.

Everything that decides a turn's terminal state lives here, and it is the only writer of one. The
host's finished-turn alert runs BEFORE that write, so a subscriber that sees the turn ended also knows
the notification was handed over; a broken host hook is swallowed on purpose (the answer is already
stored, and a popup that cannot be drawn is not an error the user should read).

This module is a mixin: ``AgentWorkspace`` composes it with the facade, so every public name and the
one-object contract the host codes against are unchanged.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field

from .errors import AIError
from .fsm import TURN
from .types import ChatRequest, new_id

#: The wire protocol version stamped on every event. A frontend can branch on it during a
#: migration instead of guessing from event names.
EVENT_PROTOCOL = 1

#: Which turn state an event moves the machine to. Terminal and user-waiting states are written by
#: the runner after the host's alert, so a subscription never returns before the notification. An
#: event never rewinds a turn either: a resumed turn is already streaming when its new ``meta``
#: arrives, so an illegal/backward move is recorded in the log and simply does not change the state.
EVENT_STATES = {
    'user': 'context',
    'meta': 'context',
    'text_delta': 'streaming',
    'thinking_delta': 'streaming',
    'tool_call': 'streaming',
    'tool_start': 'tool',
    'tool_result': 'streaming',
}

#: How much of the assistant's answer the finished-turn report carries. A notification is a
#: pointer, not a transcript: a host that needs the text reads the stored rows.
TURN_PREVIEW_CHARS = 240


@dataclass
class _TurnOutcome:
    """What one ``ask()`` learned about its own turn, for the host's finished-turn report."""

    turn_id: str = ''
    skills: list = field(default_factory=list)
    provider: str = ''
    model: str = ''
    stop_reason: str = ''
    paused_reason: str = ''
    error: str = ''
    text: str = ''
    tool_calls: int = 0

    def observe(self, item: dict) -> None:
        kind = str(item.get('type') or '')
        if kind == 'meta':
            self.turn_id = str(item.get('turn_id') or '')
            self.skills = list(item.get('skills') or [])
            self.provider = str(item.get('provider') or '')
            self.model = str(item.get('model') or '')
        elif kind == 'text_delta':
            self.text += str(item.get('text') or '')
        elif kind == 'tool_start':
            self.tool_calls += 1
        elif kind == 'done':
            self.stop_reason = str(item.get('stop_reason') or '')
        elif kind == 'paused':
            self.paused_reason = str(item.get('reason') or '')

    @property
    def status(self) -> str:
        """The one word a host alerts on. Paused wins: it is the state a user must act on."""
        if self.paused_reason:
            return 'paused'
        if self.stop_reason == 'cancelled':
            return 'cancelled'
        if self.stop_reason == 'error' or self.error:
            return 'error'
        if self.stop_reason:
            return 'completed'
        # A caller that stopped iterating closed the stream before any done/paused event. The turn
        # did not finish, and calling that completed would be a lie the host shows as a popup.
        return 'aborted'

    def summary(self, request: ChatRequest) -> dict:
        preview = self.text if len(self.text) <= TURN_PREVIEW_CHARS else self.text[-TURN_PREVIEW_CHARS:]
        return {
            'conversation_id': request.conversation_id,
            'turn_id': self.turn_id or request.turn_id,
            'account': request.account,
            'status': self.status,
            'stop_reason': self.stop_reason,
            'reason': self.paused_reason,
            'error': self.error,
            'skills': list(self.skills),
            'provider': self.provider,
            'model': self.model,
            'tool_calls': self.tool_calls,
            'text': preview,
        }


class TurnRunner:
    """Start, drive, publish and settle one turn. Mixed into ``AgentWorkspace``."""

    def ask(self, request: ChatRequest):
        """Start one turn and subscribe to its durable event log.

        The turn runs on its own thread (``_run_turn``); this generator only reads what the log
        already holds and waits for more. Closing it — a page reload, a conversation switch, a
        dropped SSE — ends the SUBSCRIPTION, not the turn: the answer still lands, and
        ``turn_events(after=last_seq)`` replays it later.

        An answer reuses the paused turn's id (``request.turn_id``): the answer is a tool result of
        that same turn, not a second one, which is what lets a client rebuild the transcript from
        one id.
        """
        account = self._resolve_account(request)
        if not request.conversation_id:
            request.conversation_id = self.create_conversation(account, title=request.text[:40] or 'New conversation')[
                'id'
            ]
        mailbox_id = str(request.context_payload.get('mailbox_id') or '')
        if mailbox_id:
            queued = self.store.take_inbox(mailbox_id, account)
            if not queued or queued['conversation_id'] != request.conversation_id:
                raise AIError('turn.unknownMailbox', kind='not_found', key='turn.unknownMailbox', reason=mailbox_id)
            self._follow_queued(request, queued.get('payload') or {})
        elif not request.turn_id and (
            self.store.pending_calls(request.conversation_id, account)
            or self.store.active_turn(request.conversation_id, account)
        ):
            # A question is waiting. Starting another turn would leave its tool_use unanswered and
            # providers reject that, so the message waits in the mailbox instead of cancelling the
            # question the user still sees. The client sends it back with the mailbox id (and its
            # own key) once the question is answered.
            queued = self.store.enqueue_turn(request.conversation_id, account, self._queued_payload(request))
            yield {'v': EVENT_PROTOCOL, 'type': 'notice', 'key': 'turn.queued', 'mailbox_id': queued['id']}
            yield {'v': EVENT_PROTOCOL, 'type': 'done', 'stop_reason': 'queued'}
            return
        start_after = self.store.last_turn_event_seq(request.turn_id) if request.turn_id else 0
        turn_id = self._open_turn(request, account)
        cancel = threading.Event()
        if request.cancel_event is None:
            request.cancel_event = cancel
        with self._lock:
            self._active[turn_id] = request.cancel_event
            self._active_conversation[request.conversation_id] = turn_id
        thread = threading.Thread(target=self._run_turn, args=(request,), name=f'turn-{turn_id}', daemon=True)
        with self._lock:
            self._threads[turn_id] = thread
        thread.start()
        # An answer continues a turn the caller already has: stream only what is NEW after the
        # events it has read. A fresh turn starts at zero.
        yield from self.subscribe(turn_id, start_after)

    def _resolve_account(self, request: ChatRequest) -> str:
        """The host's signed-in account is the default; an explicit request account still wins."""
        if not request.account or request.account == 'default':
            host_account = ''
            try:
                host_account = str(self.host.account() or '')
            except Exception:
                pass
            request.account = host_account or request.account or 'default'
        return request.account

    @staticmethod
    def _queued_payload(request: ChatRequest) -> dict:
        """What the mailbox keeps. Never the key, never attachment bytes."""
        return {
            'text': request.text,
            'provider': request.provider,
            'model': request.model,
            'skills': list(request.skills or []),
            'context': {key: value for key, value in request.context_payload.items() if key != 'mailbox_id'},
        }

    @staticmethod
    def _follow_queued(request: ChatRequest, payload: dict) -> None:
        """Run a queued message: the request's own fields win, the stored ones fill the gaps."""
        request.text = request.text or str(payload.get('text') or '')
        request.provider = request.provider or str(payload.get('provider') or '')
        request.model = request.model or str(payload.get('model') or '')
        if not request.skills:
            request.skills = list(payload.get('skills') or [])
        merged = dict(payload.get('context') or {})
        merged.update(request.context_payload)
        request.context_payload = merged

    def _open_turn(self, request: ChatRequest, account: str) -> str:
        """Create the turn row, or reopen the paused one an answer belongs to."""
        if request.turn_id:
            turn = self.store.get_turn(request.turn_id, account)
            if not turn:
                raise AIError('turn.unknown', kind='not_found', key='turn.unknown', reason=request.turn_id)
            if turn['state'] != 'awaiting_user':
                raise AIError('turn.notAwaiting', kind='refused', key='turn.notAwaiting', reason=turn['state'])
            # The answer resumes the SAME turn: awaiting_user -> streaming is the declared move.
            TURN.require('awaiting_user', 'streaming')
            self.store.set_turn_state(request.turn_id, 'streaming')
            return request.turn_id
        request.turn_id = new_id('turn')
        self.store.create_turn(
            request.turn_id,
            request.conversation_id,
            account,
            provider=request.provider or '',
            model=request.model or '',
            skills=list(request.skills or []),
        )
        return request.turn_id

    def _run_turn(self, request: ChatRequest) -> None:
        """Drive one turn to its end on a background thread, then record the outcome.

        This is the only writer of a turn's terminal state. The host's alert hook runs BEFORE that
        write, so a subscriber that sees the turn ended also knows the popup was handed over.
        """
        turn_id = request.turn_id
        slots = getattr(self, '_turn_slots', None)
        if slots is not None:
            slots.acquire()
        # A background thread inherits no host context: the host binds its account tree here.
        try:
            self.host.bind_account(request.account, getattr(request, 'lang', '') or '')
        except Exception:
            pass
        outcome = _TurnOutcome()
        final = 'settled'
        try:
            for raw in self.agent.run(request):
                item = {'v': EVENT_PROTOCOL, **raw}
                outcome.observe(item)
                self._record_event(turn_id, item)
                self._publish()
                self._consume_commands(turn_id, request)
        except Exception as exc:
            outcome.error = str(getattr(exc, 'message', '') or exc) or exc.__class__.__name__
            self.store.append_turn_event(
                turn_id,
                {
                    'v': EVENT_PROTOCOL,
                    'type': 'error',
                    'kind': str(getattr(exc, 'kind', 'error')),
                    'key': str(getattr(exc, 'key', '')),
                    'message': outcome.error,
                    'fields': dict(getattr(exc, 'fields', {}) or {}),
                },
            )
            final = 'interrupted'
        else:
            final = 'awaiting_user' if outcome.paused_reason else 'settled'
        finally:
            self._report_turn(request, outcome)
            self._handoff_unused_steer(request)
            if final == 'settled':
                self.store.set_turn_state(turn_id, 'settled', stop_reason=outcome.stop_reason)
            elif final == 'awaiting_user':
                self.store.set_turn_state(turn_id, 'awaiting_user')
            else:
                self.store.set_turn_state(turn_id, 'interrupted', error=outcome.error)
            with self._lock:
                self._active.pop(turn_id, None)
                self._threads.pop(turn_id, None)
                if self._active_conversation.get(request.conversation_id) == turn_id:
                    self._active_conversation.pop(request.conversation_id, None)
            if slots is not None:
                slots.release()
            self._publish()

    def subscribe(self, turn_id: str, after: int = 0):
        """Yield a turn's events from ``after``, waiting for the runner; end when it stops.

        A client reattaches with ``after=last_seq``: the log is the only source, so a reconnect
        cannot skip an event or repeat one. The generator ends when the turn settles or waits for
        the user; it raises the named error a failed turn recorded before it ends.
        """
        cursor = int(after or 0)
        while True:
            for item in self.store.turn_events(turn_id, cursor):
                cursor = item['seq']
                yield item
            turn = self.store.get_turn(turn_id)
            state = str(turn.get('state') or '')
            if state in TURN.terminals or state == 'awaiting_user':
                # Drain once more: the runner appends the last event before it writes the state.
                for item in self.store.turn_events(turn_id, cursor):
                    cursor = item['seq']
                    yield item
                if state == 'interrupted':
                    failure = self._error_event(turn_id)
                    if failure:
                        raise AIError(
                            str(failure.get('message') or 'error'),
                            kind=str(failure.get('kind') or 'error'),
                            key=str(failure.get('key') or ''),
                            **(failure.get('fields') or {}),
                        )
                return
            with self._lock:
                running = turn_id in self._active
            if not running:
                # Nothing in this process can advance this turn (a replay of a turn whose runner is
                # gone). Return what the log holds instead of waiting forever.
                return
            with self._events:
                self._events.wait(0.25)

    def _error_event(self, turn_id: str) -> dict:
        for item in reversed(self.store.turn_events(turn_id)):
            if item.get('type') == 'error':
                return item
        return {}

    def _publish(self) -> None:
        """Wake every subscription waiting on a turn's log."""
        with self._events:
            self._events.notify_all()

    def _consume_commands(self, turn_id: str, request: ChatRequest) -> None:
        """A stop/steer issued while the runner was between rounds is as real as the in-memory one."""
        for kind, payload in self.store.take_turn_commands(turn_id):
            if kind == 'stop' and request.cancel_event is not None:
                setter = getattr(request.cancel_event, 'set', None)
                if callable(setter):
                    setter()
            elif kind == 'steer':
                text = str(payload.get('text') or '').strip()
                if text:
                    request.context_payload.setdefault('steer', []).append(text)

    def _record_event(self, turn_id: str, item: dict) -> None:
        """Append one event and move the turn's state forward when the event declares a move.

        Terminal and user-waiting states are the runner's to write (after the host's alert), so a
        subscription never returns before the notification was handed over.
        """
        self.store.append_turn_event(turn_id, item)
        if item.get('type') == 'meta':
            self.store.set_turn_origin(
                turn_id,
                provider=str(item.get('provider') or ''),
                model=str(item.get('model') or ''),
                skills=list(item.get('skills') or []),
            )
        target = EVENT_STATES.get(str(item.get('type') or ''))
        if not target:
            return
        state = str(self.store.get_turn(turn_id).get('state') or '')
        if not state or state == target or not TURN.allows(state, target):
            return
        self.store.set_turn_state(turn_id, target)

    def _handoff_unused_steer(self, request: ChatRequest) -> None:
        """Guidance that arrived after the last safe boundary becomes the next message, not a loss."""
        pending = request.context_payload.pop('steer', None) or []
        if isinstance(pending, str):
            pending = [pending]
        for text in pending:
            text = str(text).strip()
            if text:
                self.store.enqueue_turn(request.conversation_id, request.account, {'text': text})

    def _report_turn(self, request: ChatRequest, outcome: _TurnOutcome) -> None:
        """Hand one settled turn to the host's alert hook; a broken host hook never breaks a turn."""
        try:
            self.host.turn_finished(outcome.summary(request))
        except Exception:
            # Deliberately swallowed: the answer is already produced and stored, and a desktop
            # popup that cannot be drawn must not turn it into an error the user sees. The host's
            # own log carries its failure; the engine has no second place to report it.
            pass
