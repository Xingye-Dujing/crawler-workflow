"""The three magic numbers of one turn, in one place so a test can name them."""

#: How often a streaming assistant row is flushed while the provider is still talking. Long enough
#: not to write on every token, short enough that a kill loses at most this much text.
PERSIST_EVERY_SECONDS = 1.0

#: One card may ask several related questions; beyond a handful it stops being one decision.
MAX_QUESTIONS = 5

#: One question may offer a handful of options; a list longer than this is a menu, not a choice.
MAX_OPTIONS = 12
