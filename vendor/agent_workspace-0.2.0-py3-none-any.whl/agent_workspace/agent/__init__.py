"""The turn loop, split by the question each part answers.

The single 971-line ``agent.py`` this replaced held four different jobs in one class body, so "may a
tool run twice, and who decides" had to be answered by reading a 380-line generator. The split is not
along the lines:

``turn``      one turn's loop: rounds, the streaming row, tool calls, the pause/stop boundaries.
``dispatch``  one tool call — and the six CONTROL TOOLS as a table, not six ``if name ==`` branches.
``messages``  transcript → provider messages, orphan repair, the window the history must fit.
``prompt``    what goes INTO a round: the system prompt, the user row, references, steering.
``resume``    answering a pause: claim once, write the tool row, continue the same turn.
``limits``    the three numbers (flush cadence, questions per card, options per question).

``Agent`` is those mixins and nothing else, so the public name, the MRO and every method signature are
unchanged for ``AgentWorkspace`` and the host. What the loop may touch is declared in
:mod:`agent_workspace.ports` — one Protocol per domain — instead of an untyped services bag.
"""

from __future__ import annotations

from .dispatch import CONTROL_TOOLS, QUESTION_TOOLS, DispatchMixin
from .limits import MAX_OPTIONS, MAX_QUESTIONS, PERSIST_EVERY_SECONDS
from .messages import MessageMixin
from .prompt import PromptMixin
from .resume import ResumeMixin
from .turn import TurnMixin

__all__ = [
    'CONTROL_TOOLS',
    'MAX_OPTIONS',
    'MAX_QUESTIONS',
    'PERSIST_EVERY_SECONDS',
    'QUESTION_TOOLS',
    'Agent',
]


class Agent(TurnMixin, MessageMixin, PromptMixin, DispatchMixin, ResumeMixin):
    """The turn loop: one provider call, many tool calls, one durable transcript."""

    def __init__(self, services):
        self.services = services
