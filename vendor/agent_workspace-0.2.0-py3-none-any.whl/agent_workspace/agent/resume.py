"""Answering a pause: one claim, one tool row, then the same turn continues.

An answer is a COMMAND, not a new user message: the pending row is taken exactly once (a second
click, a stale card after a restart and a call already settled all get ``question.unknown``), the
answer is written as the tool result it is, and the same turn re-enters the loop with
``resume_mode`` set — so the transcript reads as one turn that paused, not two.
"""

from __future__ import annotations

from ..errors import AIError


class ResumeMixin:
    def _resume(self, request, conversation_id, account, turn_id, provider, model):
        services = self.services
        call_id = request.resume_call_id
        pending = services.store.claim_pending_call(call_id, account)
        if not pending:
            # Answering is idempotent by name: a second click, a stale card after a restart, or a
            # call already settled by a new message gets this sentence, never a silent double run.
            raise AIError('question.unknown', kind='not_found', key='question.unknown', reason=call_id)
        answers = request.answers or {}
        selected = answers.get(call_id, answers) if isinstance(answers, dict) else answers
        content = {'answers': selected}
        reference_text = str(answers.get('reference_text') or '') if isinstance(answers, dict) else ''
        if reference_text:
            content['reference_text'] = reference_text
        if pending.get('kind') == 'question':
            expected = len((pending.get('args') or {}).get('questions') or [])
            if expected > 1 and (not isinstance(selected, list) or len(selected) != expected):
                content = {'error': 'question.answersExpected', 'expected': expected}
        if pending.get('kind') == 'approval':
            content = self._settle_approval(request, pending, selected, conversation_id, account, turn_id, call_id)
        self._persist_tool_result(
            conversation_id, turn_id, call_id, pending.get('tool', 'question'), content, bool(content.get('error'))
        )
        from ..util import event

        yield event('tool_result', call_id=call_id, tool=pending.get('tool', 'question'), content=content)
        request.answers = None
        request.resume_call_id = ''
        request.context_payload['resume_mode'] = True
        try:
            yield from self.run(request)
        finally:
            request.context_payload.pop('resume_mode', None)

    def _settle_approval(self, request, pending, selected, conversation_id, account, turn_id, call_id):
        """Apply the user's choice, then run the approved tool ONCE — or replay what it did."""
        services = self.services
        tool_name = pending.get('tool', '')
        selection = selected.get('selected') if isinstance(selected, dict) else selected
        if isinstance(selection, str):
            selection = [selection]
        answers_list = [
            {
                'selected': list(selection or []),
                'custom': str(selected.get('custom', '') if isinstance(selected, dict) else ''),
            }
        ]
        scope = services.approvals.settle(conversation_id, call_id, answers_list)
        if not scope:
            return {'error': 'approval.denied'}
        tool_args = pending.get('args') or {}
        if not services.approvals.consume(conversation_id, tool_name, tool_args):
            return {'error': 'approval.notGranted'}
        step, run_it = services.store.begin_step(
            turn_id,
            conversation_id,
            account,
            kind='tool',
            call_id=call_id,
            tool=tool_name,
            args=tool_args,
        )
        if not run_it:
            return {'approved': scope, 'tool': tool_name, 'replayed': True, 'result': step.get('result') or {}}
        ctx = {
            'account': account,
            'conversation_id': conversation_id,
            'provider_id': request.provider,
            'model': request.model,
            'cancel_event': request.cancel_event,
            'api_key': request.api_key,
        }
        try:
            executed = services.tools.execute(tool_name, tool_args, ctx)
            content = {'approved': scope, 'tool': tool_name, 'result': executed}
        except AIError as exc:
            content = {'approved': scope, 'tool': tool_name, 'error': exc.message}
        services.store.finish_step(step['step_id'], content)
        return content
