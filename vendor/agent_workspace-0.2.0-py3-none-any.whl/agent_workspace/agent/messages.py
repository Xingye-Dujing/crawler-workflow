"""Transcript ↔ provider messages, orphan repair, and the window the history has to fit.

These three are the answer to "what does the model actually see": a stored row is a known shape, a
provider wants another, and a crash between a ``tool_use`` and its result leaves a pair a provider
refuses. None of them touches the network or the turn's control flow, which is why they are readable
without the loop.
"""

from __future__ import annotations

import json

from ..types import block_text, message_text, tool_result_block
from ..util import estimate_tokens


class MessageMixin:
    # ── transcript → provider messages ─────────────────────────────────────────

    @staticmethod
    def provider_messages(rows: list[dict]) -> list[dict]:
        out = []
        for row in rows:
            role = row.get('role')
            meta = row.get('meta') or {}
            if role == 'user':
                blocks = row.get('blocks') or []
                images = [block.get('url') for block in blocks if block.get('type') == 'image' and block.get('url')]
                content = message_text(row)
                if images:
                    # The OpenAI-compatible content-part shape; only a provider declaring
                    # ``inline_images`` ever gets here (the attachment seam refuses the rest).
                    content = [{'type': 'text', 'text': content}]
                    content.extend({'type': 'image_url', 'image_url': {'url': url}} for url in images)
                out.append(
                    {
                        'role': 'user',
                        'content': content,
                        'meta': {'context_text': meta.get('context_text', '')},
                    }
                )
            elif role == 'assistant':
                tool_calls = []
                for block in row.get('blocks') or []:
                    if block.get('type') == 'tool_use':
                        tool_calls.append(
                            {
                                'id': block.get('id'),
                                'type': 'function',
                                'function': {
                                    'name': block.get('name'),
                                    'arguments': json.dumps(block.get('input') or {}, ensure_ascii=False),
                                },
                            }
                        )
                out.append(
                    {
                        'role': 'assistant',
                        'content': block_text(row.get('blocks')),
                        'tool_calls': tool_calls,
                        'meta': {'reasoning_content': meta.get('reasoning_content', '')},
                    }
                )
            elif role == 'tool':
                block = next((item for item in row.get('blocks') or [] if item.get('type') == 'tool_result'), {})
                out.append(
                    {
                        'role': 'tool',
                        'tool_call_id': block.get('tool_use_id', ''),
                        'content': json.dumps(block.get('content'), ensure_ascii=False, default=str),
                    }
                )
        return out

    def repair_tool_pairs(self, rows: list[dict], turn_id: str) -> list[dict]:
        """Heal an orphan ``tool_use`` left by a crash between the call and its result.

        Providers reject a tool_call without its result, so one interrupted turn must not poison
        every later turn. A synthetic result records the fact; it is never presented as an answer.
        """
        answered = set()
        for row in rows:
            for block in row.get('blocks') or []:
                if block.get('type') == 'tool_result':
                    answered.add(str(block.get('tool_use_id') or ''))
        repaired = []
        for row in rows:
            repaired.append(row)
            if row.get('role') != 'assistant':
                continue
            for block in row.get('blocks') or []:
                if block.get('type') != 'tool_use':
                    continue
                call_id = str(block.get('id') or '')
                if call_id and call_id not in answered:
                    answered.add(call_id)
                    self.services.store.append_message(
                        row['conversation_id'],
                        turn_id,
                        'tool',
                        [tool_result_block(call_id, {'interrupted': True}, True)],
                        {'tool': block.get('name', ''), 'call_id': call_id, 'repair': True},
                    )
                    repaired.append(
                        {
                            'role': 'tool',
                            'conversation_id': row['conversation_id'],
                            'blocks': [tool_result_block(call_id, {'interrupted': True}, True)],
                            'meta': {},
                        }
                    )
        return repaired

    def fit_history(self, messages: list[dict], window: int, reserved: int = 0) -> tuple[list[dict], dict]:
        """Drop oldest whole turns at a user boundary; never cut a system prompt mid-string.

        ``reserved`` is the system prompt plus tool schemas plus the output budget: counting only
        message characters lets a local model's prompt overflow the window it actually reports.
        """
        meta = {'window': window, 'budget': 0, 'dropped': 0, 'kept': len(messages)}
        if not window:
            return messages, meta
        budget = max(200, int(window * 0.8) - int(reserved))
        meta['budget'] = budget
        total = sum(estimate_tokens(str(item.get('content') or '')) for item in messages)
        if total <= budget:
            return messages, meta
        kept = list(messages)
        while kept and total > budget:
            index = next((i for i, item in enumerate(kept) if item.get('role') == 'user'), None)
            if index is None:
                break
            end = next((i for i in range(index + 1, len(kept)) if kept[i].get('role') == 'user'), len(kept))
            removed = kept[index:end]
            total -= sum(estimate_tokens(str(item.get('content') or '')) for item in removed)
            del kept[index:end]
            meta['dropped'] += 1
        meta['kept'] = len(kept)
        return kept, meta

    def _merge_blocks(self, blocks: list[dict]) -> list[dict]:
        """Merge adjacent same-type deltas so one paragraph is one block, not 200 tiny ones."""
        merged: list[dict] = []
        for block in blocks:
            if merged and merged[-1].get('type') == block.get('type'):
                kind = block.get('type')
                if kind == 'text':
                    merged[-1]['text'] += block.get('text', '')
                elif kind == 'thinking':
                    merged[-1]['thinking'] += block.get('thinking', '')
                continue
            merged.append(dict(block))
        return merged
