"""Run monitors and their deliveries.

A monitor is a standing condition over run events; a delivery is one recorded match, written by the
server and ACKed by the client that owns the key. Neither spends a token: the record exists so a
client can decide, never so the server can call a model.
"""

from __future__ import annotations

import json

from ..types import new_id
from ..util import utc_now


class MonitorMixin:
    def create_monitor(self, account: str, conversation_id: str, conditions: dict) -> dict:
        monitor_id = new_id('mon')
        self._run(
            'INSERT INTO monitors (id, account, conversation_id, conditions, created_at) VALUES (?,?,?,?,?)',
            (monitor_id, account, conversation_id, json.dumps(conditions, ensure_ascii=False), utc_now()),
        )
        return self.get_monitor(monitor_id)

    def get_monitor(self, monitor_id: str) -> dict:
        row = self._db.execute('SELECT * FROM monitors WHERE id=?', (monitor_id,)).fetchone()
        data = self._row(row)
        if data:
            data['conditions'] = json.loads(data.get('conditions') or '{}')
        return data

    def list_monitors(self, account: str, status: str = 'active') -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                'SELECT * FROM monitors WHERE account=? AND status=? ORDER BY created_at DESC',
                (account, status),
            ).fetchall()
        result = []
        for row in rows:
            data = self._row(row)
            data['conditions'] = json.loads(data.get('conditions') or '{}')
            result.append(data)
        return result

    def stop_monitor(self, account: str, monitor_id: str) -> bool:
        cursor = self._run("UPDATE monitors SET status='stopped' WHERE id=? AND account=?", (monitor_id, account))
        return cursor.rowcount > 0

    def add_delivery(self, account: str, monitor_id: str, payload: dict) -> dict:
        delivery_id = new_id('del')
        self._run(
            'INSERT INTO deliveries (id, monitor_id, account, payload, created_at) VALUES (?,?,?,?,?)',
            (delivery_id, monitor_id, account, json.dumps(payload, ensure_ascii=False), utc_now()),
        )
        return {'id': delivery_id, 'monitor_id': monitor_id, 'payload': payload}

    def pending_deliveries(self, account: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                'SELECT * FROM deliveries WHERE account=? AND ack=0 ORDER BY created_at', (account,)
            ).fetchall()
        result = []
        for row in rows:
            data = self._row(row)
            data['payload'] = json.loads(data.get('payload') or '{}')
            result.append(data)
        return result

    def ack_delivery(self, account: str, delivery_id: str) -> bool:
        cursor = self._run('UPDATE deliveries SET ack=1 WHERE id=? AND account=?', (delivery_id, account))
        return cursor.rowcount > 0
