"""What the user wants remembered, and the per-account preferences that are not a transcript.

A memory is a short fact with a hard cap on count AND characters — both refuse by name rather than
truncate, because a silently shortened memory is a false one. ``prefs`` is the key/value shelf the
engine and its plugins read at boot (an installed-plugin list, a conversation's mode preference).
"""

from __future__ import annotations

from ..types import new_id
from ..util import utc_now
from .base import MEMORY_MAX_CHARS, MEMORY_MAX_COUNT


class MemoryMixin:
    def add_memory(self, account: str, text: str) -> dict:
        """Return ``{... row, 'duplicate': bool}``; caps refuse by name, never truncate."""
        text = str(text or '').strip()
        if not text:
            raise ValueError('empty memory')
        if len(text) > MEMORY_MAX_CHARS:
            raise ValueError('memory.tooLong')
        with self._lock:
            existing = self._db.execute('SELECT * FROM memories WHERE account=? AND text=?', (account, text)).fetchone()
            if existing:
                return {**self._row(existing), 'duplicate': True}
            count = self._db.execute('SELECT COUNT(*) AS n FROM memories WHERE account=?', (account,)).fetchone()['n']
            if int(count) >= MEMORY_MAX_COUNT:
                raise ValueError('memory.full')
            row_id = new_id('mem')
            self._db.execute(
                'INSERT INTO memories (id, account, text, created_at) VALUES (?,?,?,?)',
                (row_id, account, text, utc_now()),
            )
            self._db.commit()
            created = self._db.execute('SELECT * FROM memories WHERE id=?', (row_id,)).fetchone()
        return {**self._row(created), 'duplicate': False}

    def list_memories(self, account: str, limit: int = 0) -> list[dict]:
        sql = 'SELECT * FROM memories WHERE account=? ORDER BY created_at DESC'
        args: list = [account]
        if limit:
            sql += ' LIMIT ?'
            args.append(limit)
        with self._lock:
            return [self._row(row) for row in self._db.execute(sql, args).fetchall()]

    def delete_memory(self, account: str, memory_id: str) -> bool:
        cursor = self._run('DELETE FROM memories WHERE id=? AND account=?', (memory_id, account))
        return cursor.rowcount > 0

    # ── prefs ──────────────────────────────────────────────────────────────────

    def get_pref(self, account: str, key: str, default: str = '') -> str:
        row = self._db.execute('SELECT value FROM prefs WHERE account=? AND key=?', (account, key)).fetchone()
        return row['value'] if row else default

    def set_pref(self, account: str, key: str, value: str) -> None:
        self._run(
            'INSERT INTO prefs (account, key, value) VALUES (?,?,?) '
            'ON CONFLICT(account, key) DO UPDATE SET value=excluded.value',
            (account, key, str(value)),
        )
