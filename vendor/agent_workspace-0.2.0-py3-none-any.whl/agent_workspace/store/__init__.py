"""The durable store, one module per aggregate and one thin ``Store`` facade over them.

The single 1220-line ``store.py`` this replaced answered 88 method calls across 16 aggregates, so
"which table does this write, and what does it commit with" had to be read out of the middle of a
class. The split is by aggregate, and the rules that make the store trustworthy live in the module
that owns the table:

``base``        connection, ``_db`` (rebound at CALL time per account), schema, ``_run``/``_row``.
``transcript``  conversations, messages, turns, the durable event log, pending calls, commands, inbox.
``steps``       one durable row per tool call, and the OTel-shaped trace beside it.
``usage``       token usage per provider call, and the two questions the panel asks.
``memory``      memories (capped, refuse by name) and per-account prefs.
``library``     write proposals, user skills, attached files, the Python script library.
``monitors``    run monitors and their deliveries.
``recipes``     recipe runs and their evidence.

``Store`` is every mixin and nothing else: the public name, the MRO and therefore every method
signature are unchanged, so ``AgentWorkspace`` and the host never learned about the split.
"""

from __future__ import annotations

from .base import MEMORY_MAX_CHARS, MEMORY_MAX_COUNT, SCHEMA, BaseMixin
from .library import LibraryMixin
from .memory import MemoryMixin
from .monitors import MonitorMixin
from .recipes import RecipeMixin
from .steps import StepsMixin
from .transcript import TranscriptMixin
from .usage import UsageMixin

__all__ = ['MEMORY_MAX_CHARS', 'MEMORY_MAX_COUNT', 'SCHEMA', 'Store']


class Store(
    BaseMixin,
    TranscriptMixin,
    StepsMixin,
    UsageMixin,
    MemoryMixin,
    LibraryMixin,
    MonitorMixin,
    RecipeMixin,
):
    """One SQLite file: transcript, memory, usage, artifacts, monitors, files, scripts, recipes."""
