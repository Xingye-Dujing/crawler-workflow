"""Token usage per provider call, and the two questions the panel asks about it.

One row per provider call (never one row per turn), so a usage bar can be read by account, by
conversation or since a local day boundary without a second ledger. ``tokens`` is the sum the UI
shows; the three components stay separate because a cached prompt token costs differently.
"""

from __future__ import annotations

from ..types import new_id
from ..util import utc_now


class UsageMixin:
    def record_usage(
        self,
        account: str,
        conversation_id: str,
        provider: str,
        model: str,
        prompt: int = 0,
        completion: int = 0,
        cached: int = 0,
        reasoning: int = 0,
        calls: int = 1,
    ) -> None:
        self._run(
            """INSERT INTO usage (id, conversation_id, account, provider, model, prompt_tokens,
               completion_tokens, cached_tokens, reasoning_tokens, calls, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                new_id('use'),
                conversation_id,
                account,
                provider,
                model,
                prompt,
                completion,
                cached,
                reasoning,
                calls,
                utc_now(),
            ),
        )

    def token_usage(self, *, account: str = '', conversation_id: str = '', since: str = '') -> dict:
        sql = 'SELECT * FROM usage WHERE 1=1'
        args: list = []
        if account:
            sql += ' AND account=?'
            args.append(account)
        if conversation_id:
            sql += ' AND conversation_id=?'
            args.append(conversation_id)
        if since:
            sql += ' AND created_at>=?'
            args.append(since)
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        prompt = sum(int(row['prompt_tokens']) for row in rows)
        completion = sum(int(row['completion_tokens']) for row in rows)
        return {
            'prompt_tokens': prompt,
            'completion_tokens': completion,
            'tokens': prompt + completion,
            'calls': len(rows),
        }

    def conversation_usage(self, conversation_id: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                """SELECT provider, model, SUM(prompt_tokens) AS prompt_tokens,
                   SUM(completion_tokens) AS completion_tokens, SUM(cached_tokens) AS cached_tokens,
                   SUM(reasoning_tokens) AS reasoning_tokens, SUM(calls) AS calls
                   FROM usage WHERE conversation_id=? GROUP BY provider, model""",
                (conversation_id,),
            ).fetchall()
        return [self._row(row) for row in rows]
