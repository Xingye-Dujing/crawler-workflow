"""Recipe runs and their evidence.

A recipe is a small, user-visible procedure; a run is the live progress through it. One ACTIVE run
per conversation is the rule — starting again returns the live run rather than forking a second, so a
double click cannot run the same procedure twice. Evidence is one row per step's proof, so a finished
recipe can show why each step was believed.
"""

from __future__ import annotations

import json

from ..types import new_id
from ..util import utc_now


class RecipeMixin:
    def start_recipe_run(self, account: str, conversation_id: str, recipe_id: str) -> dict:
        """One active recipe per conversation: starting again returns the live run, never a fork."""
        active = self.active_recipe_run(conversation_id, account)
        if active:
            return active
        run_id = new_id('recipe_run')
        now = utc_now()
        self._run(
            'INSERT INTO recipe_runs (id, account, conversation_id, recipe_id, status, step_index, '
            'created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)',
            (run_id, account, conversation_id, recipe_id, 'running', 0, now, now),
        )
        return self.get_recipe_run(run_id, account)

    def get_recipe_run(self, run_id: str, account: str = '') -> dict:
        sql = 'SELECT * FROM recipe_runs WHERE id=?'
        args: list = [run_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        with self._lock:
            row = self._db.execute(sql, args).fetchone()
        return self._row(row)

    def active_recipe_run(self, conversation_id: str, account: str = '') -> dict:
        sql = "SELECT * FROM recipe_runs WHERE conversation_id=? AND status='running'"
        args: list = [conversation_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        sql += ' ORDER BY created_at DESC LIMIT 1'
        with self._lock:
            row = self._db.execute(sql, args).fetchone()
        return self._row(row)

    def update_recipe_run(self, run_id: str, account: str, *, step_index=None, status: str = '') -> dict:
        sets = ['updated_at=?']
        args: list = [utc_now()]
        if step_index is not None:
            sets.append('step_index=?')
            args.append(int(step_index))
        if status:
            sets.append('status=?')
            args.append(status)
        args.extend([run_id, account])
        self._run(f'UPDATE recipe_runs SET {", ".join(sets)} WHERE id=? AND account=?', tuple(args))
        return self.get_recipe_run(run_id, account)

    def add_recipe_evidence(self, run_id: str, step_id: str, tool: str, kind: str, payload: dict | None = None) -> dict:
        evidence_id = new_id('recipe_ev')
        self._run(
            'INSERT INTO recipe_evidence (id, run_id, step_id, tool, kind, payload, created_at) VALUES (?,?,?,?,?,?,?)',
            (
                evidence_id,
                run_id,
                step_id,
                tool,
                kind,
                json.dumps(payload or {}, ensure_ascii=False, default=str),
                utc_now(),
            ),
        )
        return {'id': evidence_id, 'step_id': step_id, 'tool': tool, 'kind': kind, 'payload': payload or {}}

    def recipe_evidence(self, run_id: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                'SELECT * FROM recipe_evidence WHERE run_id=? ORDER BY created_at, rowid', (run_id,)
            ).fetchall()
        out = []
        for row in rows:
            item = self._row(row)
            item['payload'] = json.loads(item.get('payload') or '{}')
            out.append(item)
        return out
