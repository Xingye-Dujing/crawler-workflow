"""The data shelf: write proposals, user skills, attached files and the Python script library.

All four are DATA, never code: a skill manifest's prompt may not contain imports, a script is stored
as text for a local runtime to run (this store never executes it), and an artifact is a proposal the
host applies. Every row is scoped by ``account``.
"""

from __future__ import annotations

import json

from ..types import SKILL_ID_RE, new_id
from ..util import utc_now


class LibraryMixin:
    # ── artifacts (write proposals) ────────────────────────────────────────────

    def save_artifact(self, account: str, conversation_id: str, kind: str, payload: dict) -> dict:
        artifact_id = new_id('art')
        self._run(
            'INSERT INTO artifacts (id, conversation_id, account, kind, payload, created_at) VALUES (?,?,?,?,?,?)',
            (artifact_id, conversation_id, account, kind, json.dumps(payload, ensure_ascii=False), utc_now()),
        )
        return self.get_artifact(artifact_id)

    def get_artifact(self, artifact_id: str) -> dict:
        row = self._db.execute('SELECT * FROM artifacts WHERE id=?', (artifact_id,)).fetchone()
        data = self._row(row)
        if data:
            data['payload'] = json.loads(data.get('payload') or '{}')
        return data

    def list_artifacts(self, account: str, conversation_id: str = '', limit: int = 0) -> list[dict]:
        sql = 'SELECT * FROM artifacts WHERE account=?'
        args: list = [account]
        if conversation_id:
            sql += ' AND conversation_id=?'
            args.append(conversation_id)
        sql += ' ORDER BY created_at DESC'
        if limit:
            sql += ' LIMIT ?'
            args.append(limit)
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        result = []
        for row in rows:
            data = self._row(row)
            data['payload'] = json.loads(data.get('payload') or '{}')
            result.append(data)
        return result

    # ── user skills (data, never code) ─────────────────────────────────────────

    def save_skill(self, account: str, manifest: dict) -> dict:
        skill_id = str(manifest.get('id') or '').strip()
        if not SKILL_ID_RE.match(skill_id):
            raise ValueError('invalid skill id')
        if str(manifest.get('prompt') or '').strip().startswith(('import ', 'from ')):
            raise ValueError('a user skill may not contain code')
        self._run(
            'INSERT INTO skills (id, account, manifest, created_at) VALUES (?,?,?,?) '
            'ON CONFLICT(id) DO UPDATE SET manifest=excluded.manifest',
            (skill_id, account, json.dumps(manifest, ensure_ascii=False), utc_now()),
        )
        return {'id': skill_id, 'account': account, 'manifest': manifest}

    def list_user_skills(self, account: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                'SELECT manifest FROM skills WHERE account=? ORDER BY created_at', (account,)
            ).fetchall()
        result = []
        for row in rows:
            manifest = json.loads(row['manifest'])
            manifest['id'] = str(manifest.get('id') or '')
            result.append(manifest)
        return result

    def delete_skill(self, account: str, skill_id: str) -> bool:
        cursor = self._run('DELETE FROM skills WHERE id=? AND account=?', (skill_id, account))
        return cursor.rowcount > 0

    # ── attached files ─────────────────────────────────────────────────────────

    def add_file(
        self,
        account: str,
        name: str,
        path: str = '',
        size: int = 0,
        conversation_id: str = '',
        meta: dict | None = None,
    ) -> dict:
        file_id = new_id('file')
        self._run(
            'INSERT INTO files (id, account, conversation_id, name, path, size, meta, created_at) '
            'VALUES (?,?,?,?,?,?,?,?)',
            (
                file_id,
                account,
                conversation_id,
                name,
                path,
                size,
                json.dumps(meta or {}, ensure_ascii=False),
                utc_now(),
            ),
        )
        return self.get_file(file_id)

    def get_file(self, file_id: str) -> dict:
        row = self._db.execute('SELECT * FROM files WHERE id=?', (file_id,)).fetchone()
        data = self._row(row)
        if data:
            data['meta'] = json.loads(data.get('meta') or '{}')
        return data

    def list_files(self, account: str, conversation_id: str = '') -> list[dict]:
        sql = 'SELECT * FROM files WHERE account=?'
        args: list = [account]
        if conversation_id:
            sql += ' AND conversation_id=?'
            args.append(conversation_id)
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        result = []
        for row in rows:
            data = self._row(row)
            data['meta'] = json.loads(data.get('meta') or '{}')
            result.append(data)
        return result

    def delete_file(self, account: str, file_id: str) -> bool:
        cursor = self._run('DELETE FROM files WHERE id=? AND account=?', (file_id, account))
        return cursor.rowcount > 0

    # ── python script library (data, never a sandbox) ──────────────────────────

    def save_script(self, account: str, payload: dict) -> dict:
        script_id = str(payload.get('id') or '').strip() or new_id('script')
        existing = self.get_script(script_id, account)
        version = int(existing.get('version') or 0) + 1
        row = {
            'id': script_id,
            'account': account,
            'name': str(payload.get('name') or script_id),
            'code': str(payload.get('code') or ''),
            'inputs': str(payload.get('inputs') or ''),
            'outputs': str(payload.get('outputs') or ''),
            'tags': str(payload.get('tags') or ''),
            'version': version,
            'builtin': 0,
        }
        self._run(
            """INSERT INTO python_scripts (id, account, name, code, inputs, outputs, tags, version, builtin, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(id) DO UPDATE SET name=excluded.name, code=excluded.code,
                   inputs=excluded.inputs, outputs=excluded.outputs, tags=excluded.tags,
                   version=excluded.version""",
            (
                row['id'],
                row['account'],
                row['name'],
                row['code'],
                row['inputs'],
                row['outputs'],
                row['tags'],
                row['version'],
                row['builtin'],
                utc_now(),
            ),
        )
        return self.get_script(script_id, account)

    def get_script(self, script_id: str, account: str = '') -> dict:
        sql = 'SELECT * FROM python_scripts WHERE id=?'
        args: list = [script_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        return self._row(self._db.execute(sql, args).fetchone())

    def list_scripts(self, account: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                'SELECT * FROM python_scripts WHERE account=? ORDER BY builtin DESC, name', (account,)
            ).fetchall()
        return [self._row(row) for row in rows]

    def delete_script(self, account: str, script_id: str) -> bool:
        cursor = self._run('DELETE FROM python_scripts WHERE id=? AND account=? AND builtin=0', (script_id, account))
        return cursor.rowcount > 0
