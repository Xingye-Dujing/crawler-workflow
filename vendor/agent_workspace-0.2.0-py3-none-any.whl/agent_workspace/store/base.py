"""The connection, the schema and the two helpers every aggregate mixin uses.

``path`` may be a callable: the account's data root is resolved at CALL time, not when the process
boots, so one ``AgentWorkspace`` can serve several accounts by switching the host's active account.
Every read goes through the ``_db`` property, which rebinds (and re-opens) on change.
"""

from __future__ import annotations

import json
import shutil
import sqlite3
import threading
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY, account TEXT NOT NULL, title TEXT DEFAULT '',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
    pinned INTEGER DEFAULT 0, archived INTEGER DEFAULT 0,
    provider TEXT DEFAULT '', model TEXT DEFAULT '',
    skills TEXT NOT NULL DEFAULT '[]',
    workspace_dir TEXT DEFAULT '', workspace_group TEXT DEFAULT '', workspace_label TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_conv_account ON conversations(account, updated_at DESC);
CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, turn_id TEXT NOT NULL,
    role TEXT NOT NULL, status TEXT DEFAULT 'done', seq INTEGER NOT NULL,
    blocks TEXT NOT NULL, meta TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id, seq);
CREATE TABLE IF NOT EXISTS turns (
    id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, account TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'new', stop_reason TEXT DEFAULT '', error TEXT DEFAULT '',
    provider TEXT DEFAULT '', model TEXT DEFAULT '', skills TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_turns_conv ON turns(conversation_id, created_at);
CREATE TABLE IF NOT EXISTS turn_events (
    turn_id TEXT NOT NULL, seq INTEGER NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL,
    PRIMARY KEY (turn_id, seq)
);
CREATE TABLE IF NOT EXISTS pending_calls (
    call_id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, account TEXT NOT NULL,
    turn_id TEXT NOT NULL, kind TEXT NOT NULL, tool TEXT DEFAULT '', args TEXT NOT NULL,
    provider TEXT DEFAULT '', model TEXT DEFAULT '', skills TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pending_conv ON pending_calls(conversation_id);
CREATE TABLE IF NOT EXISTS turn_commands (
    turn_id TEXT NOT NULL, kind TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_commands_turn ON turn_commands(turn_id);
CREATE TABLE IF NOT EXISTS turn_inbox (
    id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, account TEXT NOT NULL,
    payload TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_inbox_conv ON turn_inbox(conversation_id, created_at);
CREATE TABLE IF NOT EXISTS agent_steps (
    step_id TEXT PRIMARY KEY, turn_id TEXT NOT NULL, conversation_id TEXT NOT NULL, account TEXT NOT NULL,
    kind TEXT NOT NULL, call_id TEXT NOT NULL DEFAULT '', tool TEXT NOT NULL DEFAULT '',
    args TEXT NOT NULL, status TEXT NOT NULL, result TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_step_call ON agent_steps(turn_id, call_id);
CREATE INDEX IF NOT EXISTS idx_step_turn ON agent_steps(turn_id, created_at);
CREATE TABLE IF NOT EXISTS agent_traces (
    trace_id TEXT PRIMARY KEY, turn_id TEXT NOT NULL, conversation_id TEXT NOT NULL, account TEXT NOT NULL,
    kind TEXT NOT NULL, name TEXT NOT NULL, parent TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'running', attributes TEXT NOT NULL DEFAULT '{}',
    started_at TEXT NOT NULL, ended_at TEXT DEFAULT '', duration_ms INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_traces_turn ON agent_traces(turn_id, started_at);
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY, account TEXT NOT NULL, text TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mem_account ON memories(account, created_at DESC);
CREATE TABLE IF NOT EXISTS usage (
    id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, account TEXT NOT NULL,
    provider TEXT DEFAULT '', model TEXT DEFAULT '', prompt_tokens INTEGER DEFAULT 0,
    completion_tokens INTEGER DEFAULT 0, cached_tokens INTEGER DEFAULT 0,
    reasoning_tokens INTEGER DEFAULT 0, calls INTEGER DEFAULT 0, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_usage_account ON usage(account, created_at);
CREATE INDEX IF NOT EXISTS idx_usage_conv ON usage(conversation_id);
CREATE TABLE IF NOT EXISTS prefs (
    account TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL,
    PRIMARY KEY (account, key)
);
CREATE TABLE IF NOT EXISTS artifacts (
    id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, account TEXT NOT NULL,
    kind TEXT NOT NULL, payload TEXT NOT NULL, status TEXT DEFAULT 'proposed',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS monitors (
    id TEXT PRIMARY KEY, account TEXT NOT NULL, conversation_id TEXT NOT NULL,
    conditions TEXT NOT NULL, status TEXT DEFAULT 'active', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS deliveries (
    id TEXT PRIMARY KEY, monitor_id TEXT NOT NULL, account TEXT NOT NULL,
    payload TEXT NOT NULL, ack INTEGER DEFAULT 0, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY, account TEXT NOT NULL, conversation_id TEXT DEFAULT '',
    name TEXT NOT NULL, path TEXT DEFAULT '', size INTEGER DEFAULT 0,
    meta TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS skills (
    id TEXT PRIMARY KEY, account TEXT NOT NULL, manifest TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS python_scripts (
    id TEXT PRIMARY KEY, account TEXT NOT NULL, name TEXT NOT NULL, code TEXT NOT NULL,
    inputs TEXT DEFAULT '', outputs TEXT DEFAULT '', tags TEXT DEFAULT '',
    version INTEGER DEFAULT 1, builtin INTEGER DEFAULT 0, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS recipe_runs (
    id TEXT PRIMARY KEY, account TEXT NOT NULL, conversation_id TEXT NOT NULL,
    recipe_id TEXT NOT NULL, status TEXT NOT NULL, step_index INTEGER DEFAULT 0,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS recipe_evidence (
    id TEXT PRIMARY KEY, run_id TEXT NOT NULL, step_id TEXT NOT NULL,
    tool TEXT DEFAULT '', kind TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL
);
"""

MEMORY_MAX_COUNT = 200
MEMORY_MAX_CHARS = 2000


class BaseMixin:
    def __init__(self, path):
        # ``path`` may be a callable. The account's data root is resolved at CALL time, not when the
        # process boots, so one AgentWorkspace can serve several accounts by switching the host's
        # active account. Every read goes through the ``_db`` property, which rebinds on change.
        self._path_provider = path if callable(path) else (lambda: path)
        self.path = Path(self._path_provider())
        self._lock = threading.RLock()
        self._connection = None
        self._connection_path = None
        _ = self._db  # open the first connection now

    @property
    def _db(self):
        target = Path(self._path_provider())
        with self._lock:
            if self._connection is None or target != self._connection_path:
                if self._connection is not None:
                    self._connection.close()
                target.parent.mkdir(parents=True, exist_ok=True)
                connection = sqlite3.connect(str(target), check_same_thread=False)
                connection.row_factory = sqlite3.Row
                connection.execute('PRAGMA journal_mode=WAL')
                connection.executescript(SCHEMA)
                connection.commit()
                self._connection = connection
                self._connection_path = target
                self.path = target
                self._migrate_skill_lists()
                self._ensure_conversation_columns()
            return self._connection

    def close(self) -> None:
        with self._lock:
            if self._connection is not None:
                self._connection.close()
                self._connection = None
                self._connection_path = None

    def _run(self, sql: str, args=()):
        with self._lock:
            cursor = self._db.execute(sql, args)
            self._db.commit()
            return cursor

    @staticmethod
    def _row(row) -> dict:
        return dict(row) if row is not None else {}

    def _columns(self, table: str) -> set[str]:
        return {str(row[1]) for row in self._db.execute(f'PRAGMA table_info({table})')}

    def _ensure_conversation_columns(self) -> None:
        """Add the session-configuration columns to a database created before 0.2.0."""
        wanted = (
            ('provider', "TEXT DEFAULT ''"),
            ('model', "TEXT DEFAULT ''"),
            ('skills', "TEXT NOT NULL DEFAULT '[]'"),
            ('workspace_dir', "TEXT DEFAULT ''"),
            ('workspace_group', "TEXT DEFAULT ''"),
            ('workspace_label', "TEXT DEFAULT ''"),
        )
        columns = self._columns('conversations')
        with self._lock:
            for name, declaration in wanted:
                if name not in columns:
                    self._db.execute(f'ALTER TABLE conversations ADD COLUMN {name} {declaration}')
            self._db.commit()

    def _migrate_skill_lists(self) -> None:
        """Replace the single ``skill`` column with a JSON list, once per database.

        A turn may activate several skills. SQLite 3.35+ can drop a column, so this is a real
        migration rather than a second read path: backfill ``skills`` from ``skill`` and drop the
        old column. ``ai.db.pre-0.2.0`` is written beside the database first, because a downgrade
        needs the old shape.
        """
        for table in ('turns', 'pending_calls'):
            columns = self._columns(table)
            if 'skills' in columns:
                continue
            if 'skill' not in columns:
                continue
            backup = self.path.with_name(f'{self.path.name}.pre-0.2.0')
            if not backup.exists():
                with self._lock:
                    self._db.commit()
                shutil.copy2(self.path, backup)
            with self._lock:
                self._db.execute(f'ALTER TABLE {table} ADD COLUMN skills TEXT NOT NULL DEFAULT "[]"')
                rows = self._db.execute(f'SELECT rowid, skill FROM {table}').fetchall()
                for row in rows:
                    raw = str(row['skill'] or '').strip()
                    value = json.dumps([raw], ensure_ascii=False) if raw else '[]'
                    self._db.execute(f'UPDATE {table} SET skills=? WHERE rowid=?', (value, row['rowid']))
                self._db.execute(f'ALTER TABLE {table} DROP COLUMN skill')
                self._db.commit()
