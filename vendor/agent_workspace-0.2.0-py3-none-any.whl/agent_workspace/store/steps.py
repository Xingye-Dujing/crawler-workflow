"""One durable row per tool call, and the OTel-shaped trace beside it.

``agent_steps`` is what makes a retry safe: the row is written ``running`` BEFORE the tool runs, a
finished row is replayed from its stored result on a second attempt, and a ``running`` row left by a
crash is marked ``interrupted`` and never executed again. ``agent_traces`` is observation only — ids,
names, status and counts, never prompt or answer text.
"""

from __future__ import annotations

import json

from ..types import new_id
from ..util import utc_now
from .base import BaseMixin


class StepsMixin:
    # ── agent steps ────────────────────────────────────────────────────────────

    def begin_step(
        self,
        turn_id: str,
        conversation_id: str,
        account: str,
        *,
        kind: str,
        call_id: str = '',
        tool: str = '',
        args: dict | None = None,
    ) -> tuple[dict, bool]:
        """Start one durable step, or return what a previous attempt recorded.

        Returns ``(step, run_it)``. ``run_it`` is true only when this call created a fresh
        ``running`` row. A finished step is replayed from its stored result, and a ``running`` row
        left by a crash is marked ``interrupted`` and never executed again — a side effect must not
        happen twice because the process died after the first one.
        """
        with self._lock:
            existing = self._db.execute(
                'SELECT * FROM agent_steps WHERE turn_id=? AND call_id=?', (turn_id, call_id)
            ).fetchone()
            if existing:
                step = self._decode_step(existing)
                if step['status'] != 'running':
                    return step, False
                self._db.execute(
                    "UPDATE agent_steps SET status='interrupted', result=?, updated_at=? WHERE step_id=?",
                    (json.dumps({'error': 'step.interrupted'}), utc_now(), step['step_id']),
                )
                self._db.commit()
                return self.get_step(step['step_id']), False
            step_id = new_id('step')
            now = utc_now()
            self._db.execute(
                'INSERT INTO agent_steps (step_id, turn_id, conversation_id, account, kind, call_id, tool, '
                'args, status, result, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                (
                    step_id,
                    turn_id,
                    conversation_id,
                    account,
                    kind,
                    call_id,
                    tool,
                    json.dumps(args or {}, ensure_ascii=False, default=str),
                    'running',
                    '{}',
                    now,
                    now,
                ),
            )
            self._db.commit()
        return self.get_step(step_id), True

    def finish_step(self, step_id: str, result, status: str = 'done') -> dict:
        self._run(
            'UPDATE agent_steps SET status=?, result=?, updated_at=? WHERE step_id=?',
            (status, json.dumps(result or {}, ensure_ascii=False, default=str), utc_now(), step_id),
        )
        return self.get_step(step_id)

    @staticmethod
    def _decode_step(row) -> dict:
        data = BaseMixin._row(row)
        if not data:
            return {}
        data['args'] = json.loads(data.get('args') or '{}')
        data['result'] = json.loads(data.get('result') or '{}')
        return data

    def get_step(self, step_id: str) -> dict:
        return self._decode_step(self._db.execute('SELECT * FROM agent_steps WHERE step_id=?', (step_id,)).fetchone())

    def steps(self, turn_id: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                'SELECT * FROM agent_steps WHERE turn_id=? ORDER BY created_at, step_id', (turn_id,)
            ).fetchall()
        return [self._decode_step(row) for row in rows]

    def settle_interrupted_steps(self) -> int:
        """Boot recovery: a step that was running has no runner any more; mark it once."""
        cursor = self._run(
            "UPDATE agent_steps SET status='interrupted', result=?, updated_at=? WHERE status='running'",
            (json.dumps({'error': 'step.interrupted'}), utc_now()),
        )
        return cursor.rowcount

    # ── traces (OTel GenAI semantics: ids, names, tokens; never content) ───────

    def add_trace(
        self,
        turn_id: str,
        conversation_id: str,
        account: str,
        *,
        kind: str,
        name: str,
        parent: str = '',
        attributes: dict | None = None,
    ) -> dict:
        trace_id = new_id('trace')
        self._run(
            'INSERT INTO agent_traces (trace_id, turn_id, conversation_id, account, kind, name, parent, '
            'status, attributes, started_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
            (
                trace_id,
                turn_id,
                conversation_id,
                account,
                kind,
                name,
                parent,
                'running',
                json.dumps(attributes or {}, ensure_ascii=False, default=str),
                utc_now(),
            ),
        )
        return self.get_trace(trace_id)

    @staticmethod
    def _decode_trace(row) -> dict:
        data = BaseMixin._row(row)
        if not data:
            return {}
        data['attributes'] = json.loads(data.get('attributes') or '{}')
        return data

    def get_trace(self, trace_id: str) -> dict:
        return self._decode_trace(
            self._db.execute('SELECT * FROM agent_traces WHERE trace_id=?', (trace_id,)).fetchone()
        )

    def finish_trace(self, trace_id: str, *, status: str = 'ok', attributes: dict | None = None) -> dict:
        trace = self.get_trace(trace_id)
        if not trace:
            return {}
        merged = dict(trace.get('attributes') or {})
        merged.update(attributes or {})
        ended = utc_now()
        duration = 0
        try:
            from datetime import datetime

            started = datetime.fromisoformat(str(trace.get('started_at') or ''))
            duration = max(0, int((datetime.fromisoformat(ended) - started).total_seconds() * 1000))
        except ValueError:
            duration = 0
        self._run(
            'UPDATE agent_traces SET status=?, attributes=?, ended_at=?, duration_ms=? WHERE trace_id=?',
            (status, json.dumps(merged, ensure_ascii=False, default=str), ended, duration, trace_id),
        )
        return self.get_trace(trace_id)

    def traces_for(self, turn_id: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute('SELECT * FROM agent_traces WHERE turn_id=? ORDER BY rowid', (turn_id,)).fetchall()
        return [self._decode_trace(row) for row in rows]
