"""Built-in expert modes plus host and user skills — one catalog, no code in user skills."""

from __future__ import annotations

from .errors import AIError
from .tools import CONTROL_TOOLS
from .types import SkillSpec, skill_from_manifest

#: Context sections the built-in context builder understands; a host may add its own source names.
CONTEXT_SOURCES = frozenset({'project', 'docs', 'memories'})


def validate_manifest(manifest: dict, known_tools=(), known_contexts=()) -> None:
    """A user/plugin skill is data: no code, no control tools, no unknown capability names."""
    from .types import CAPABILITIES, SKILL_ID_RE

    identifier = str(manifest.get('id') or '').strip()
    if not SKILL_ID_RE.match(identifier):
        raise ValueError('invalid skill id')
    prompt = str(manifest.get('prompt') or '').strip()
    if not prompt:
        raise ValueError('skill.promptRequired')
    if prompt.lstrip().startswith(('import ', 'from ', 'def ', 'class ')):
        raise ValueError('a skill may not contain code')
    for tool in manifest.get('tools') or ():
        if tool in CONTROL_TOOLS:
            raise ValueError('a skill may not name a control tool')
        if known_tools and tool not in known_tools:
            raise ValueError(f'unknown tool: {tool}')
    for source in manifest.get('context') or ():
        if source not in CONTEXT_SOURCES and known_contexts and source not in known_contexts:
            raise ValueError(f'unknown context source: {source}')
    for capability in manifest.get('requires') or ():
        if capability not in CAPABILITIES:
            raise ValueError(f'unknown capability: {capability}')
    for keyword in manifest.get('keywords') or ():
        if not isinstance(keyword, str) or not 1 <= len(keyword.strip()) <= 40:
            raise ValueError(f'invalid skill keyword: {keyword!r}')


BUILTIN_SKILLS: dict[str, SkillSpec] = {
    'general': SkillSpec(
        id='general',
        name_key='workspace.skill.general.name',
        description_key='workspace.skill.general.desc',
        prompt=(
            'You are a careful assistant. Read the supplied project context before answering. '
            'Prefer read-only tools and smallest-evidence-first: a small sample beats a whole table. '
            'If a fact is missing, say so; never invent one. Writes are proposals the user applies.'
        ),
        context=('project',),
        tools=('project_facts', 'capabilities', 'docs_search'),
        suggested=('Summarise the project.', 'What can I ask you to do?'),
        group='general',
    ),
    'project': SkillSpec(
        id='project',
        name_key='workspace.skill.project.name',
        description_key='workspace.skill.project.desc',
        prompt=(
            'You are a project advisor. Answer from the generated project facts and the host doc '
            'search. Name the source of a claim; when the context omits something, report the '
            'omission instead of filling the gap.'
        ),
        context=('project', 'docs'),
        tools=('project_facts', 'capabilities', 'docs_search'),
        suggested=('What are the main constraints here?', 'Explain the current context.'),
        group='general',
    ),
    'workspace': SkillSpec(
        id='workspace',
        name_key='workspace.skill.workspace.name',
        description_key='workspace.skill.workspace.desc',
        prompt=(
            "You can work in the user's chosen folder. List before reading, read before writing. "
            'All paths stay inside the folder; a path escape is refused by name. Show a diff before '
            'a write is applied and say exactly what you touched.'
        ),
        context=('project',),
        tools=('workspace_info', 'workspace_list', 'workspace_read', 'workspace_write', 'workspace_import', 'run_cmd'),
        suggested=('List the working folder.', 'Show the diff for this file.'),
        group='extension',
    ),
    'skill_author': SkillSpec(
        id='skill_author',
        name_key='workspace.skill.skill_author.name',
        description_key='workspace.skill.skill_author.desc',
        prompt=(
            'Help the user turn a repeated workflow into a reusable skill. A skill is data: a '
            'prompt, a context list, a tool list and capability requirements. It may not contain '
            'code or write actions. Produce a skill artifact for the user to apply.'
        ),
        context=('project',),
        tools=('project_facts', 'capabilities'),
        group='authoring',
    ),
    'developer': SkillSpec(
        id='developer',
        name_key='workspace.skill.developer.name',
        description_key='workspace.skill.developer.desc',
        prompt=(
            'Answer code questions from the read-only source snapshot the host exposes. You may '
            'cite a file or a line but you cannot change the running program; a reusable script '
            'is the extension path.'
        ),
        context=('project', 'docs'),
        tools=('project_facts', 'docs_search'),
        requires=frozenset(),
        local_only=True,
        group='authoring',
    ),
}


class SkillRegistry:
    def __init__(self, store, host, settings, catalog, scopes=None, tools=None):
        self.store = store
        self.host = host
        self.settings = settings
        self.catalog = catalog
        self.scopes = scopes
        self.tools = tools
        self._extra: dict[str, SkillSpec] = {}

    def register(self, spec: SkillSpec) -> None:
        self._extra[spec.id] = spec

    def unregister(self, skill_id: str) -> None:
        self._extra.pop(skill_id, None)

    def _all(self, account: str) -> dict[str, SkillSpec]:
        result = dict(BUILTIN_SKILLS)
        visible = (
            (lambda identifier: self.scopes.visible(identifier, account)) if self.scopes else (lambda identifier: True)
        )
        result.update({skill.id: skill for skill in self.host.skills() if visible(skill.id)})
        result.update({identifier: skill for identifier, skill in self._extra.items() if visible(identifier)})
        for manifest in self.store.list_user_skills(account):
            try:
                skill = skill_from_manifest(manifest, account=account, builtin=False)
            except ValueError:
                continue
            result[skill.id] = skill
        return result

    def get(self, skill_id: str, account: str) -> SkillSpec | None:
        return self._all(account).get(skill_id)

    def availability(self, skill: SkillSpec, provider_id: str = '', model: str = '') -> tuple[bool, str]:
        env = self.host.environment()
        if skill.local_only and env.cloud:
            return False, 'workspace.skill.cloudRefused'
        for source in skill.context:
            if source not in CONTEXT_SOURCES and source not in {item.name for item in self.host.context_sources()}:
                return False, f'skill.contextUnknown:{source}'
        for tool in skill.tools:
            if tool in CONTROL_TOOLS:
                continue
            if self.tools is not None and self.tools.get(tool) is None:
                return False, f'skill.toolUnknown:{tool}'
        for capability in sorted(skill.requires):
            if not self.catalog.supports(provider_id, capability, model):
                return False, capability
        return True, ''

    def route_many(self, text: str, account: str = 'default', limit: int = 0) -> list[dict]:
        """A deterministic keyword router: every candidate it returns is named with its score.

        What scores, strongest first: a starter phrase the user pasted whole (``suggested``, +5),
        a declared keyword (``keywords``, +its length, so a longer Chinese cue outranks a shorter
        one inside it), and a word of the skill id (+3). A Chinese question against English ids
        therefore needs the host to declare its own cues — measured: without them the router could
        only answer the two skills whose id happened to be the word the user typed.

        A turn may activate several skills. Candidates scoring 0 never enter; the list is capped
        (``skills.auto_max``, default 3) and a candidate below half the best score is noise.
        """
        lowered = str(text or '').lower()
        scored: list[dict] = []
        for identifier, skill in self._all(account).items():
            score = sum(3 for word in identifier.replace('_', ' ').split() if word in lowered)
            score += sum(len(str(word).lower()) for word in skill.keywords if str(word).lower() in lowered)
            score += sum(5 for word in skill.suggested if str(word).lower() in lowered)
            if score > 0:
                scored.append({'id': identifier, 'score': score})
        if not scored:
            return []
        scored.sort(key=lambda row: (-row['score'], row['id']))
        top = scored[0]['score']
        scored = [row for row in scored if row['score'] * 2 >= top]
        cap = int(limit or self.settings.get('skills.auto_max', 3) or 3)
        return scored[: max(1, cap)]

    def index_text(self, account: str = 'default', provider_id: str = '', model: str = '') -> str:
        """L0: one line per available skill, never a body."""
        lines = []
        for skill in sorted(self._all(account).values(), key=lambda item: (item.group, item.id)):
            available, _reason = self.availability(skill, provider_id, model)
            if not available:
                continue
            name = skill.name or self.host.i18n().t(skill.name_key)
            description = skill.description or self.host.i18n().t(skill.description_key)
            lines.append(f'- {skill.id}: {name} — {description}')
        return '\n'.join(lines)

    def list(self, account: str = 'default', provider_id: str = '', model: str = '') -> list[dict]:
        rows = []
        for skill in self._all(account).values():
            available, reason = self.availability(skill, provider_id, model)
            row = skill.to_public()
            row['available'] = available
            row['reason'] = reason
            row['why_not'] = reason
            row['why_not_text'] = self.host.i18n().t(reason) if reason else ''
            rows.append(row)
        rows.sort(key=lambda row: (not row['builtin'], row['group'], row['id']))
        return rows

    def manifests(self, account: str = 'default') -> list[dict]:
        return [skill.to_manifest() for skill in self._all(account).values()]

    def save_user(self, account: str, manifest: dict) -> dict:
        if str(manifest.get('id') or '') in BUILTIN_SKILLS:
            raise AIError('skill.builtinReadOnly', kind='refused', key='skill.builtinReadOnly')
        known_tools = set(self._specs_names())
        known_contexts = {item.name for item in self.host.context_sources()}
        try:
            validate_manifest(manifest, known_tools=known_tools, known_contexts=known_contexts)
            return self.store.save_skill(account, manifest)
        except ValueError as exc:
            raise AIError('skill.invalid', kind='refused', key='skill.invalid', reason=str(exc)) from exc

    def _specs_names(self):
        if self.tools is None:
            return set()
        return set(self.tools._specs) | set(self.tools._extra)

    def fork(self, account: str, skill_id: str) -> dict:
        source = self.get(skill_id, account)
        if source is None:
            raise AIError('skill.unknown', kind='not_found', reason=skill_id)
        manifest = source.to_manifest()
        manifest['id'] = f'{skill_id}_copy'
        manifest['builtin'] = False
        manifest['name'] = f'{source.name or source.name_key} (copy)'
        while self.get(str(manifest['id']), account):
            manifest['id'] += '_copy'
        return self.store.save_skill(account, manifest)

    def delete_user(self, account: str, skill_id: str) -> bool:
        return self.store.delete_skill(account, skill_id)


MAX_EXPLICIT_SKILLS = 8


class SkillContext:
    """One turn's activated skills: explicit, automatic, and tool-loaded.

    The order is stable (explicit order, then auto score, then load order), so the system prompt,
    the tool allowlist and the persisted ``turns.skills`` all describe the same activation.
    """

    def __init__(self, registry: SkillRegistry, account: str, provider_id: str = '', model: str = ''):
        self.registry = registry
        self.account = account
        self.provider_id = provider_id
        self.model = model
        self._specs: dict[str, SkillSpec] = {}
        self._sources: dict[str, str] = {}
        self.auto: list[dict] = []
        self.requested: list[str] = []

    def _add(self, skill: SkillSpec, source: str, score: float = 0) -> None:
        if skill.id not in self._specs:
            self._specs[skill.id] = skill
            self._sources[skill.id] = source

    def _require(self, skill_id: str) -> SkillSpec:
        skill = self.registry.get(skill_id, self.account)
        if skill is None:
            raise AIError('skill.unknown', kind='refused', key='skill.unknown', reason=skill_id)
        available, reason = self.registry.availability(skill, self.provider_id, self.model)
        if not available:
            raise AIError(
                'skill.unavailable', kind='capability', key='skill.unavailable', reason=f'{skill_id}: {reason}'
            )
        return skill

    def resolve(self, requested, text: str) -> list[SkillSpec]:
        """Resolve this turn. An explicit set wins; otherwise the router may pick several."""
        explicit = []
        for value in requested or ():
            identifier = str(value or '').strip()
            if identifier and identifier not in explicit:
                explicit.append(identifier)
        if len(explicit) > MAX_EXPLICIT_SKILLS:
            raise AIError('skills.tooMany', kind='refused', key='skills.tooMany', reason=str(len(explicit)))
        self.requested = explicit
        if explicit:
            for identifier in explicit:
                self._add(self._require(identifier), 'explicit')
            return self.specs()
        self.auto = self.registry.route_many(text, self.account) if str(text or '').strip() else []
        for row in self.auto:
            skill = self.registry.get(row['id'], self.account)
            if skill is None:
                continue
            available, _reason = self.registry.availability(skill, self.provider_id, self.model)
            if available:
                self._add(skill, 'auto', row['score'])
        if not self._specs:
            general = self.registry.get('general', self.account)
            if general is not None:
                self._add(general, 'auto')
        return self.specs()

    def load(self, skill_id: str) -> SkillSpec:
        """Load one skill by tool call; it becomes active from the next round."""
        skill = self._require(skill_id)
        self._add(skill, 'tool')
        return skill

    def specs(self) -> list[SkillSpec]:
        return list(self._specs.values())

    def ids(self) -> list[str]:
        return list(self._specs)

    def tools(self) -> tuple[str, ...]:
        names: list[str] = []
        for skill in self._specs.values():
            for name in skill.tools:
                if name not in names:
                    names.append(name)
        return tuple(names)

    def contexts(self) -> set[str]:
        names: set[str] = set()
        for skill in self._specs.values():
            names.update(skill.context)
        return names

    def meta(self) -> dict:
        return {
            'requested': list(self.requested),
            'auto': [dict(row) for row in self.auto],
            'resolved': [{'id': identifier, 'source': self._sources[identifier]} for identifier in self._specs],
            'loaded': [identifier for identifier, source in self._sources.items() if source == 'tool'],
        }
