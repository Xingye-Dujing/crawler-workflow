"""Tool dispatch: the six control tools are a TABLE, the rest is one tool call.

The control tools (a question, a plan, a recipe step, an artifact, an approval) are not domain tools:
they answer the loop itself, most of them by PAUSING it, and each has its own small protocol with the
UI. They used to be six ``if name ==`` branches in the middle of dispatch, which meant "which control
tools exist" could only be answered by reading that chain. :data:`CONTROL_TOOLS` is the answer, and
each handler is a generator that returns one of three verdicts:

``('content', dict)``   the tool produced a result — the caller writes the tool row and continues;
``('answered', None)``  the handler already wrote its own tool row (a refusal) — continue;
``('pause', None)``     the turn pauses and the user answers through ``pending_calls``.

A tool the turn did not offer is refused at EXECUTION, not merely hidden from the schema list, so a
replayed history cannot smuggle one past the mode or the recipe mask.
"""

from __future__ import annotations

import json

from .. import approval_preview
from ..errors import AIError
from ..policy import PolicyEngine
from ..util import event
from .limits import MAX_OPTIONS, MAX_QUESTIONS

#: name → handler method. Adding a control tool is one entry and one generator; it is never a new
#: branch inside :meth:`DispatchMixin._dispatch`.
CONTROL_TOOLS = {
    'ask_user_question': 'control_ask_user_question',
    'update_plan': 'control_update_plan',
    'recipe_start': 'control_recipe_start',
    'recipe_skip': 'control_recipe_skip',
    'present_artifact': 'control_present_artifact',
    'request_approval': 'control_request_approval',
}

#: The two controls a run may switch off as a pair (a chat-only or unattended surface).
QUESTION_TOOLS = ('ask_user_question', 'request_approval')


class DispatchMixin:
    # ── the loop's entry point ─────────────────────────────────────────────────

    def _dispatch(self, call, request, conversation_id, account, turn_id, allowed, cancel, parent_span=''):
        services = self.services
        ctx = {
            'call': call,
            'request': request,
            'conversation_id': conversation_id,
            'account': account,
            'turn_id': turn_id,
            'allowed': allowed,
            'cancel': cancel,
            'parent_span': parent_span,
            'name': call['name'],
            'args': call['arguments'],
            'call_id': call['id'],
        }
        yield event('tool_start', call_id=ctx['call_id'], tool=ctx['name'], arguments=ctx['args'])
        handler = CONTROL_TOOLS.get(ctx['name'])
        if handler is not None:
            verdict, content = yield from getattr(self, handler)(ctx)
        else:
            verdict, content = yield from self._dispatch_domain(ctx)
        if verdict == 'pause':
            return 'pause'
        if verdict == 'answered':
            return 'continue'
        # ── the one tail every producing path shares ──
        recipe_state = services.recipes.active(conversation_id, account)
        if recipe_state and (recipe_state.get('current') or {}).get('tool') == ctx['name']:
            progressed = services.recipes.observe(conversation_id, account, ctx['name'], content, False)
            if progressed:
                yield event('recipe', **progressed)
        yield event('tool_result', call_id=ctx['call_id'], tool=ctx['name'], content=content)
        self._persist_tool_result(conversation_id, turn_id, ctx['call_id'], ctx['name'], content, False)
        return 'continue'

    # ── control tools ──────────────────────────────────────────────────────────

    def control_ask_user_question(self, ctx):
        """Persist the question first, then paint it: a card that exists only in memory dies with
        the process, and its answer would have nothing to claim."""
        services = self.services
        questions = self._normalize_questions(ctx['args'])
        if not questions:
            content = {'error': 'badArgs'}
            yield event('tool_result', call_id=ctx['call_id'], tool=ctx['name'], content=content, is_error=True)
            self._persist_tool_result(
                ctx['conversation_id'], ctx['turn_id'], ctx['call_id'], ctx['name'], content, True
            )
            return 'answered', None
        services.store.save_pending_call(
            call_id=ctx['call_id'],
            conversation_id=ctx['conversation_id'],
            account=ctx['account'],
            turn_id=ctx['turn_id'],
            kind='question',
            tool=ctx['name'],
            args={'questions': questions},
            provider=ctx['request'].provider or '',
            model=ctx['request'].model or '',
            skill=ctx['request'].skill or '',
        )
        if len(questions) == 1:
            first = questions[0]
            yield event(
                'question',
                call_id=ctx['call_id'],
                question=first['question'],
                options=first['options'],
                allow_custom=first['allow_custom'],
                detail=first['detail'],
                tool=ctx['name'],
            )
        else:
            yield event('question', call_id=ctx['call_id'], questions=questions, tool=ctx['name'])
        return 'pause', None

    def control_update_plan(self, ctx):
        steps = [str(step) for step in ctx['args'].get('steps') or []]
        yield event('plan', steps=steps, call_id=ctx['call_id'])
        return 'content', {'ok': True, 'steps': steps}

    def control_recipe_start(self, ctx):
        services = self.services
        try:
            content = services.recipes.ensure(
                ctx['conversation_id'], ctx['account'], str(ctx['args'].get('recipe_id') or '')
            )
        except AIError as exc:
            content = {'error': exc.message, 'kind': exc.kind, 'key': exc.key}
        if content and not content.get('error'):
            yield event('recipe', **content)
        return 'content', content

    def control_recipe_skip(self, ctx):
        services = self.services
        try:
            content = services.recipes.skip(
                ctx['conversation_id'], ctx['account'], str(ctx['args'].get('reason') or '')
            )
        except AIError as exc:
            content = {'error': exc.message, 'kind': exc.kind, 'key': exc.key}
        if content and not content.get('error'):
            yield event('recipe', **content)
        return 'content', content

    def control_present_artifact(self, ctx):
        """A write is a PROPOSAL: the artifact is validated against the host's contract, stored, and
        offered; nothing is applied here."""
        services = self.services
        kind = str(ctx['args'].get('kind') or '')
        if not kind:
            content = {'error': 'missing kind'}
            yield event('tool_result', call_id=ctx['call_id'], tool=ctx['name'], content=content, is_error=True)
            self._persist_tool_result(
                ctx['conversation_id'], ctx['turn_id'], ctx['call_id'], ctx['name'], content, True
            )
            return 'answered', None
        artifact_payload = dict(ctx['args'].get('payload') or {})
        problems = services.artifact_registry.problems(kind, artifact_payload)
        if problems:
            content = {'error': 'artifact.invalid', 'problems': problems}
            yield event('tool_result', call_id=ctx['call_id'], tool=ctx['name'], content=content, is_error=True)
            self._persist_tool_result(
                ctx['conversation_id'], ctx['turn_id'], ctx['call_id'], ctx['name'], content, True
            )
            return 'answered', None
        artifact = services.store.save_artifact(ctx['account'], ctx['conversation_id'], kind, artifact_payload)
        yield event(
            'artifact',
            call_id=ctx['call_id'],
            kind=kind,
            title=str(ctx['args'].get('title') or ''),
            artifact_id=artifact['id'],
            payload=artifact['payload'],
            summary=str(ctx['args'].get('summary') or ''),
            preview=services.artifact_registry.preview(kind, artifact_payload),
            unvalidated=not services.artifact_registry.validated_by(kind),
        )
        return 'content', {'ok': True, 'artifact_id': artifact['id'], 'kind': kind}

    def control_request_approval(self, ctx):
        tool = str(ctx['args'].get('tool') or '')
        exact = ctx['args'].get('args') or {}
        if self.services.tools.get(tool, ctx['account']) is None:
            return 'content', {'error': 'unknown tool', 'tool': tool}
        yield from self._ask_approval(ctx['call_id'], ctx['conversation_id'], tool, exact, ctx['args'], ctx['request'])
        return 'pause', None

    # ── domain tools ───────────────────────────────────────────────────────────

    def _dispatch_domain(self, ctx):
        """One offered tool, executed once — or replayed if this exact call already ran."""
        services = self.services
        account = ctx['account']
        name = ctx['name']
        args = ctx['args']
        call_id = ctx['call_id']
        conversation_id = ctx['conversation_id']
        turn_id = ctx['turn_id']
        # The offer list is the contract: a tool the turn did not advertise is refused here, at
        # execution, not merely hidden from the schema list. Replayed history cannot smuggle one.
        if name not in ctx['allowed']:
            state = services.recipes.active(conversation_id, account)
            if state and (state.get('current') or {}).get('tool'):
                content = {
                    'error': 'recipe.stepTool',
                    'step': state['current']['title'],
                    'tool': state['current']['tool'],
                }
            else:
                content = {'error': 'tool.notOffered', 'tool': name}
            yield event('tool_result', call_id=call_id, tool=name, content=content, is_error=True)
            self._persist_tool_result(conversation_id, turn_id, call_id, name, content, True)
            return 'answered', None
        spec = services.tools.check(name, {'account': account})
        auto = bool(services.settings.get('approval.auto', True))
        decision = PolicyEngine.decide(spec, auto=auto)
        if decision.required and not services.approvals.consume(
            conversation_id, name, args, once_only=not decision.session_allowed
        ):
            yield from self._ask_approval(
                call_id,
                conversation_id,
                name,
                args,
                {'question': f'Allow {name}?', 'detail': args},
                ctx['request'],
                session_allowed=decision.session_allowed,
            )
            return 'pause', None
        tool_span = services.tracing.start(
            turn_id=turn_id,
            conversation_id=conversation_id,
            account=account,
            kind='tool',
            name=name,
            parent=ctx['parent_span'],
            attributes={'gen_ai.operation.name': 'execute_tool', 'gen_ai.tool.name': name},
        )
        step, run_it = services.store.begin_step(
            turn_id, conversation_id, account, kind='tool', call_id=call_id, tool=name, args=args
        )
        if not run_it:
            # This exact tool call already has a recorded outcome (or a crash left it running):
            # replay it. A side effect must not happen twice because a turn was retried.
            services.tracing.finish(tool_span, status='replayed')
            content = step.get('result') or {}
            is_error = step.get('status') != 'done'
            yield event('tool_result', call_id=call_id, tool=name, content=content, is_error=is_error)
            self._persist_tool_result(conversation_id, turn_id, call_id, name, content, is_error)
            return 'answered', None
        call_ctx = {
            'account': account,
            'conversation_id': conversation_id,
            'provider_id': ctx['request'].provider,
            'model': ctx['request'].model,
            'cancel_event': ctx['cancel'],
            'api_key': ctx['request'].api_key,
        }
        try:
            content = services.tools.execute(name, args, call_ctx, allowed=ctx['allowed'])
        except AIError as exc:
            services.tracing.finish(tool_span, status='error')
            content = {'error': exc.message, 'kind': exc.kind, 'key': exc.key}
            services.store.finish_step(step['step_id'], content, 'error')
            yield event('tool_result', call_id=call_id, tool=name, content=content, is_error=True)
            self._persist_tool_result(conversation_id, turn_id, call_id, name, content, True)
            return 'answered', None
        services.tracing.finish(tool_span, status='ok')
        services.store.finish_step(step['step_id'], content)
        return 'content', content

    # ── shared helpers ─────────────────────────────────────────────────────────

    @staticmethod
    def _normalize_questions(args: dict) -> list[dict]:
        """One shape for one question or up to five, so the card and the answer agree.

        ``questions`` (an array) is the multi form; ``question``/``options`` is the single form kept
        for existing callers. Anything malformed answers ``[]`` — the caller reports ``badArgs`` and
        writes the result, so no orphan tool_use is left in the transcript.
        """

        raw = args.get('questions')
        items = raw if isinstance(raw, (list, tuple)) else [args]
        if not items or len(items) > MAX_QUESTIONS:
            return []
        normalized = []
        for item in items:
            if not isinstance(item, dict):
                return []
            question = str(item.get('question') or '').strip()
            options = item.get('options') or []
            if isinstance(options, str):
                try:
                    options = json.loads(options)
                except ValueError:
                    options = [part.strip() for part in options.split(',') if part.strip()]
            if not isinstance(options, (list, tuple)):
                options = [options]
            options = [str(option) for option in options[:MAX_OPTIONS] if str(option).strip()]
            if not question or not options:
                return []
            normalized.append(
                {
                    'question': question,
                    'options': options,
                    'allow_custom': bool(item.get('allow_custom')),
                    'detail': item.get('detail') or {},
                }
            )
        return normalized

    def _ask_approval(self, call_id, conversation_id, tool, exact, args, request, *, session_allowed=True):
        services = self.services
        labels = {'once': 'Allow once'}
        if session_allowed:
            labels['session'] = 'Allow for this session'
        preview = approval_preview.preview(tool, exact, services.workspace(request.account))
        services.approvals.request(conversation_id, tool, exact, call_id, labels)
        services.store.save_pending_call(
            call_id=call_id,
            conversation_id=conversation_id,
            account=request.account,
            turn_id=request.turn_id or '',
            kind='approval',
            tool=tool,
            args=exact,
            provider=request.provider or '',
            model=request.model or '',
            skill=request.skill or '',
        )
        yield event(
            'question',
            call_id=call_id,
            question=str(args.get('question') or f'Allow {tool}?'),
            options=[labels['once'], *([labels['session']] if session_allowed else []), 'Deny'],
            allow_custom=False,
            detail={'tool': tool, 'arguments': exact, 'preview': preview},
            kind='approval',
        )

    def _persist_tool_result(self, conversation_id, turn_id, call_id, name, content, is_error):
        from ..types import tool_result_block

        self.services.store.append_message(
            conversation_id,
            turn_id,
            'tool',
            [tool_result_block(call_id, content, is_error)],
            {'tool': name, 'call_id': call_id},
        )
