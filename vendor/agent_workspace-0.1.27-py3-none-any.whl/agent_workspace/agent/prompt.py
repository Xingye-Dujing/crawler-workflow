"""What goes INTO a round: the system prompt, the mode, the user row, and steering.

``_system`` is the assembled instruction; ``_mode`` is the one setting a conversation may carry; the
user row is where attachments, ``@`` references and the replayable context block land together. None
of it calls a provider, which is what lets a reader check the prompt without following the loop.
"""

from __future__ import annotations

from .. import attachments as attachment_seam
from ..errors import AIError
from ..types import ChatRequest, image_block, text_block
from ..util import event


class PromptMixin:
    def _flush(self, message_id: str, blocks: list[dict], meta: dict, status: str) -> None:
        self.services.store.update_message(message_id, blocks=blocks, meta=meta, status=status)

    @staticmethod
    def _mode(request: ChatRequest, services=None, account: str = '', conversation_id: str = '') -> str:
        """``plan`` / ``build`` / ``''``; the conversation preference fills an explicit gap."""
        mode = str(request.context_payload.get('agent_mode') or '').strip().lower()
        if not mode and services is not None and conversation_id:
            mode = str(services.store.get_pref(account, f'agent_mode:{conversation_id}', '') or '').strip().lower()
        if mode not in ('', 'plan', 'build'):
            raise AIError('mode.unknown', kind='refused', key='mode.unknown', reason=mode)
        return mode

    @staticmethod
    def _is_write_tool(spec) -> bool:
        return spec is not None and (bool(getattr(spec, 'mutating', False)) or bool(getattr(spec, 'always_ask', False)))

    @staticmethod
    def _take_steer(request: ChatRequest) -> list[str]:
        """Guidance a running turn inserted at its next safe boundary; consumed exactly once."""
        pending = request.context_payload.pop('steer', None) or []
        if isinstance(pending, str):
            pending = [pending]
        return [str(item) for item in pending if str(item).strip()]

    def _system(self, request: ChatRequest, skill, provider, account) -> str:
        services = self.services
        lines = [
            f'You are operating in a {services.host.environment().kind} host.',
            services.host.environment().prompt_line(),
            skill.prompt,
            'Read the smallest evidence first. A missing id or column is refused by name.',
            'Writes are proposals: use present_artifact and let the user apply them.',
            f'Provider: {provider.spec.id}. '
            f'Model: {request.model or (provider.spec.models[0].id if provider.spec.models else "")}.',
        ]
        return '\n\n'.join(line for line in lines if line)

    def _user_row(self, conversation_id, turn_id, text, replay_text, account, provider, model, request):
        attachment = attachment_seam.prepare(request.context_payload.get('attachments'), provider=provider, model=model)
        blocks = [text_block(text)]
        if attachment['text']:
            blocks.append(text_block(attachment['text']))
        blocks.extend(image_block(url) for url in attachment['images'])
        references, unresolved = self.services.references.resolve(text, account)
        picks = [row for row in (request.context_payload or {}).get('references') or () if isinstance(row, dict)]
        # A token typed in the text was already expanded; a chip picked in the composer is a row.
        picks = [row for row in picks if f'@{row.get("kind")}:{row.get("id")}' not in text]
        if picks:
            picked, picked_unresolved = self.services.references.resolve_rows(picks, account)
            if picked:
                references = f'{references}\n\n{picked}' if references else picked
            unresolved.extend(name for name in picked_unresolved if name not in unresolved)
        if references:
            blocks.append(text_block(f'\n[Resolved references]\n{references}'))
        row_meta = {
            'context_text': replay_text,
            'unresolved_references': unresolved,
            'attachments': attachment['names'],
        }
        self.services.store.append_message(conversation_id, turn_id, 'user', blocks, row_meta)
        yield event(
            'user',
            text=text,
            references=bool(references),
            unresolved=unresolved,
            attachments=len(attachment['names']),
        )
