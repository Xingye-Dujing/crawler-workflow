"""The tool registry and the generic, domain-free tools.

A tool is a read-only verb, or a mutating verb that produces a proposal the user applies. Missing
ids and unsupported operations are refused by name; a result is bounded before it reaches the model.
Domain tools are registered by the host through ``HostAdapter.tools()`` or a plugin pack.

Two checks happen at *execution*, not just when schemas are offered: the account scope of a
contribution, and the exact allowlist the current turn advertised. Otherwise replayed history or a
narrow skill could still reach a mutating tool the user never saw in the tool list.
"""

from __future__ import annotations

import math
import re

from . import python_runtime
from .errors import AIError
from .types import ToolSpec
from .util import clip

_WORD = re.compile(r'[A-Za-z0-9_]{3,}')
_CJK = re.compile(r'[\u3400-\u9fff]{2,}')

#: BM25 constants. A tool list is a tiny corpus (tens of documents, each two sentences long), so
#: the classic defaults are the right ones: k1 controls term-frequency saturation, b the length
#: normalisation. Both are here rather than inline because a change to them is a change to what the
#: model is offered, and that is a measurement, not a taste (`tools/eval_tool_routing.py`).
_BM25_K1 = 1.2
_BM25_B = 0.75


def _query_terms(query: str) -> set[str]:
    terms = {word.lower() for word in _WORD.findall(query or '')}
    for run in _CJK.findall(query or ''):
        terms.update(run[index : index + 2] for index in range(len(run) - 1))
    return terms


def _tokens(text: str) -> list[str]:
    """The same vocabulary a query is read with: words, plus every CJK bigram.

    A query and a description must be tokenised by ONE function, or a word the user typed can
    never match the description that answers it.
    """
    tokens = [word.lower() for word in _WORD.findall(text or '')]
    for run in _CJK.findall(text or ''):
        tokens.extend(run[index : index + 2] for index in range(len(run) - 1))
    return tokens


def _bm25(specs: list[ToolSpec], terms: set[str]) -> dict[str, float]:
    """Relevance of each tool to the user's words, with IDF and length normalisation.

    The old scorer counted substring occurrences, so a long description mentioning "数据集" three
    times beat the tool actually named ``dataset_query``, and the universal read verbs (all phrased
    alike) crowded every skill out of the budget. IDF is what fixes that: a term every description
    carries scores nothing, and a term only the right tool carries scores most.
    """
    if not terms:
        return {spec.name: 0.0 for spec in specs}
    # A tool's name is read both whole and split on ``_``: a user who types ``dataset_query`` matches
    # the whole one, and a user who says "chart" must still reach ``chart_catalog`` — the underscore
    # is a word separator in a name, never part of one.
    docs = {
        spec.name: _tokens(spec.name + ' ' + spec.name.replace('_', ' ') + ' ' + spec.description) for spec in specs
    }
    average = sum(len(tokens) for tokens in docs.values()) / max(1, len(docs))
    document_frequency: dict[str, int] = {}
    for tokens in docs.values():
        for term in set(tokens) & terms:
            document_frequency[term] = document_frequency.get(term, 0) + 1
    scores = {}
    for spec in specs:
        tokens = docs[spec.name]
        length = max(1, len(tokens))
        total = 0.0
        for term in terms:
            frequency = tokens.count(term)
            if not frequency:
                continue
            seen = document_frequency.get(term, 0)
            # The +1 keeps the idf positive for a term every document carries (a whole-corpus term
            # must not become a penalty) while still rewarding the rare one.
            idf = math.log(1 + (len(docs) - seen + 0.5) / (seen + 0.5))
            total += (
                idf * (frequency * (_BM25_K1 + 1)) / (frequency + _BM25_K1 * (1 - _BM25_B + _BM25_B * length / average))
            )
        scores[spec.name] = total
    return scores


CONTROL_TOOLS = (
    'ask_user_question',
    'update_plan',
    'present_artifact',
    'request_approval',
    'recipe_start',
    'recipe_skip',
)
GENERIC_NAMES = frozenset(
    {
        'project_facts',
        'capabilities',
        'docs_search',
        'workspace_info',
        'workspace_list',
        'workspace_read',
        'workspace_write',
        'workspace_import',
        'run_cmd',
        'python_status',
        'python_run',
        'python_scripts',
        'python_script',
        'python_save_script',
        'python_fork_script',
        'python_delete_script',
        'python_files',
        'python_read',
        'python_write',
        'web_search',
        'fetch_url',
        'history_search',
    }
)

ASK_USER_SCHEMA = {
    'type': 'object',
    'properties': {
        'question': {'type': 'string'},
        'options': {'type': 'array', 'items': {'type': 'string'}},
        'allow_custom': {'type': 'boolean'},
        'detail': {'type': 'string', 'description': 'Exact facts the user is deciding about.'},
        #: Up to five related questions in one card; each answer comes back under the same call_id.
        'questions': {
            'type': 'array',
            'maxItems': 5,
            'items': {
                'type': 'object',
                'properties': {
                    'question': {'type': 'string'},
                    'options': {'type': 'array', 'items': {'type': 'string'}},
                    'allow_custom': {'type': 'boolean'},
                    'detail': {'type': 'object'},
                },
                'required': ['question', 'options'],
            },
        },
    },
    'anyOf': [{'required': ['question', 'options']}, {'required': ['questions']}],
}
PLAN_SCHEMA = {
    'type': 'object',
    'properties': {'steps': {'type': 'array', 'items': {'type': 'string'}}},
    'required': ['steps'],
}
ARTIFACT_SCHEMA = {
    'type': 'object',
    'properties': {
        'kind': {'type': 'string'},
        'title': {'type': 'string'},
        'payload': {'type': 'object'},
        'summary': {'type': 'string'},
    },
    'required': ['kind', 'payload'],
}
APPROVAL_SCHEMA = {
    'type': 'object',
    'properties': {
        'tool': {'type': 'string'},
        'args': {'type': 'object'},
        'question': {'type': 'string'},
        'detail': {'type': 'object', 'description': 'The exact arguments about to be used.'},
    },
    'required': ['tool', 'args'],
}


def control_specs() -> list[ToolSpec]:
    return [
        ToolSpec(
            'ask_user_question',
            'Pause and ask the user a question with explicit options.',
            ASK_USER_SCHEMA,
            control=True,
        ),
        ToolSpec('update_plan', 'Show a short execution plan to the user.', PLAN_SCHEMA, control=True),
        ToolSpec(
            'present_artifact',
            'Propose a write for the user to apply; never apply it yourself.',
            ARTIFACT_SCHEMA,
            control=True,
        ),
        ToolSpec('request_approval', 'Ask the user to approve one exact mutating call.', APPROVAL_SCHEMA, control=True),
        ToolSpec(
            'recipe_start',
            'Start one declared recipe (an ordered plan whose steps need evidence). Use it when the '
            'user asks for that multi-step job; the server then offers only the current step tool.',
            {
                'type': 'object',
                'properties': {'recipe_id': {'type': 'string'}},
                'required': ['recipe_id'],
            },
            control=True,
        ),
        ToolSpec(
            'recipe_skip',
            'Record that the user chose to skip the current recipe step, with the reason. The step '
            'stays in the final report as skipped; evidence is never invented.',
            {
                'type': 'object',
                'properties': {'reason': {'type': 'string'}},
            },
            control=True,
        ),
    ]


# ── generic handlers ────────────────────────────────────────────────────────────


def _tool_project_facts(args, ctx):
    return {'text': ctx['context'].project_facts()}


def _tool_capabilities(args, ctx):
    host = ctx['host']
    return {
        'provider': ctx.get('provider_id', ''),
        'host': host.environment().capabilities(),
        'domain': host.capabilities(),
    }


def _tool_docs_search(args, ctx):
    if not ctx['host'].doc_roots():
        raise AIError('docs.unavailable', kind='capability', key='docs.unavailable', reason='this host exposes no docs')
    return {'results': ctx['context'].docs_search(str(args.get('query') or ''), int(args.get('limit') or 3))}


def _tool_workspace_info(args, ctx):
    return ctx['workspace'].describe()


def _tool_workspace_list(args, ctx):
    return ctx['workspace'].list(str(args.get('path') or ''))


def _tool_workspace_read(args, ctx):
    return ctx['workspace'].read(str(args.get('path') or ''))


def _tool_workspace_write(args, ctx):
    return ctx['workspace'].write(str(args.get('path') or ''), str(args.get('content') or ''))


def _tool_workspace_import(args, ctx):
    relative = str(args.get('path') or '')
    target = ctx['workspace'].resolve(relative, must_exist=True)
    try:
        return {'import': ctx['host'].import_table(str(target)), 'path': relative}
    except NotImplementedError as exc:
        raise AIError('import.unavailable', kind='capability', key='import.unavailable', reason=str(exc)) from exc


def _tool_run_cmd(args, ctx):
    env = ctx['host'].environment()
    if env.cloud:
        raise AIError('cmd.cloudRefused', kind='capability', key='cmd.cloudRefused')
    return ctx['workspace'].run(
        str(args.get('command') or ''),
        cwd=str(args.get('cwd') or ''),
        allow=ctx['host'].command_allowlist(),
        timeout=int(args.get('timeout') or 30),
        cancel_event=ctx.get('cancel_event'),
    )


def _require_python(ctx) -> None:
    if not ctx['host'].environment().local:
        raise AIError('python.cloudRefused', kind='capability', key='python.cloudRefused')
    if not ctx['settings'].get('python.allowed', False):
        raise AIError('python.disabled', kind='capability', key='python.disabled', reason='python.allowed is off')


def _tool_python_status(args, ctx):
    return ctx['python'].status(ctx['settings'])


def _tool_python_scripts(args, ctx):
    _require_python(ctx)
    return {
        'scripts': [
            {key: row[key] for key in ('id', 'name', 'inputs', 'outputs', 'tags', 'version', 'builtin')}
            for row in ctx['library'].all(ctx['account'])
        ]
    }


def _tool_python_script(args, ctx):
    _require_python(ctx)
    row = ctx['library'].get(ctx['account'], str(args.get('id') or ''))
    if not row:
        raise AIError(
            'python.scriptMissing', kind='not_found', key='python.scriptMissing', reason=str(args.get('id') or '')
        )
    return {
        'script': {
            key: row.get(key) for key in ('id', 'name', 'code', 'inputs', 'outputs', 'tags', 'version', 'builtin')
        }
    }


def _tool_python_save_script(args, ctx):
    _require_python(ctx)
    return {'script': ctx['library'].save(ctx['account'], dict(args))}


def _tool_python_fork_script(args, ctx):
    _require_python(ctx)
    return {'script': ctx['library'].fork(ctx['account'], str(args.get('id') or ''))}


def _tool_python_delete_script(args, ctx):
    _require_python(ctx)
    return {'deleted': ctx['library'].delete(ctx['account'], str(args.get('id') or ''))}


def _tool_python_files(args, ctx):
    _require_python(ctx)
    from pathlib import Path

    root = Path(str(ctx['workspace'].describe().get('folder') or ''))
    if not root.exists():
        return {'files': []}
    return {'files': [str(path) for path in root.rglob('*') if path.is_file() and 'runs' not in path.parts][:200]}


def _tool_python_read(args, ctx):
    _require_python(ctx)
    return ctx['workspace'].read(str(args.get('path') or ''))


def _tool_python_write(args, ctx):
    _require_python(ctx)
    return ctx['workspace'].write(str(args.get('path') or ''), str(args.get('content') or ''))


def _tool_python_run(args, ctx):
    _require_python(ctx)
    code = str(args.get('code') or '')
    script_id = str(args.get('script_id') or '')
    if script_id:
        code = ctx['library'].code(ctx['account'], script_id)
        if not code:
            raise AIError('python.scriptMissing', kind='not_found', key='python.scriptMissing', reason=script_id)
    try:
        return ctx['python'].run_code(
            code,
            rows=args.get('rows') or [],
            args=args.get('args') or {},
            timeout=int(args.get('timeout') or 10),
            python_bin=str(ctx['settings'].get('python.path', '') or ''),
            cancel_event=ctx.get('cancel_event'),
        )
    except (RuntimeError, ValueError, TimeoutError) as exc:
        raise AIError('python.failed', kind='refused', key='python.failed', reason=str(exc)) from exc


def _tool_web_search(args, ctx):
    results = ctx['host'].search(
        str(args.get('query') or ''), int(args.get('limit') or 3), api_key=str(ctx.get('api_key') or '')
    )
    if not results:
        raise AIError(
            'search.unavailable', kind='capability', key='search.unavailable', reason='this host has no search service'
        )
    return {'results': results}


def _tool_fetch_url(args, ctx):
    try:
        text = ctx['host'].fetch(str(args.get('url') or ''), api_key=str(ctx.get('api_key') or ''))
    except NotImplementedError as exc:
        raise AIError('fetch.unavailable', kind='capability', key='fetch.unavailable', reason=str(exc)) from exc
    return {'text': clip(text, 8000)}


def _tool_history_search(args, ctx):
    term = str(args.get('query') or '').strip().lower()
    if not term:
        raise AIError('history.empty', kind='refused', key='history.empty')
    conversation = ctx['store'].get_conversation(ctx.get('conversation_id', ''), ctx.get('account', ''))
    if not conversation:
        return {'results': []}
    results = []
    from .types import message_text

    for message in ctx['store'].list_messages(conversation['id']):
        text = message_text(message)
        if term in text.lower():
            results.append({'role': message['role'], 'text': clip(text, 1200)})
        if len(results) >= 10:
            break
    return {'results': results}


GENERIC_HANDLERS = {
    'project_facts': _tool_project_facts,
    'capabilities': _tool_capabilities,
    'docs_search': _tool_docs_search,
    'workspace_info': _tool_workspace_info,
    'workspace_list': _tool_workspace_list,
    'workspace_read': _tool_workspace_read,
    'workspace_write': _tool_workspace_write,
    'workspace_import': _tool_workspace_import,
    'run_cmd': _tool_run_cmd,
    'python_status': _tool_python_status,
    'python_scripts': _tool_python_scripts,
    'python_script': _tool_python_script,
    'python_save_script': _tool_python_save_script,
    'python_fork_script': _tool_python_fork_script,
    'python_delete_script': _tool_python_delete_script,
    'python_files': _tool_python_files,
    'python_read': _tool_python_read,
    'python_write': _tool_python_write,
    'python_run': _tool_python_run,
    'web_search': _tool_web_search,
    'fetch_url': _tool_fetch_url,
    'history_search': _tool_history_search,
}


def generic_specs() -> list[ToolSpec]:
    """Declare every generic tool in one place. Schemas are intentionally small."""

    def obj(required=(), **props):
        return {
            'type': 'object',
            'properties': {key: {'type': value} for key, value in props.items()},
            'required': list(required),
        }

    # (name, description, properties, mutating). Mutating local tools are local_only so a cloud
    # host hides them from schemas() — a UI entry that cannot work must not be offered.
    declarations = [
        ('project_facts', 'Read the generated project facts. Never hand-write a second list.', {}, False),
        ('capabilities', 'Read host and provider capabilities.', {}, False),
        ('docs_search', 'Keyword-search the host documentation.', {'query': 'string', 'limit': 'integer'}, False),
        ('workspace_info', 'Show whether a working folder is configured.', {}, False),
        ('workspace_list', 'List names in a folder inside the working folder.', {'path': 'string'}, False),
        ('workspace_read', 'Read a text file inside the working folder.', {'path': 'string'}, True),
        (
            'workspace_write',
            'Write a text file inside the working folder.',
            {'path': 'string', 'content': 'string'},
            True,
        ),
        ('workspace_import', 'Import a local file through the host importer.', {'path': 'string'}, True),
        ('run_cmd', 'Run one allow-listed command; no shell, no pipes.', {'command': 'string', 'cwd': 'string'}, True),
        ('python_status', 'Read the Python interpreter status.', {}, False),
        ('python_scripts', 'List the saved Python scripts.', {}, False),
        ('python_script', 'Read one saved script by id.', {'id': 'string'}, False),
        (
            'python_save_script',
            'Save a script to the library.',
            {'id': 'string', 'name': 'string', 'code': 'string'},
            True,
        ),
        ('python_fork_script', 'Fork a saved script without overwriting it.', {'id': 'string'}, True),
        ('python_delete_script', 'Delete a saved script.', {'id': 'string'}, True),
        ('python_files', 'List Python files in the working folder.', {}, False),
        ('python_read', 'Read a text file for the Python workspace.', {'path': 'string'}, True),
        ('python_write', 'Write a text file in the Python workspace.', {'path': 'string', 'content': 'string'}, True),
        (
            'python_run',
            'Run a bounded Python script over JSON Lines rows.',
            {'code': 'string', 'script_id': 'string', 'rows': 'array', 'args': 'object'},
            True,
        ),
        ('web_search', 'Search the web through the host service.', {'query': 'string'}, False),
        ('fetch_url', 'Fetch a URL as text through the host service.', {'url': 'string'}, False),
        ('history_search', 'Search this conversation transcript.', {'query': 'string'}, False),
    ]
    specs = []
    for name, description, props, mutating in declarations:
        required = (
            ('path',)
            if name in ('workspace_read', 'workspace_write', 'workspace_import', 'python_read', 'python_write')
            else ()
        )
        specs.append(
            ToolSpec(
                name,
                description,
                obj(required, **props),
                permission='write:workspace' if mutating else 'read:project',
                handler=GENERIC_HANDLERS[name],
                mutating=mutating,
                local_only=name in LOCAL_ONLY_GENERIC,
            )
        )
    return specs


LOCAL_ONLY_GENERIC = frozenset(
    {
        'workspace_info',
        'workspace_list',
        'workspace_read',
        'workspace_write',
        'workspace_import',
        'run_cmd',
        'python_status',
        'python_scripts',
        'python_script',
        'python_save_script',
        'python_fork_script',
        'python_delete_script',
        'python_files',
        'python_read',
        'python_write',
        'python_run',
    }
)


class ToolRegistry:
    def __init__(self, store, host, settings, context, workspace_provider, scopes=None, library=None, python=None):
        self.store = store
        self.host = host
        self.settings = settings
        self.context = context
        self.workspace_provider = workspace_provider
        self.scopes = scopes
        self.library = library
        self.python = python or python_runtime
        self._extra: dict[str, ToolSpec] = {}
        self._specs: dict[str, ToolSpec] = {spec.name: spec for spec in generic_specs()}
        self._specs.update({spec.name: spec for spec in control_specs()})

    def register(self, spec: ToolSpec, *, owner: str = '') -> None:
        if spec.name in CONTROL_TOOLS:
            raise AIError('tool.reserved', kind='refused', key='tool.reserved', reason=spec.name)
        if spec.name in self._specs or spec.name in self._extra:
            raise AIError('tool.builtinConflict', kind='refused', key='tool.builtinConflict', reason=spec.name)
        self._extra[spec.name] = spec
        if owner and self.scopes is not None:
            self.scopes.remember(spec.name, owner)

    def unregister(self, name: str) -> None:
        self._extra.pop(name, None)
        if self.scopes is not None:
            self.scopes.forget(name)

    def get(self, name: str, account: str = '') -> ToolSpec | None:
        spec = self._extra.get(name) or self._specs.get(name)
        if account and self.scopes is not None and name in self._extra:
            if not self.scopes.visible(name, account):
                raise AIError('tool.unknown', kind='refused', key='tool.unknown', reason=name)
        return spec

    def names(self) -> set[str]:
        """Every registered name (control, generic and host-added), for recipe validation."""
        return set(self._specs) | set(self._extra)

    def schemas(
        self,
        allowed: set[str] | None = None,
        *,
        query: str = '',
        limit: int = 0,
        required=(),
        priority=(),
    ) -> list[dict]:
        """Control tools are always present; domain/generic tools respect the skill allowlist.

        ``limit`` is the strict-mode tool budget over those domain/generic tools: the current recipe
        step, the host's core verbs and the ``priority`` names (the active skill's own tools) come
        first, then the best of the rest by relevance to the user's words (BM25 over name +
        description).

        Three rules this used to break. **The budget is a budget**: a host that declared more core
        verbs than slots was offered all of them, so a "12 tool" list was really 25. **A core verb
        is a priority, not an immunity**: it gets the first slots and is trimmed by relevance when
        there are more of them than slots. And **a skill's own tools are the floor of the budget**:
        the point of a skill is that its verbs are reachable, so a skill declaring more tools than
        the budget raises it rather than being cut — a lexical ranking of a Chinese question against
        English descriptions has no signal to decide with (that needs a multilingual embedding, see
        the tool-routing eval). ``required`` (the recipe's current step) is the only truly immune
        name.
        """
        specs = [self._specs[name] for name in CONTROL_TOOLS]
        cloud = self.host.environment().cloud
        candidates = [
            spec
            for name, spec in {**self._specs, **self._extra}.items()
            if name not in CONTROL_TOOLS and (allowed is None or name in allowed) and not (spec.local_only and cloud)
        ]
        if limit and len(candidates) > limit:
            by_name = {spec.name: spec for spec in candidates}
            scores = _bm25(candidates, _query_terms(query))
            picked = [by_name[name] for name in required if name in by_name]
            taken = {spec.name for spec in picked}
            priority_specs = [by_name[name] for name in priority if name in by_name and name not in taken]
            picked.extend(priority_specs)
            taken.update(spec.name for spec in picked)
            # The skill's own list is the floor; core verbs then fill what is left, best first.
            budget = max(limit, len(picked))
            core = sorted(
                (by_name[name] for name in (self.host.core_tools() or ()) if name in by_name and name not in taken),
                key=lambda spec: (-scores[spec.name], spec.name),
            )
            picked.extend(core[: max(0, budget - len(picked))])
            taken.update(spec.name for spec in picked)
            best = sorted(candidates, key=lambda spec: (-scores[spec.name], spec.name))
            for spec in best:
                if len(picked) >= budget:
                    break
                if spec.name not in taken:
                    picked.append(spec)
                    taken.add(spec.name)
            candidates = picked
        specs.extend(candidates)
        return [spec.schema() for spec in specs]

    def check(self, name: str, ctx: dict) -> ToolSpec:
        account = str(ctx.get('account') or '')
        spec = self.get(name, account)
        if spec is None:
            raise AIError(f'tool.unknown: {name}', kind='refused', key='tool.unknown', reason=name)
        if spec.local_only and self.host.environment().cloud:
            raise AIError('tool.cloudRefused', kind='capability', key='tool.cloudRefused', reason=name)
        return spec

    def execute(self, name: str, args: dict, ctx: dict, *, allowed: set[str] | None = None) -> dict:
        if allowed is not None and name not in allowed and name not in CONTROL_TOOLS:
            raise AIError(
                f'tool.notOffered: {name}',
                kind='refused',
                key='tool.notOffered',
                reason=name,
                detail='not offered in this turn',
            )
        spec = self.check(name, ctx)
        handler = spec.handler
        if handler is None:
            raise AIError('tool.noHandler', kind='refused', key='tool.noHandler', reason=name)
        runtime_ctx = {
            'store': self.store,
            'host': self.host,
            'settings': self.settings,
            'context': self.context,
            'workspace': self.workspace_provider(ctx.get('account', 'default')),
            'account': ctx.get('account', 'default'),
            'conversation_id': ctx.get('conversation_id', ''),
            'provider_id': ctx.get('provider_id', ''),
            'cancel_event': ctx.get('cancel_event'),
            'library': self.library,
            'python': self.python,
            'api_key': ctx.get('api_key', ''),
            'model': ctx.get('model', ''),
        }
        try:
            result = handler(args or {}, runtime_ctx)
        except AIError:
            raise
        except (KeyError, TypeError, ValueError, NotImplementedError) as exc:
            raise AIError('tool.badArgs', kind='refused', key='tool.badArgs', reason=f'{name}: {exc}') from exc
        if not isinstance(result, dict):
            result = {'result': result}
        limit = int(self.settings.get('tools.max_result_chars', 12000))
        rendered = str(result)
        if len(rendered) > limit:
            return {'result': rendered[:limit], 'truncated': True, 'tool': name}
        return result
