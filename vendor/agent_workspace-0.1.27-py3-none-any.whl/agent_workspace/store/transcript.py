"""Conversations, messages, turns, the durable event log, pending calls, commands and the inbox.

The transcript is append-only and its ORDER is the product: a message's ``seq`` is MAX+1 (never
COUNT), a turn's events are one monotonic log a reattach replays from ``after=last_seq``, and an
interrupt (``pending_calls``) or a queued message (``turn_inbox``) is taken exactly once under one
lock — answering twice must not execute an approved tool twice.
"""

from __future__ import annotations

import json

from ..fsm import TURN
from ..types import new_id
from ..util import utc_now
from .base import BaseMixin


class TranscriptMixin:
    # ── conversations ──────────────────────────────────────────────────────────

    def create_conversation(self, account: str, title: str = '', conversation_id: str = '') -> dict:
        conversation_id = conversation_id or new_id('conv')
        now = utc_now()
        self._run(
            'INSERT INTO conversations (id, account, title, created_at, updated_at) VALUES (?,?,?,?,?)',
            (conversation_id, account, title, now, now),
        )
        return self.get_conversation(conversation_id, account)

    def get_conversation(self, conversation_id: str, account: str = '') -> dict:
        if not conversation_id:
            return {}
        sql = 'SELECT * FROM conversations WHERE id=?'
        args = [conversation_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        return self._row(self._db.execute(sql, args).fetchone())

    def list_conversations(
        self, account: str, *, query: str = '', archived: bool = False, limit: int = 50, offset: int = 0
    ) -> list[dict]:
        sql = 'SELECT * FROM conversations WHERE account=? AND archived=?'
        args: list = [account, 1 if archived else 0]
        if query:
            # Escape LIKE metacharacters so a title search is literal.
            escaped = query.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
            sql += " AND title LIKE ? ESCAPE '\\'"
            args.append(f'%{escaped}%')
        sql += ' ORDER BY pinned DESC, updated_at DESC LIMIT ? OFFSET ?'
        args.extend([limit, offset])
        with self._lock:
            return [self._row(row) for row in self._db.execute(sql, args).fetchall()]

    def patch_conversation(self, conversation_id: str, account: str, **fields) -> dict:
        allowed = {'title', 'pinned', 'archived'}
        updates = {key: value for key, value in fields.items() if key in allowed}
        if not updates:
            return self.get_conversation(conversation_id, account)
        updates['updated_at'] = utc_now()
        assignments = ', '.join(f'{key}=?' for key in updates)
        self._run(
            f'UPDATE conversations SET {assignments} WHERE id=? AND account=?',
            (*updates.values(), conversation_id, account),
        )
        return self.get_conversation(conversation_id, account)

    def delete_conversation(self, conversation_id: str, account: str) -> bool:
        with self._lock:
            self._db.execute('DELETE FROM conversations WHERE id=? AND account=?', (conversation_id, account))
            # Conversation ids are globally unique; only the tables that carry an account column
            # can be scoped by it (messages deliberately have no account column of their own).
            self._db.execute('DELETE FROM messages WHERE conversation_id=?', (conversation_id,))
            self._db.execute(
                'DELETE FROM turn_events WHERE turn_id IN (SELECT id FROM turns WHERE conversation_id=?)',
                (conversation_id,),
            )
            self._db.execute(
                'DELETE FROM turn_commands WHERE turn_id IN (SELECT id FROM turns WHERE conversation_id=?)',
                (conversation_id,),
            )
            for table in ('artifacts', 'usage', 'files', 'turns', 'pending_calls', 'turn_inbox'):
                self._db.execute(
                    f'DELETE FROM {table} WHERE conversation_id=? AND account=?', (conversation_id, account)
                )
            self._db.execute('DELETE FROM agent_steps WHERE conversation_id=?', (conversation_id,))
            self._db.commit()
        return True

    def export_conversation(self, conversation_id: str, account: str, fmt: str = 'json') -> str:
        conv = self.get_conversation(conversation_id, account)
        messages = self.list_messages(conversation_id)
        if fmt == 'md':
            lines = [f'# {conv.get("title") or "Conversation"}', '']
            for message in messages:
                speaker = {'user': 'User', 'assistant': 'Assistant'}.get(message['role'], message['role'])
                from ..types import message_text

                lines.extend([f'## {speaker} · {message["created_at"]}', '', message_text(message), ''])
            return '\n'.join(lines)
        return json.dumps({'conversation': conv, 'messages': messages}, ensure_ascii=False, indent=2)

    # ── messages ───────────────────────────────────────────────────────────────

    def next_seq(self, conversation_id: str) -> int:
        with self._lock:
            row = self._db.execute(
                'SELECT COALESCE(MAX(seq), 0) + 1 AS n FROM messages WHERE conversation_id=?',
                (conversation_id,),
            ).fetchone()
        return int(row['n'])

    def append_message(
        self,
        conversation_id: str,
        turn_id: str,
        role: str,
        blocks: list,
        meta: dict | None = None,
        status: str = 'done',
        message_id: str = '',
    ) -> dict:
        message_id = message_id or new_id('msg')
        seq = self.next_seq(conversation_id)
        meta = meta or {}
        self._run(
            """INSERT INTO messages (id, conversation_id, turn_id, role, status, seq, blocks, meta, created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (
                message_id,
                conversation_id,
                turn_id,
                role,
                status,
                seq,
                json.dumps(blocks, ensure_ascii=False),
                json.dumps(meta, ensure_ascii=False),
                utc_now(),
            ),
        )
        self._run('UPDATE conversations SET updated_at=? WHERE id=?', (utc_now(), conversation_id))
        return self.get_message(message_id)

    def get_message(self, message_id: str) -> dict:
        row = self._db.execute('SELECT * FROM messages WHERE id=?', (message_id,)).fetchone()
        return self._decode_message(row)

    def delete_message(self, message_id: str) -> bool:
        cursor = self._run('DELETE FROM messages WHERE id=?', (message_id,))
        return cursor.rowcount > 0

    def list_conversations_all(self) -> list[dict]:
        with self._lock:
            return [self._row(row) for row in self._db.execute('SELECT id FROM conversations').fetchall()]

    @staticmethod
    def _decode_message(row) -> dict:
        data = BaseMixin._row(row)
        if not data:
            return {}
        data['blocks'] = json.loads(data.get('blocks') or '[]')
        data['meta'] = json.loads(data.get('meta') or '{}')
        return data

    def list_messages(self, conversation_id: str, limit: int = 0) -> list[dict]:
        sql = 'SELECT * FROM messages WHERE conversation_id=? ORDER BY seq'
        args: list = [conversation_id]
        if limit:
            sql = 'SELECT * FROM messages WHERE conversation_id=? ORDER BY seq DESC LIMIT ?'
            args.append(limit)
            with self._lock:
                rows = self._db.execute(sql, args).fetchall()
            return [self._decode_message(row) for row in reversed(rows)]
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        return [self._decode_message(row) for row in rows]

    def last_message(self, conversation_id: str, role: str = '') -> dict:
        sql = 'SELECT * FROM messages WHERE conversation_id=?'
        args: list = [conversation_id]
        if role:
            sql += ' AND role=?'
            args.append(role)
        sql += ' ORDER BY seq DESC LIMIT 1'
        return self._decode_message(self._db.execute(sql, args).fetchone())

    def update_message(self, message_id: str, *, blocks=None, meta=None, status: str = '') -> dict:
        updates: dict = {}
        if blocks is not None:
            updates['blocks'] = json.dumps(blocks, ensure_ascii=False)
        if meta is not None:
            updates['meta'] = json.dumps(meta, ensure_ascii=False)
        if status:
            updates['status'] = status
        if updates:
            assignments = ', '.join(f'{key}=?' for key in updates)
            self._run(f'UPDATE messages SET {assignments} WHERE id=?', (*updates.values(), message_id))
        return self.get_message(message_id)

    def settle_streams(self, conversation_id: str, status: str = 'interrupted') -> int:
        """Mark unfinished rows when a client disconnects — no vanished answers on reload."""
        cursor = self._run(
            "UPDATE messages SET status=? WHERE conversation_id=? AND status='streaming'",
            (status, conversation_id),
        )
        return cursor.rowcount

    # ── turns and their durable log ────────────────────────────────────────────

    def create_turn(
        self,
        turn_id: str,
        conversation_id: str,
        account: str,
        *,
        provider: str = '',
        model: str = '',
        skill: str = '',
    ) -> dict:
        now = utc_now()
        self._run(
            """INSERT INTO turns (id, conversation_id, account, state, provider, model, skill,
               created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)""",
            (turn_id, conversation_id, account, TURN.start, provider, model, skill, now, now),
        )
        return self.get_turn(turn_id)

    def get_turn(self, turn_id: str, account: str = '') -> dict:
        sql = 'SELECT * FROM turns WHERE id=?'
        args: list = [turn_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        return self._row(self._db.execute(sql, args).fetchone())

    def list_turns(self, conversation_id: str, account: str = '', limit: int = 20) -> list[dict]:
        sql = 'SELECT * FROM turns WHERE conversation_id=?'
        args: list = [conversation_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        sql += ' ORDER BY created_at DESC LIMIT ?'
        args.append(limit)
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        return [self._row(row) for row in rows]

    def set_turn_state(
        self, turn_id: str, state: str, *, stop_reason: str | None = None, error: str | None = None
    ) -> dict:
        updates: dict = {'state': state, 'updated_at': utc_now()}
        if stop_reason is not None:
            updates['stop_reason'] = stop_reason
        if error is not None:
            updates['error'] = error
        assignments = ', '.join(f'{key}=?' for key in updates)
        self._run(f'UPDATE turns SET {assignments} WHERE id=?', (*updates.values(), turn_id))
        return self.get_turn(turn_id)

    def set_turn_origin(self, turn_id: str, *, provider: str = '', model: str = '', skill: str = '') -> dict:
        """Record the RESOLVED origin once the engine knows it (a restart resumes the same model)."""
        self._run(
            'UPDATE turns SET provider=?, model=?, skill=?, updated_at=? WHERE id=?',
            (provider, model, skill, utc_now(), turn_id),
        )
        return self.get_turn(turn_id)

    def append_turn_event(self, turn_id: str, payload: dict) -> int:
        """Append one event to a turn's durable log; the next slot is MAX(seq)+1, never COUNT(*)."""
        with self._lock:
            row = self._db.execute('SELECT COALESCE(MAX(seq), 0) FROM turn_events WHERE turn_id=?', (turn_id,))
            seq = int(row.fetchone()[0]) + 1
            self._db.execute(
                'INSERT INTO turn_events (turn_id, seq, payload, created_at) VALUES (?,?,?,?)',
                (turn_id, seq, json.dumps(payload, ensure_ascii=False, default=str), utc_now()),
            )
            self._db.commit()
        return seq

    def last_turn_event_seq(self, turn_id: str) -> int:
        with self._lock:
            row = self._db.execute('SELECT COALESCE(MAX(seq), 0) FROM turn_events WHERE turn_id=?', (turn_id,))
            return int(row.fetchone()[0])

    def turn_events(self, turn_id: str, after: int = 0, limit: int = 2000) -> list[dict]:
        """Events after ``after``, in order — the reattach path (``after=last_seq``)."""
        with self._lock:
            rows = self._db.execute(
                'SELECT seq, payload FROM turn_events WHERE turn_id=? AND seq>? ORDER BY seq LIMIT ?',
                (turn_id, int(after or 0), limit),
            ).fetchall()
        return [{'seq': int(row['seq']), **json.loads(row['payload'])} for row in rows]

    def settle_interrupted_turns(self) -> int:
        """Boot recovery: a turn that was mid-flight has no runner any more. A turn ``awaiting_user``
        is NOT interrupted — its question is the durable interrupt ADR-003 keeps answerable."""
        cursor = self._run(
            "UPDATE turns SET state='interrupted', updated_at=? "
            "WHERE state NOT IN ('settled','interrupted','awaiting_user')",
            (utc_now(),),
        )
        return cursor.rowcount

    # ── pending calls (the durable interrupt) ─────────────────────────────────

    def save_pending_call(
        self,
        *,
        call_id: str,
        conversation_id: str,
        account: str,
        turn_id: str,
        kind: str,
        tool: str = '',
        args: dict | None = None,
        provider: str = '',
        model: str = '',
        skill: str = '',
    ) -> dict:
        """Persist an interrupt. A question that exists only in memory dies with the process."""
        self._run(
            """INSERT INTO pending_calls (call_id, conversation_id, account, turn_id, kind, tool,
               args, provider, model, skill, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                call_id,
                conversation_id,
                account,
                turn_id,
                kind,
                tool,
                json.dumps(args or {}, ensure_ascii=False, default=str),
                provider,
                model,
                skill,
                utc_now(),
            ),
        )
        return self.get_pending_call(call_id, account)

    @staticmethod
    def _decode_pending(row) -> dict:
        data = BaseMixin._row(row)
        if not data:
            return {}
        data['args'] = json.loads(data.get('args') or '{}')
        return data

    def get_pending_call(self, call_id: str, account: str = '') -> dict:
        sql = 'SELECT * FROM pending_calls WHERE call_id=?'
        args: list = [call_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        return self._decode_pending(self._db.execute(sql, args).fetchone())

    def pending_calls(self, conversation_id: str, account: str = '') -> list[dict]:
        sql = 'SELECT * FROM pending_calls WHERE conversation_id=?'
        args: list = [conversation_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        sql += ' ORDER BY created_at'
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        return [self._decode_pending(row) for row in rows]

    def claim_pending_call(self, call_id: str, account: str = '') -> dict:
        """Take an interrupt exactly once. A second answer for the same call gets nothing.

        Answering is a command, not an event: two clicks (or two tabs) must not execute the
        approved tool twice, so the row is selected and deleted under one lock.
        """
        with self._lock:
            pending = self.get_pending_call(call_id, account)
            if pending:
                self._db.execute('DELETE FROM pending_calls WHERE call_id=?', (call_id,))
                self._db.commit()
        return pending

    # ── commands and the inbox ────────────────────────────────────────────────

    def add_turn_command(self, turn_id: str, kind: str, payload: dict | None = None) -> None:
        """Persist one command for a running turn. ``stop`` is the first; the runner consumes it."""
        self._run(
            'INSERT INTO turn_commands (turn_id, kind, payload, created_at) VALUES (?,?,?,?)',
            (turn_id, kind, json.dumps(payload or {}, ensure_ascii=False, default=str), utc_now()),
        )

    def take_turn_commands(self, turn_id: str) -> list[tuple[str, dict]]:
        """Every pending command for a turn, removed — one consumer, one delivery."""
        with self._lock:
            rows = self._db.execute(
                'SELECT kind, payload FROM turn_commands WHERE turn_id=? ORDER BY created_at', (turn_id,)
            ).fetchall()
            if rows:
                self._db.execute('DELETE FROM turn_commands WHERE turn_id=?', (turn_id,))
                self._db.commit()
        return [(str(row['kind']), json.loads(row['payload'] or '{}')) for row in rows]

    def enqueue_turn(self, conversation_id: str, account: str, payload: dict) -> dict:
        """A message that arrived while a question waits. Its request is stored WITHOUT the key."""
        inbox_id = new_id('mailbox')
        self._run(
            'INSERT INTO turn_inbox (id, conversation_id, account, payload, created_at) VALUES (?,?,?,?,?)',
            (inbox_id, conversation_id, account, json.dumps(payload, ensure_ascii=False, default=str), utc_now()),
        )
        return self.get_inbox_message(inbox_id, account)

    @staticmethod
    def _decode_inbox(row) -> dict:
        data = BaseMixin._row(row)
        if not data:
            return {}
        data['payload'] = json.loads(data.get('payload') or '{}')
        return data

    def get_inbox_message(self, inbox_id: str, account: str = '') -> dict:
        sql = 'SELECT * FROM turn_inbox WHERE id=?'
        args: list = [inbox_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        return self._decode_inbox(self._db.execute(sql, args).fetchone())

    def inbox(self, conversation_id: str, account: str = '') -> list[dict]:
        sql = 'SELECT * FROM turn_inbox WHERE conversation_id=?'
        args: list = [conversation_id]
        if account:
            sql += ' AND account=?'
            args.append(account)
        sql += ' ORDER BY created_at'
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        return [self._decode_inbox(row) for row in rows]

    def take_inbox(self, inbox_id: str, account: str = '') -> dict:
        """Take one queued message for execution — once, like an interrupt."""
        with self._lock:
            queued = self.get_inbox_message(inbox_id, account)
            if queued:
                self._db.execute('DELETE FROM turn_inbox WHERE id=?', (inbox_id,))
                self._db.commit()
        return queued
