"""The attachment seam: a host extracts, the framework bounds and routes.

A host sends already-extracted material on ``ChatRequest.context_payload['attachments']``::

    [{'name': 'paper.pdf', 'text': '...', 'image': 'data:image/png;base64,...', 'file_id': 'file_1'}]

Extracted text always travels — it is just text. An image needs a provider that declares BOTH
``vision`` and ``inline_images``; a files-only surface has no transport in this framework yet, so
the request is refused by name instead of silently dropping the picture. Nothing here reads a file
or calls a parser: extraction belongs to the host, which knows what its files are.
"""

from __future__ import annotations

from dataclasses import dataclass

from .errors import AIError

#: One message may carry a handful of attachments; beyond that it stops being one question.
MAX_ATTACHMENTS = 8
#: Extracted text is bounded like any other context block.
MAX_TEXT_CHARS = 40000
#: A data URL longer than this is refused; a 10 MB image is already more than any vision model takes.
MAX_IMAGE_CHARS = 14_000_000
TRUNCATED = '\n[attachment text truncated]'


@dataclass(frozen=True)
class Attachment:
    name: str = ''
    text: str = ''
    image: str = ''
    file_id: str = ''


def normalize(items) -> list[Attachment]:
    """Accept dicts (or a bare string per item); anything else is ignored, not guessed."""
    found = []
    for item in list(items or [])[:MAX_ATTACHMENTS]:
        if isinstance(item, str):
            found.append(Attachment(text=item))
            continue
        if not isinstance(item, dict):
            continue
        found.append(
            Attachment(
                name=str(item.get('name') or ''),
                text=str(item.get('text') or ''),
                image=str(item.get('image') or ''),
                file_id=str(item.get('file_id') or ''),
            )
        )
    return found


def prepare(items, *, provider, model: str = '') -> dict:
    """Turn host attachments into ``{text, images, names}`` or refuse the part this provider lacks.

    The refusal is a capability answer, not a crash: the host shows the key and can offer to switch
    models. Text is truncated with a marker; images are passed through unchanged (already inlined).
    """
    attachments = normalize(items)
    if not attachments:
        return {'text': '', 'images': [], 'names': []}
    texts = []
    images = []
    names = []
    for attachment in attachments:
        label = f'[{attachment.name}]\n' if attachment.name else ''
        if attachment.text:
            texts.append(label + attachment.text)
        if attachment.image:
            if not provider.supports('vision', model):
                raise AIError(
                    'attachment.visionRequired',
                    kind='capability',
                    key='attachment.visionRequired',
                    reason=attachment.name or 'image',
                )
            if not provider.supports('inline_images', model):
                raise AIError(
                    'attachment.inlineRequired',
                    kind='capability',
                    key='attachment.inlineRequired',
                    reason=attachment.name or 'image',
                )
            if len(attachment.image) > MAX_IMAGE_CHARS:
                raise AIError(
                    'attachment.imageTooLarge',
                    kind='refused',
                    key='attachment.imageTooLarge',
                    reason=attachment.name or 'image',
                )
            images.append(attachment.image)
            names.append(attachment.name)
        elif attachment.name:
            names.append(attachment.name)
    text = '\n\n'.join(texts)
    if len(text) > MAX_TEXT_CHARS:
        text = text[:MAX_TEXT_CHARS] + TRUNCATED
    return {'text': text, 'images': images, 'names': names}
