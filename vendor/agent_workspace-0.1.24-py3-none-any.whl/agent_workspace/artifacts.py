"""Artifact declarations: one validator and one preview per kind, supplied by the host.

The engine never invents what an artifact means. A host registers a validator (``payload ->
list[str]`` problems, empty means valid) and a preview (``payload -> dict``) for each kind it
applies; the engine runs the validator before an artifact is stored or applied, and asks for the
preview when it presents the card. A kind nobody declared is not refused — it is marked
``unvalidated`` so a host can still show it as text — but a declared validator that fails or raises
is a named refusal, never a silently accepted write.
"""

from __future__ import annotations

from typing import Callable

from .errors import AIError


class ArtifactRegistry:
    """The engine-side half of the artifact seam; hosts fill it through ``HostAdapter``."""

    def __init__(self):
        self._validators: dict[str, Callable] = {}
        self._previews: dict[str, Callable] = {}

    def register_validator(self, kind: str, validator: Callable) -> None:
        if not str(kind or '').strip() or not callable(validator):
            raise AIError('artifact.badDeclaration', kind='refused', key='artifact.badDeclaration', reason=kind)
        self._validators[str(kind)] = validator

    def register_preview(self, kind: str, preview: Callable) -> None:
        if not str(kind or '').strip() or not callable(preview):
            raise AIError('artifact.badDeclaration', kind='refused', key='artifact.badDeclaration', reason=kind)
        self._previews[str(kind)] = preview

    def validated_by(self, kind: str) -> bool:
        return str(kind or '') in self._validators

    def kinds(self) -> list[str]:
        return sorted(set(self._validators) | set(self._previews))

    def problems(self, kind: str, payload: dict) -> list[str]:
        """Problems the host's validator reports; an undeclared kind has none (it is unvalidated)."""
        validator = self._validators.get(str(kind or ''))
        if validator is None:
            return []
        try:
            answer = validator(dict(payload or {}))
        except AIError:
            raise
        except Exception as exc:  # a host bug is a named refusal, not a 500
            raise AIError(
                'artifact.validatorFailed',
                kind='refused',
                key='artifact.validatorFailed',
                reason=str(kind),
                detail=str(exc),
            ) from exc
        return [str(problem) for problem in (answer or []) if str(problem).strip()]

    def preview(self, kind: str, payload: dict) -> dict:
        """The host's preview payload, or ``{}``: a preview is a convenience, never a gate."""
        builder = self._previews.get(str(kind or ''))
        if builder is None:
            return {}
        try:
            return dict(builder(dict(payload or {})) or {})
        except Exception:
            # A preview that cannot be built must not stop the artifact being shown as text.
            return {}
