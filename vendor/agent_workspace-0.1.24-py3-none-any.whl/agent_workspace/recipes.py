"""Recipes: an ordered plan whose progress is proved by evidence, never by the model's word.

A recipe is declared by the host as data: steps with the one tool that completes each, the earlier
steps whose evidence it needs, and the name of what it produces. The framework owns the durable run
and the masking rule: while a run is live, only the current step's tool and the read-only tools are
offered, so a small model cannot skip ahead. Evidence is a tool result the server actually got; a
failed call leaves the step open, and a user skip is recorded as a skip in the final report.

This module imports no Flask and knows no domain: a workflow step and a chart step look the same.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .errors import AIError

#: Result keys worth keeping as evidence; the whole payload is not stored twice.
EVIDENCE_KEYS = ('ok', 'id', 'dataset_id', 'run_id', 'name', 'status', 'count', 'rows', 'errors', 'valid')
MAX_EVIDENCE_CHARS = 2000


@dataclass(frozen=True)
class RecipeStep:
    id: str
    title: str
    tool: str
    requires: tuple[str, ...] = ()
    produces: str = ''


@dataclass(frozen=True)
class Recipe:
    id: str
    title: str
    steps: tuple[RecipeStep, ...] = field(default_factory=tuple)

    def step(self, index: int) -> RecipeStep | None:
        return self.steps[index] if 0 <= index < len(self.steps) else None

    def l1(self) -> dict:
        return {
            'id': self.id,
            'title': self.title,
            'step_count': len(self.steps),
            'steps': [{'id': step.id, 'title': step.title, 'tool': step.tool} for step in self.steps],
        }


def parse_recipes(items, known_tools) -> dict[str, Recipe]:
    """Normalize host data; a duplicate id, an unknown tool or a forward requirement is refused."""
    recipes: dict[str, Recipe] = {}
    for row in items or []:
        if not isinstance(row, dict):
            continue
        identifier = str(row.get('id') or '').strip()
        steps = []
        seen: set[str] = set()
        for raw in row.get('steps') or ():
            if not isinstance(raw, dict):
                continue
            step_id = str(raw.get('id') or '').strip()
            tool = str(raw.get('tool') or '').strip()
            if not step_id or step_id in seen:
                raise AIError('recipe.stepId', kind='refused', key='recipe.stepId', reason=step_id)
            if known_tools and tool not in known_tools:
                raise AIError('recipe.unknownTool', kind='refused', key='recipe.unknownTool', reason=tool)
            requires = tuple(str(item) for item in raw.get('requires') or () if str(item))
            missing = [item for item in requires if item not in seen]
            if missing:
                raise AIError(
                    'recipe.forwardRequirement', kind='refused', key='recipe.forwardRequirement', reason=missing[0]
                )
            seen.add(step_id)
            steps.append(
                RecipeStep(
                    id=step_id,
                    title=str(raw.get('title') or step_id),
                    tool=tool,
                    requires=requires,
                    produces=str(raw.get('produces') or ''),
                )
            )
        if not identifier or not steps:
            raise AIError('recipe.incomplete', kind='refused', key='recipe.incomplete', reason=identifier)
        if identifier in recipes:
            raise AIError('recipe.duplicate', kind='refused', key='recipe.duplicate', reason=identifier)
        recipes[identifier] = Recipe(id=identifier, title=str(row.get('title') or identifier), steps=tuple(steps))
    return recipes


class Recipes:
    """The run store + the masking/advance rules. ``store`` is the framework's SQLite store."""

    def __init__(self, store, host, tools):
        self.store = store
        self.host = host
        self.tools = tools

    def _declared(self) -> dict[str, Recipe]:
        known = set(self.tools.names()) if hasattr(self.tools, 'names') else set()
        return parse_recipes(self.host.recipes(), known)

    def catalog(self) -> list[dict]:
        return [recipe.l1() for recipe in self._declared().values()]

    def get(self, recipe_id: str) -> Recipe | None:
        return self._declared().get(str(recipe_id or ''))

    # ── run lifecycle ────────────────────────────────────────────────────────

    def ensure(self, conversation_id: str, account: str, recipe_id: str) -> dict:
        """Start *recipe_id* for this conversation, or return the live run when it is the same one."""
        active = self.store.active_recipe_run(conversation_id, account)
        if active:
            if recipe_id and active.get('recipe_id') != recipe_id:
                raise AIError('recipe.busy', kind='refused', key='recipe.busy', reason=active.get('recipe_id') or '')
            return self.public(active)
        if not recipe_id:
            return {}
        if self.get(recipe_id) is None:
            raise AIError('recipe.unknown', kind='bad_request', key='recipe.unknown', reason=recipe_id)
        return self.public(self.store.start_recipe_run(account, conversation_id, recipe_id))

    def active(self, conversation_id: str, account: str) -> dict:
        run = self.store.active_recipe_run(conversation_id, account)
        return self.public(run) if run else {}

    def public(self, run: dict) -> dict:
        recipe = self.get(run.get('recipe_id') or '')
        if recipe is None:
            return {}
        evidence = self.store.recipe_evidence(run.get('id') or '')
        by_step: dict[str, str] = {}
        for row in evidence:
            by_step.setdefault(str(row.get('step_id') or ''), str(row.get('kind') or ''))
        index = int(run.get('step_index') or 0)
        status = str(run.get('status') or 'running')
        steps = []
        for position, step in enumerate(recipe.steps):
            if step.id in by_step:
                step_status = by_step[step.id]
            elif position == index and status == 'running':
                step_status = 'current'
            else:
                step_status = 'pending'
            steps.append(
                {
                    'id': step.id,
                    'title': step.title,
                    'tool': step.tool,
                    'requires': list(step.requires),
                    'status': step_status,
                }
            )
        current = None
        if status == 'running':
            step = recipe.step(index)
            if step is not None:
                current = {'id': step.id, 'title': step.title, 'tool': step.tool, 'requires': list(step.requires)}
        return {
            'run_id': run.get('id') or '',
            'recipe_id': recipe.id,
            'title': recipe.title,
            'status': status,
            'step_index': index,
            'current': current,
            'steps': steps,
        }

    def mask(self, allowed: set[str], state: dict) -> set[str]:
        """Keep the current step's tool plus read-only tools; a done run offers everything again."""
        if not state or state.get('status') != 'running' or not state.get('current'):
            return set(allowed)
        tool = state['current']['tool']
        kept = {name for name in allowed if name == tool or self._read_only(name) or self._always_ask(name)}
        return kept

    def _read_only(self, name: str) -> bool:
        try:
            spec = self.tools.get(name, '')
        except Exception:
            return False
        return bool(spec is not None and not getattr(spec, 'mutating', False))

    def _always_ask(self, name: str) -> bool:
        """An always-ask tool cannot act without the user, so it stays offerable in any step."""
        try:
            spec = self.tools.get(name, '')
        except Exception:
            return False
        return bool(spec is not None and getattr(spec, 'always_ask', False))

    def _advance(self, run: dict, step: RecipeStep, reason: str) -> dict:
        index = int(run.get('step_index') or 0) + 1
        progress = index >= len(self.get(run['recipe_id']).steps)
        updated = self.store.update_recipe_run(
            run['id'], run['account'], step_index=index, status='done' if progress else ''
        )
        updated['advanced'] = reason
        return self.public(updated)

    def observe(self, conversation_id: str, account: str, tool: str, content, is_error: bool) -> dict | None:
        """Record the outcome of a tool call against the current step; ``None`` when no run is live."""
        run = self.store.active_recipe_run(conversation_id, account)
        if not run:
            return None
        state = self.public(run)
        current = state.get('current') or {}
        if not current or current.get('tool') != tool:
            return state
        step = self.get(run.get('recipe_id') or '').step(int(run.get('step_index') or 0))
        if step is None:
            return state
        payload = None
        if isinstance(content, dict):
            payload = {key: content[key] for key in EVIDENCE_KEYS if key in content}
        if len(str(payload)) > MAX_EVIDENCE_CHARS:
            payload = {'truncated': True, 'keys': sorted(content)[:12]}
        if is_error:
            self.store.add_recipe_evidence(run['id'], step.id, tool, 'failed', payload)
            return self.public(self.store.get_recipe_run(run['id'], account))
        self.store.add_recipe_evidence(run['id'], step.id, tool, 'done', payload)
        return self._advance(run, step, 'done')

    def skip(self, conversation_id: str, account: str, reason: str = '') -> dict:
        """Record a deliberate skip and move on; the report keeps it visible."""
        run = self.store.active_recipe_run(conversation_id, account)
        if not run:
            raise AIError('recipe.none', kind='bad_request', key='recipe.none')
        step = self.get(run.get('recipe_id') or '').step(int(run.get('step_index') or 0))
        if step is None:
            raise AIError('recipe.done', kind='refused', key='recipe.done')
        self.store.add_recipe_evidence(run['id'], step.id, step.tool, 'skipped', {'reason': str(reason or '')[:200]})
        return self._advance(run, step, 'skipped')
