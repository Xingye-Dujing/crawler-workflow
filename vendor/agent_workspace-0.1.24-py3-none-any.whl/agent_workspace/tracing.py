"""Best-effort per-turn tracing with OTel GenAI attribute names.

A span carries ids, names, status and token counts — never prompt or answer text. Recording is
best-effort on purpose: a tracing failure must never fail a turn that already paid for a model.
"""

from __future__ import annotations


class Tracing:
    """Wraps the store's trace rows; every call swallows its own failure."""

    def __init__(self, store):
        self.store = store

    def start(
        self,
        *,
        turn_id: str,
        conversation_id: str,
        account: str,
        kind: str,
        name: str,
        parent: str = '',
        attributes: dict | None = None,
    ) -> dict:
        try:
            return self.store.add_trace(
                turn_id,
                conversation_id,
                account,
                kind=kind,
                name=name,
                parent=parent,
                attributes=attributes or {},
            )
        except Exception:
            return {}

    def finish(self, span: dict, *, status: str = 'ok', attributes: dict | None = None) -> None:
        if not span:
            return
        try:
            self.store.finish_trace(str(span.get('trace_id') or ''), status=status, attributes=attributes or {})
        except Exception:
            pass

    def spans(self, turn_id: str) -> list[dict]:
        try:
            return self.store.traces_for(turn_id)
        except Exception:
            return []

    def tree(self, turn_id: str) -> dict:
        """Spans of one turn, nested by ``parent``; the roots are provider calls (or a bare turn)."""
        spans = self.spans(turn_id)
        by_parent: dict[str, list[dict]] = {}
        nodes = {}
        for span in spans:
            node = dict(span)
            node['children'] = []
            nodes[str(span.get('trace_id') or '')] = node
            by_parent.setdefault(str(span.get('parent') or ''), []).append(node)
        for node in nodes.values():
            node['children'] = by_parent.get(str(node.get('trace_id') or ''), [])
        roots = [node for node in nodes.values() if not str(node.get('parent') or '') or node['parent'] not in nodes]
        return {'turn_id': turn_id, 'spans': [node for node in nodes.values()], 'roots': roots}
