"""Slash commands: one registry, framework commands plus whatever the host declares.

A command returns plain data; it never streams and never spends a token by itself. The framework
owns ``status``/``skills``/``mode``/``compact`` (things that need only the store), and a host adds the
commands that know its own project (``init`` …). A duplicate name is refused at boot instead of
shadowing a framework verb.
"""

from __future__ import annotations

from .errors import AIError


class CommandRegistry:
    def __init__(self):
        self._handlers: dict[str, object] = {}
        self._host: set[str] = set()

    @staticmethod
    def _name(name) -> str:
        return str(name or '').strip().lstrip('/')

    def register(self, name: str, handler, *, host: bool = False) -> None:
        clean = self._name(name)
        if not clean or not callable(handler):
            raise AIError('command.badDeclaration', kind='refused', key='command.badDeclaration', reason=str(name))
        if clean in self._handlers:
            raise AIError('command.duplicate', kind='refused', key='command.duplicate', reason=clean)
        self._handlers[clean] = handler
        if host:
            self._host.add(clean)

    def names(self) -> list[str]:
        return sorted(self._handlers)

    def host_names(self) -> list[str]:
        return sorted(self._host)

    def run(self, name: str, payload: dict) -> dict:
        clean = self._name(name)
        handler = self._handlers.get(clean)
        if handler is None:
            raise AIError('command.unknown', kind='not_found', key='command.unknown', reason=clean)
        return dict(handler(payload) or {})
