"""The ports one turn asks of its workspace: what the agent needs, named as types.

``Agent`` used to take an untyped ``services`` bag assembled by ``AgentWorkspace``, so "what may a
turn touch" could only be answered by reading every call site in the loop. Each Protocol here is one
of those domains, with exactly the members the turn uses — the store it writes, the tools it offers,
the skills it resolves, the approvals it asks, the spans it traces.

These are structural types, not a container: nothing constructs them, nothing registers anything, and
the real workspace satisfies them as it is. A member added to the loop must be added here in the same
change, which is what keeps this file from becoming a comment.
"""

from __future__ import annotations

from typing import Protocol


class SettingsPort(Protocol):
    def get(self, key: str, default=''):
        """One setting value; the framework's defaults fill an absent key."""


class StorePort(Protocol):
    """The durable facts a turn reads and writes. Every method here is in ``agent_workspace/store``."""

    def get_conversation(self, conversation_id: str, account: str = '') -> dict: ...

    def create_conversation(self, account: str, title: str = '', conversation_id: str = '') -> dict: ...

    def patch_conversation(self, conversation_id: str, account: str, **fields) -> dict: ...

    def get_pref(self, account: str, key: str, default: str = '') -> str: ...

    def list_messages(self, conversation_id: str, limit: int = 0) -> list[dict]: ...

    def last_message(self, conversation_id: str, role: str = '') -> dict: ...

    def append_message(
        self,
        conversation_id: str,
        turn_id: str,
        role: str,
        blocks: list,
        meta: dict | None = None,
        status: str = 'done',
        message_id: str = '',
    ) -> dict: ...

    def update_message(self, message_id: str, *, blocks=None, meta=None, status: str = '') -> dict: ...

    def delete_message(self, message_id: str) -> bool: ...

    def pending_calls(self, conversation_id: str, account: str = '') -> list[dict]: ...

    def claim_pending_call(self, call_id: str, account: str = '') -> dict: ...

    def save_pending_call(
        self,
        *,
        call_id: str,
        conversation_id: str,
        account: str,
        turn_id: str,
        kind: str,
        tool: str = '',
        args: dict | None = None,
        provider: str = '',
        model: str = '',
        skill: str = '',
    ) -> dict: ...

    def record_usage(
        self,
        account: str,
        conversation_id: str,
        provider: str,
        model: str,
        prompt: int = 0,
        completion: int = 0,
        cached: int = 0,
        reasoning: int = 0,
        calls: int = 1,
    ) -> None: ...

    def save_artifact(self, account: str, conversation_id: str, kind: str, payload: dict) -> dict: ...

    def begin_step(
        self,
        turn_id: str,
        conversation_id: str,
        account: str,
        *,
        kind: str,
        call_id: str = '',
        tool: str = '',
        args: dict | None = None,
    ) -> tuple[dict, bool]: ...

    def finish_step(self, step_id: str, result, status: str = 'done') -> dict: ...


class ToolsPort(Protocol):
    """The tool registry: what is offered, what a call's policy is, and one execution."""

    def get(self, name: str, account: str = ''):
        """One ``ToolSpec`` (or None) — the offer list's unit."""

    def check(self, name: str, ctx: dict | None = None):
        """The spec a call must be checked against, refusing an unknown tool by name."""

    def schemas(self, allowed=None, *, query: str = '', limit: int = 0, required=()):
        """The schemas offered this round, narrowed by the skill, the recipe mask and the budget."""

    def execute(self, name: str, args: dict, ctx: dict, allowed=None):
        """Run one tool once. Side effects happen here and nowhere else."""


class RecipesPort(Protocol):
    def ensure(self, conversation_id: str, account: str, recipe_id: str = '') -> dict: ...

    def active(self, conversation_id: str, account: str = '') -> dict: ...

    def mask(self, allowed, state) -> set: ...

    def skip(self, conversation_id: str, account: str, reason: str = '') -> dict: ...

    def observe(self, conversation_id: str, account: str, tool: str, content, is_error: bool) -> dict: ...


class ApprovalsPort(Protocol):
    def request(self, conversation_id: str, tool: str, args: dict, call_id: str, labels: dict) -> None: ...

    def consume(self, conversation_id: str, tool: str, args: dict, *, once_only: bool = True) -> bool: ...

    def settle(self, conversation_id: str, call_id: str, answers: list) -> str: ...


class TracingPort(Protocol):
    def start(self, *, turn_id: str, conversation_id: str, account: str, kind: str, name: str, **kwargs) -> dict: ...

    def finish(self, span: dict, *, status: str = 'ok', attributes: dict | None = None) -> None: ...


class ContextPort(Protocol):
    def build(self, text: str, account: str, payload: dict) -> tuple[str, dict]: ...

    def for_replay(self, context_text: str) -> tuple[str, dict]: ...


class SkillsPort(Protocol):
    def get(self, skill_id: str, account: str = ''):
        """One skill, or None — the unknown id is refused by the caller, by name."""

    def availability(self, skill, provider_id: str, model: str) -> tuple[bool, str]: ...


class CostsPort(Protocol):
    def spend_state(self, conversation_id: str, account: str) -> dict: ...


class ReferencesPort(Protocol):
    def resolve(self, text: str, account: str) -> tuple[str, list]: ...

    def resolve_rows(self, rows, account: str) -> tuple[str, list]: ...


class CatalogPort(Protocol):
    def default_id(self) -> str: ...

    def get(self, provider_id: str, account: str = ''):
        """One provider transport, or None — the caller refuses an unknown id by name."""

    def default_model(self, provider_id: str, api_key: str = '', host: str = '') -> str: ...


class HostPort(Protocol):
    def environment(self):
        """``{kind, prompt_line()}`` — what the system prompt says about this host."""

    def universal_tools(self) -> list: ...


class ArtifactsPort(Protocol):
    def problems(self, kind: str, payload: dict) -> list: ...

    def preview(self, kind: str, payload: dict): ...

    def validated_by(self, kind: str) -> bool: ...


class WorkspacePort(Protocol):
    """The host's own data surface, for an approval preview. Never written to by a turn."""


class AgentServices(Protocol):
    """Everything a turn may reach, one attribute per port."""

    store: StorePort
    tools: ToolsPort
    recipes: RecipesPort
    approvals: ApprovalsPort
    tracing: TracingPort
    context: ContextPort
    skills: SkillsPort
    costs: CostsPort
    references: ReferencesPort
    catalog: CatalogPort
    settings: SettingsPort
    host: HostPort
    artifact_registry: ArtifactsPort

    def t(self, key: str, **kwargs) -> str:
        """One localized sentence."""

    def workspace(self, account: str = '') -> WorkspacePort:
        """The host's workspace handle, for previews and reads."""
