"""One place that answers: does this tool call need a human, and may a session grant cover it?

A tool declares what it *is* (``mutating``) and, when nothing should ever run it silently, that it
always asks. The policy engine turns those declarations plus the host's auto-approve setting into
a decision, so the turn loop never grows another branch per tool. A destructive tool or a resource
grant (both ``always_ask``) is never satisfied by a session-scope grant: the user said yes to that
one exact call, not to every future one.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ApprovalDecision:
    """What the engine should do with one proposed tool call."""

    required: bool
    #: A session-scope grant may cover repeats. Only false for an ``always_ask`` tool.
    session_allowed: bool
    #: ``always`` / ``mutating`` / ``none`` — useful for a host that words the card.
    reason: str


class PolicyEngine:
    """The turn loop's approval policy; the host supplies declarations, not branches."""

    @staticmethod
    def decide(spec, *, auto: bool) -> ApprovalDecision:
        always = bool(getattr(spec, 'always_ask', False))
        mutating = bool(getattr(spec, 'mutating', False))
        if always:
            return ApprovalDecision(required=True, session_allowed=False, reason='always')
        if mutating and not auto:
            return ApprovalDecision(required=True, session_allowed=True, reason='mutating')
        return ApprovalDecision(required=False, session_allowed=True, reason='none')
