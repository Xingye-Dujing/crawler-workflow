"""Declared lifecycles, validated once, shared by every store write.

The AI turn is the framework's one durable lifecycle object: it survives a browser disconnect, a
conversation switch and a process restart. Its states and legal moves are declared here rather than
scattered through ``if`` branches, so an impossible pair fails by name (machine, source, target)
instead of being written to the database. The crawler host keeps its own run/node machines; this one
belongs to the workspace.

A host may add a machine, but it must be structurally whole: a start state that is not terminal,
terminals with no exits, every other state with at least one exit, and every target declared.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Machine:
    """One immutable transition table."""

    name: str
    start: str
    terminals: tuple[str, ...]
    moves: dict[str, tuple[str, ...]]

    @property
    def states(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys((*self.moves, *self.terminals)))

    def allows(self, source: str, target: str) -> bool:
        return target in self.moves.get(source, ())

    def require(self, source: str, target: str) -> str:
        """Return ``target`` when the move is declared; refuse by name otherwise."""
        if source not in self.states or target not in self.states:
            raise ValueError(f'{self.name}: unknown state {source!r} -> {target!r}')
        if target in self.terminals and source == target:
            raise ValueError(f'{self.name}: {source!r} is already terminal')
        if not self.allows(source, target):
            raise ValueError(f'{self.name}: illegal move {source!r} -> {target!r}')
        return target


def machine(name: str, start: str, terminals: tuple[str, ...], moves: dict) -> Machine:
    """Build a machine, refusing a structurally incomplete table."""
    table = {source: tuple(dict.fromkeys(targets)) for source, targets in moves.items()}
    names = [*table, *terminals]
    states = tuple(dict.fromkeys(names))
    if len(states) != len(names):
        raise ValueError(f'{name}: duplicate state name')
    if start not in states:
        raise ValueError(f'{name}: start state {start!r} is not a state')
    if start in terminals:
        raise ValueError(f'{name}: start state {start!r} is terminal')
    for terminal in terminals:
        if table.get(terminal):
            raise ValueError(f'{name}: terminal {terminal!r} has exits')
    for source, targets in table.items():
        if source in terminals:
            continue
        if not targets:
            raise ValueError(f'{name}: {source!r} has no exit')
        for target in targets:
            if target not in states:
                raise ValueError(f'{name}: {source!r} moves to unknown {target!r}')
            if target == source:
                raise ValueError(f'{name}: {source!r} moves to itself')
    return Machine(name=name, start=start, terminals=tuple(terminals), moves=table)


#: One AI turn. A question pauses at ``awaiting_user``; its answer resumes the SAME turn at
#: ``streaming``. A crash or a closed event stream settles ``interrupted``; only a finished turn is
#: ``settled``. ``new`` -> ``settled`` covers a refusal raised before the provider was ever called.
TURN = machine(
    'turn',
    start='new',
    terminals=('settled', 'interrupted'),
    moves={
        'new': ('context', 'settled', 'interrupted'),
        'context': ('streaming', 'settled', 'interrupted'),
        'streaming': ('tool', 'awaiting_user', 'settled', 'interrupted'),
        'tool': ('streaming', 'awaiting_user', 'settled', 'interrupted'),
        'awaiting_user': ('streaming', 'settled', 'interrupted'),
    },
)
